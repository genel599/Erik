# madem — mesajlaşma uygulaması

madem; kullanıcı adı/şifre girişi, gerçek Supabase verileri ve mobil uyumlu web arayüzüyle geliştirilen mesajlaşma uygulamasıdır. E-posta adresi ve telefon numarası kullanıcıdan istenmez.

## Bu paketteki özellikler

- Kullanıcı adı/şifre ile kayıt ve giriş
- Bire bir ve grup metin sohbetleri; mesaj düzenleme/silme/yanıtlama ve emoji tepkileri
- Gerçek zamanlı mesaj akışı ve çevrimiçi durumu
- Fotoğraf, video, dosya ve tarayıcı destekliyorsa sesli mesaj yükleme/oynatma
- Okundu/iletildi kayıtları ve yazıyor göstergeleri
- Uygulama içi bildirim kayıtları ve tarayıcı bildirim izni
- Kullanıcı engelleme, sohbet arşivleme (bire bir) ve sabitleme (grup)
- Supabase Auth TOTP iki aşamalı doğrulaması
- Hesabı kalıcı silme akışı
- Profil fotoğrafı/biyografi, açık tema
- Capacitor ile Android/iOS kabuğu oluşturmak için yapılandırma

## Kurulum (web)

1. Node.js 20+ yükle.
2. `.env.example` dosyasını `.env` olarak kopyala; Supabase URL ve publishable key değerlerini ayarla.
3. `npm install`
4. `npm run dev`
5. Üretim derlemesi için `npm run build`.

Bu çalışma oturumunda npm kayıt deposuna erişim zaman aşımına uğradığından paket kurulumu ve tam üretim derlemesi doğrulanamadı. Kaynak JSX/JavaScript sözdizimi `tsc` ayrıştırıcısıyla kontrol edildi.

## Supabase

Uygulama aşağıdaki Edge Functions'ı kullanır:

- `madem-register`: yeni hesap ve profil oluşturma
- `madem-login`: kullanıcı adı üzerinden oturum açma uç noktası
- `madem-delete-account`: doğrulanmış oturum sahibinin hesabını ve profilini silme

Kayıt/giriş ekranı şu anda Supabase Auth ile uygulama içinde gizli `@accounts.madem.invalid` takma adresini kullanır. Bu gerçek e-posta değildir. Service-role anahtarı asla istemciye eklenmemelidir.

`supabase/migrations/` içindeki yeni migration dosyaları medya, okundu bilgisi, yazıyor göstergesi, arama sinyalleşmesi, bildirim, engelleme/şikâyet ve kullanıcı sohbet tercihlerini kapsar. Bu migration'lar bağlı Supabase projesine bu geliştirme sırasında uygulandı.

## Android ve iOS derlemesi

Capacitor yapılandırması eklendi; ancak mağazaya yüklenebilir `.aab`/`.apk` veya `.ipa` dosyaları henüz üretilmedi. Bunun için önce bağımlılıkların kurulması gerekir:

```bash
npm install
npm run build
npm run cap:add:android   # ilk kurulumda bir kez
npm run cap:add:ios       # macOS üzerinde ilk kurulumda bir kez
npm run cap:sync
```

Android için Android Studio ve uygun JDK gerekir; mağaza yayını için imzalı release bundle oluşturulmalıdır. iOS için macOS, Xcode, Apple Developer hesabı ve provisioning/signing ayarları gerekir. Bu ortamda npm kurulumunun zaman aşımına uğraması, Android/iOS derleme araçlarının ve mağaza imzalama kimlik bilgilerinin bulunmaması nedeniyle bu dosyalar burada üretilemedi.

## Önemli sınırlamalar — üretim öncesi gerekli işler

- Sesli ve görüntülü arama bu sürümden kaldırıldı; arama özelliği mevcut sürümde yoktur.
- Uygulama içi bildirim kayıtları ve tarayıcı bildirimleri vardır; Android FCM/iOS APNs üzerinden arka plan push bildirimleri için proje kimlikleri/sertifikaları ve gönderici servisi gerekir.
- Mesaj okundu bilgileri temel düzeydedir; teslim/okundu durumu tüm cihaz senaryolarında test edilmelidir.
- Engelleme yeni bire bir mesaj göndermeyi RLS politikasıyla engeller. Yönetici şikâyet inceleme paneli henüz yoktur.
- İki aşamalı doğrulama Supabase Auth TOTP faktörünü kullanır; kurtarma kodları, cihaz kaybı ve hesap kurtarma akışı ayrıca tasarlanıp test edilmelidir.
- Bu sürüm nihai, güvenlik denetiminden geçmiş bir mağaza ürünü olarak değerlendirilmemelidir.

## Güvenli güncelleme notları

- `src/components.jsx`, giriş ekranı ve avatar bileşenlerini `src/main.jsx` dosyasından ayırır.
- Sohbet özeti için `20261010122000_madem_conversation_summaries.sql` migration'ı, son mesaj ve okundu bilgisini tek RPC çağrısında getirir. Migration henüz uygulanmadıysa istemci toplu sorgu yedeğine döner.
- Migration'ları Supabase SQL Editor/CLI üzerinden uygulamadan önce hedef veritabanında yedek alın ve özellikle mevcut şemayla karşılaştırın. Kaynak paketi tek başına canlı veritabanını veya Netlify sitesini değiştirmez.
- React render hataları için hata sınırı eklendi; beklenmeyen bir arayüz hatasında tamamen boş ekran yerine yenileme mesajı gösterilir.

---
## Sürüm notları (v8_7 → v8_12)
Ayrıntılar `DEGISIKLIKLER-v8_*.md` dosyalarında. Veritabanı migration'ları tarih sırasıyla Supabase'e uygulanmalıdır (`supabase/migrations`). Son durum için `DENETIM_RAPORU.md`'ye bak.

## Bildirimler
v8.13 ile Web Push sunucu altyapısı Supabase üzerinde hazırlanmıştır. Ayrıntılar için `BILDIRIM_KURULUM.md` ve `DEGISIKLIKLER-v8_13.md` dosyalarına bakın. Android FCM gönderimi için Firebase servis hesabı gereklidir.
