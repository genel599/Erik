# Madem — Vercel dağıtımı

## Vercel ayarları

Bu proje Vite tabanlıdır. Proje klasörünün kökünü Vercel'e yükleyin (bu klasörde `package.json` ve `vercel.json` bulunmalı).

- Framework Preset: **Vite**
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: `npm install`

`vercel.json`, bu ayarları ve istemci tarafı rotalar için `index.html` yönlendirmesini tanımlar.

## Ortam değişkenleri

Vercel projesinde **Settings → Environment Variables** bölümüne, Supabase projenize ait değerleri ekleyin:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- İsteğe bağlı: `VITE_TURN_URL`, `VITE_TURN_USERNAME`, `VITE_TURN_CREDENTIAL`, `VITE_VAPID_PUBLIC_KEY`

Değişkenleri ekledikten veya değiştirdikten sonra yeni deployment başlatın. Tarayıcıda kullanılan `VITE_` değişkenleri derleme çıktısına dahil olur; **service-role/secret anahtarlarını `VITE_` değişkenlerine koymayın**. Supabase erişimi RLS politikalarıyla korunmalıdır.

## Supabase migration'ları

ZIP'i Vercel'e yüklemek SQL migration'larını veritabanına uygulamaz. `supabase/migrations/` içindeki henüz uygulanmamış migration'ları, proje bağlantınızı doğruladıktan sonra Supabase CLI ile sırayla uygulayın. Bu sürümün cihaz oturumu migration dosyası:

`supabase/migrations/20261013170000_madem_device_sessions.sql`

Migration'ları canlı veritabanına uygulamadan önce yedek ve test ortamı kullanın.

## Doğrulama durumu

Bu arşivde `vercel.json` ve bu dağıtım notu eklendi; ZIP bütünlüğü kontrol edilmelidir. Bu çalışma ortamında npm kayıt sunucusuna DNS bağlantısı kurulamadığı için bağımlılıklar yüklenemedi ve `npm run build` doğrulaması tamamlanamadı. Bu nedenle Vercel dağıtımı başarılı olacak diye garanti verilmez; ilk deployment sonucundaki build loglarını kontrol edin.
