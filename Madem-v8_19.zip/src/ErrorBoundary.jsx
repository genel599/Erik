import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorId: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorId: Date.now().toString() };
  }

  componentDidCatch(error, info) {
    const report = {
      app: 'madem',
      time: new Date().toISOString(),
      message: error?.message,
      stack: error?.stack,
      component: info?.componentStack,
    };
    console.error('Madem uygulama hatası:', report);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="app-error">
          <h2>Bir hata oluştu</h2>
          <p>Geçici bir sorun oluştu. Yenileyip tekrar deneyebilirsin.</p>
          <small>Hata kodu: {this.state.errorId}</small>
          <br />
          <button onClick={() => location.reload()}>Yenile</button>
        </div>
      );
    }
    return this.props.children;
  }
}
