import React, { useState } from 'react';
import { ArrowUpRight, ShieldCheck } from 'lucide-react';
import { supabase } from './supabase';

const initials = (name = '?') => name.trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();

export function Avatar({ name, url, size = 'md', online = false }) {
  return <div className={`avatar avatar-${size}`}>{url ? <img src={url} alt="" /> : <span>{initials(name)}</span>}{online && <i className="online-dot" />}</div>;
}
export function AuthScreen() {
  const [mode, setMode] = useState('login');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState(''); const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [notice, setNotice] = useState('');
  async function usernameLogin(normalized, secret) {
    const { data, error: functionError } = await supabase.functions.invoke('madem-login', {
      body: { username: normalized, password: secret }
    });
    if (functionError) {
      let message = functionError.message;
      try { const payload = await functionError.context?.json?.(); if (payload?.error) message = payload.error; } catch {}
      throw new Error(message || 'Giriş servisine ulaşılamadı. Biraz sonra tekrar dene.');
    }
    if (!data?.access_token || !data?.refresh_token) throw new Error(data?.error || 'Giriş tamamlanamadı. Kullanıcı adını ve şifreni kontrol et.');
    const { error: sessionError } = await supabase.auth.setSession({ access_token: data.access_token, refresh_token: data.refresh_token });
    if (sessionError) throw new Error('Şifre doğrulandı ancak oturum açılamadı. Tekrar dene.');
  }
  async function submit(e) {
    e.preventDefault(); setError(''); setNotice(''); setBusy(true);
    try {
      if (mode === 'signup') {
        if (!/^[a-z0-9_]{3,24}$/.test(username.toLowerCase())) throw new Error('Kullanıcı adı 3–24 karakter olmalı; yalnızca harf, rakam ve _ kullanılabilir.');
        const normalized = username.trim().toLowerCase();
        const { error: registerError } = await supabase.functions.invoke('madem-register', {
          body: { username: normalized, password, displayName: displayName.trim() || normalized }
        });
        if (registerError) {
          let message = registerError.message;
          try { const payload = await registerError.context?.json?.(); if (payload?.error) message = payload.error; } catch {}
          throw new Error(message || 'Hesap oluşturulamadı.');
        }
        // Use the same username-auth endpoint as regular login, then persist its session.
        await usernameLogin(normalized, password);
      } else {
        const normalized = username.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,24}$/.test(normalized)) throw new Error('Kullanıcı adını kontrol et.');
        await usernameLogin(normalized, password);
      }
    } catch (err) { setError(err.message || 'Bir hata oluştu.'); }
    finally { setBusy(false); }
  }
  return <main className="auth-shell"><section className="auth-card">
    <div className="brand-lockup"><div className="brand-mark"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><div><div className="brand-name"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><div className="brand-tagline">yakınlarınla bağlantıda kal.</div></div></div>
    <div className="auth-intro"><p className="eyebrow">YENİ NESİL MESAJLAŞMA</p><h1>{mode === 'login' ? 'Tekrar hoş geldin.' : 'Sohbete katıl.'}</h1><p>{mode === 'login' ? 'Sohbetlerin seni bekliyor.' : 'Kendine bir hesap oluştur, konuşmaya başla.'}</p></div>
    <form className="auth-form" onSubmit={submit}>
      {mode === 'signup' && <><label>Görünen ad<input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Nasıl hitap edelim?" maxLength={60} required /></label><label>Kullanıcı adı<div className="input-prefix"><span>@</span><input value={username} onChange={e => setUsername(e.target.value.toLowerCase())} placeholder="kullaniciadi" minLength={3} maxLength={24} pattern="[a-z0-9_]{3,24}" required /></div></label></>}
      {mode === 'login' && <label>Kullanıcı adı<div className="input-prefix"><span>@</span><input value={username} onChange={e => setUsername(e.target.value.toLowerCase())} placeholder="kullaniciadi" autoComplete="username" minLength={3} maxLength={24} required /></div></label>}
      <label>Şifre<input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="En az 8 karakter" minLength={8} maxLength={128} required /></label>
      {error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}
      <button className="primary-btn wide" disabled={busy}>{busy ? 'İşleniyor…' : mode === 'login' ? 'Giriş yap' : 'Hesap oluştur'} <ArrowUpRight size={17} /></button>
    </form>
    <div className="auth-switch">{mode === 'login' ? 'Henüz hesabın yok mu?' : 'Zaten hesabın var mı?'} <button onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); setNotice(''); }}>{mode === 'login' ? 'Kayıt ol' : 'Giriş yap'}</button></div>
    <div className="auth-foot"><ShieldCheck size={14} /> Hesapların ve sohbetlerin güvenliği önemlidir.</div>
  </section><div className="auth-side"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-message hero-a"><Avatar name="Ece Yılmaz" size="sm"/><div><b>Ece Yılmaz</b><p>Akşam görüşüyor muyuz? 🌙</p></div><span>14:32</span></div><div className="hero-message hero-b"><Avatar name="Mert Kaya" size="sm"/><div><b>Mert Kaya</b><p>Fotoğrafları gönderdim 📸</p></div><span>14:29</span></div><div className="hero-copy"><span className="hero-chip"><span className="live-dot"/> DAHA YAKIN, DAHA KOLAY</span><h2>Konuşmak için<br/><em>bir sebep</em> yeter.</h2><p>Mesajların ve sevdiklerin. Hepsi tek bir yerde.</p></div><div className="hero-bottom"><span>MESAJLAŞ</span><span>·</span><span>PAYLAŞ</span><span>·</span><span>BAĞLAN</span></div></div></main>;
}

