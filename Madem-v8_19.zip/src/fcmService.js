// Geriye dönük uyumluluk katmanı — asıl mantık pushNotifications.js içinde.
import { autoRegisterAndroidPush } from './pushNotifications';
export const registerCurrentDevice = () => autoRegisterAndroidPush();
