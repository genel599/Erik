import { supabase } from './supabase';
const DEVICE_KEY = 'madem-device-id';
function deviceId() {
  try {
    let id = localStorage.getItem(DEVICE_KEY);
    if (!id) { id = crypto.randomUUID(); localStorage.setItem(DEVICE_KEY, id); }
    return id;
  } catch { return crypto.randomUUID(); }
}
export async function registerCurrentDeviceSession(userId) {
  if (!supabase || !userId || !navigator.onLine) return false;
  const id = deviceId();
  const ua = navigator.userAgent || '';
  const platform = /Android/i.test(ua) ? 'android' : /iPhone|iPad|iPod/i.test(ua) ? 'ios' : /Windows/i.test(ua) ? 'windows' : /Macintosh/i.test(ua) ? 'macos' : 'web';
  const { error } = await supabase.rpc('register_device_session', { p_device_id: id, p_platform: platform, p_label: ua.slice(0, 160) });
  if (error) { console.warn('Cihaz oturumu eşitlenemedi:', error.message); return false; }
  return true;
}
