// Geriye dönük uyumluluk katmanı — asıl mantık pushNotifications.js içinde.
import { autoRegisterAndroidPush } from './pushNotifications';
export async function setupAndroidNotifications() {
  try { return await autoRegisterAndroidPush(); } catch (e) { console.warn('FCM kurulamadı', e); return false; }
}
