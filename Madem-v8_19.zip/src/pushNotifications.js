import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { supabase } from './supabase';

const TOKEN_KEY = 'madem-fcm-token';
let listenersReady = false;

export const isNativeAndroid = () => {
  try { return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android'; } catch { return false; }
};

async function saveToken(value) {
  if (!value || !supabase) return;
  const { error } = await supabase.rpc('register_device_token', { p_token: value, p_platform: 'android' });
  if (error) { console.warn('FCM token kaydedilemedi:', error.message); return; }
  try { localStorage.setItem(TOKEN_KEY, value); } catch {}
}

// Dinleyiciler register() çağrısından ÖNCE eklenmeli; yoksa token olayı kaçırılabilir.
async function ensureListeners() {
  if (listenersReady) return;
  listenersReady = true;
  await PushNotifications.addListener('registration', (t) => { saveToken(t.value); });
  await PushNotifications.addListener('registrationError', (e) => console.warn('FCM kayıt hatası:', e?.error || e));
}

// Android 8+ için yüksek öncelikli kanal; sunucu bildirimleri bu kanal kimliğiyle gönderir.
async function ensureChannel() {
  try { await PushNotifications.createChannel({ id: 'messages', name: 'Mesajlar', description: 'Yeni mesaj bildirimleri', importance: 5, visibility: 1, sound: 'default', vibration: true }); } catch {}
}

async function registerNow() {
  await ensureChannel();
  await ensureListeners();
  await PushNotifications.register();
}

// Ayarlardaki "bildirimleri aç" düğmesi için: izin ister, reddedilmişse açıklayıcı hata verir.
export async function registerAndroidPush() {
  if (!isNativeAndroid()) throw new Error('Bu özellik yalnızca Android uygulamasında çalışır.');
  let perm = await PushNotifications.checkPermissions();
  if (perm.receive !== 'granted') perm = await PushNotifications.requestPermissions();
  if (perm.receive !== 'granted') throw new Error('Bildirim izni verilmedi. Telefon Ayarları > Uygulamalar > madem > Bildirimler bölümünden izin ver.');
  await registerNow();
  return true;
}

// Girişte otomatik: izin zaten verilmişse sessizce yeniler, ilk kez ise izin ister. Reddedilmişse rahatsız etmez.
export async function autoRegisterAndroidPush() {
  if (!isNativeAndroid()) return false;
  let perm = await PushNotifications.checkPermissions();
  if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') perm = await PushNotifications.requestPermissions();
  if (perm.receive !== 'granted') return false;
  await registerNow();
  return true;
}

// Çıkış yaparken ve bildirimleri kapatırken: token'ı veritabanından ve FCM'den sil. Oturum kapanmadan ÖNCE çağır.
export async function unregisterAndroidPush() {
  if (!isNativeAndroid()) return;
  let token = null;
  try { token = localStorage.getItem(TOKEN_KEY); } catch {}
  if (token && supabase) { try { await supabase.rpc('unregister_device_token', { p_token: token }); } catch {} try { localStorage.removeItem(TOKEN_KEY); } catch {} }
  try { await PushNotifications.unregister(); } catch {}
}

// Eski ad ile uyumluluk
export const initPushNotifications = () => registerAndroidPush();
