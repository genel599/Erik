import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';

// Bildirime dokunulunca (uygulama kapalıyken bile) ilgili sohbetin kimliğini onOpen'a verir.
export function registerFCMNotificationOpenHandler(onOpen) {
  let handle = null, removed = false;
  try { if (!Capacitor.isNativePlatform()) return () => {}; } catch { return () => {}; }
  PushNotifications.addListener('pushNotificationActionPerformed', (event) => {
    const data = event.notification?.data || {};
    const id = data.conversationId || data.conversation_id;
    if (id) onOpen(id);
  }).then((h) => { if (removed) h.remove(); else handle = h; }).catch(() => {});
  return () => { removed = true; handle?.remove(); };
}
