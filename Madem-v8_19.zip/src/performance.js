// v15 performance helpers
// Keeps non-critical work away from the main UI thread.
export function scheduleIdleTask(task) {
  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    return window.requestIdleCallback(() => task());
  }
  return setTimeout(task, 0);
}

export function observePerformance() {
  if (typeof window === 'undefined' || !window.performance) return;
  scheduleIdleTask(() => {
    const nav = performance.getEntriesByType?.('navigation')?.[0];
    if (nav) console.info('[Madem Performance]', { load: Math.round(nav.loadEventEnd - nav.startTime) });
  });
}
