import { createClient } from '@supabase/supabase-js';

// Supabase publishable keys are intended for browser use. Access is enforced by RLS.
// Never silently connect to a fallback project. Configure these per deployment.
const url = String(import.meta.env.VITE_SUPABASE_URL || '').trim();
const key = String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '').trim();
export const isSupabaseConfigured = Boolean(url && key);
export const supabase = isSupabaseConfigured ? createClient(url, key, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
}) : null;
