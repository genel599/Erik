import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, ArrowDownLeft, ArrowLeft, ArrowUpRight, Bell, Check, CheckCheck, ChevronDown, CircleHelp, Image, LogOut, MessageCircle, MoreHorizontal, Paperclip, Plus, Search, Send, Settings, ShieldCheck, Smile, UserRound, Users, X, Archive, Pin, Mic, StopCircle, ShieldAlert, Trash2, RotateCw, Star, UserPlus } from 'lucide-react';
import { isSupabaseConfigured, supabase } from './supabase';
import { Avatar, AuthScreen } from './components';
import { registerAndroidPush, autoRegisterAndroidPush, unregisterAndroidPush, isNativeAndroid } from './pushNotifications';
import { registerFCMNotificationOpenHandler } from './fcmNotificationHandler';
import './styles.css';
import ErrorBoundary from './ErrorBoundary.jsx';
import { observePerformance } from './performance.js';
import { enqueueMedia, listQueuedMedia, removeQueuedMedia } from './mediaOutbox.js';
import { registerCurrentDeviceSession } from './deviceSync.js';

const clock = value => new Date(value).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
const dateLabel = value => {
  const d = new Date(value), now = new Date();
  if (d.toDateString() === now.toDateString()) return clock(value);
  return d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' });
};

const previewText = text => {
  const t = String(text || '');
  if (/^ses-\d+\.(webm|m4a|ogg|mp4)$/i.test(t) || t === 'Sesli mesaj') return '🎤 Sesli mesaj';
  if (/\.(jpe?g|png|webp|gif|heic)$/i.test(t) || t === 'Fotoğraf') return '📷 Fotoğraf';
  if (/\.(mp4|mov|webm|mkv)$/i.test(t) || t === 'Video') return '🎬 Video';
  return t;
};
const urlBase64ToUint8Array = base64 => {
  const padded = (base64 + '='.repeat((4 - base64.length % 4) % 4)).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(padded);
  return Uint8Array.from([...raw].map(ch => ch.charCodeAt(0)));
};
async function showSystemNotification(title, options) {
  // Android Chrome rejects `new Notification`; the service worker path works everywhere.
  try { const reg = await navigator.serviceWorker?.getRegistration(); if (reg) { await reg.showNotification(title, options); return; } } catch {}
  try { new Notification(title, options); } catch (e) { console.warn('Tarayıcı bildirimi gösterilemedi:', e); }
}
const PAGE_SIZE = 200;
const SAFE_MEDIA_TYPES = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
  'video/mp4', 'video/webm',
  'audio/webm', 'audio/ogg', 'audio/mpeg', 'audio/mp4',
  'application/pdf', 'text/plain', 'application/zip',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
]);
const SAFE_EXTENSION_TYPES = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif',
  mp4: 'video/mp4', webm: 'video/webm', ogg: 'audio/ogg', mp3: 'audio/mpeg', m4a: 'audio/mp4',
  pdf: 'application/pdf', txt: 'text/plain', zip: 'application/zip', doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ppt: 'application/vnd.ms-powerpoint',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
};
function getSafeMediaMime(file) {
  const name = String(file?.name || '').toLowerCase();
  const ext = name.includes('.') ? name.split('.').pop() : '';
  // MediaRecorder may append codecs (e.g. audio/webm;codecs=opus).
  // Strip parameters before checking the allowlist so voice notes stay audio/webm.
  const reported = String(file?.type || '').toLowerCase().split(';')[0].trim();
  if (/\.(?:html?|xhtml|svg|js|mjs|cjs|jsx|ts|tsx|exe|dll|bat|cmd|com|scr|ps1|sh|msi|apk|jar|php|hta|vbs|wsf)$/i.test(name)) return null;
  if (/^(?:text\/html|image\/svg\+xml|application\/(?:x-msdownload|x-executable|x-sh|x-msdos-program))$/i.test(reported)) return null;
  if (reported && reported !== 'application/octet-stream' && SAFE_MEDIA_TYPES.has(reported)) return reported;
  return SAFE_EXTENSION_TYPES[ext] || null;
}
// Çevrimdışı önbellek: son görülen sohbetler, mesajlar, favoriler cihazda saklanır.
const CACHE_PREFIX = 'madem-cache:';
function cacheGet(uid, key) { try { const raw = localStorage.getItem(`${CACHE_PREFIX}${uid}:${key}`); return raw ? JSON.parse(raw) : null; } catch { return null; } }
function cacheSet(uid, key, val) { try { localStorage.setItem(`${CACHE_PREFIX}${uid}:${key}`, JSON.stringify(val)); } catch { /* kota dolu olabilir */ } }
function readOutbox(uid) {
  try {
    const raw = JSON.parse(localStorage.getItem(`madem-outbox:${uid}`) || '[]');
    if (!Array.isArray(raw)) return [];
    // Eski sürümlerdeki local-* kimliklerini UUID'ye dönüştür; veritabanı id alanı UUID.
    let changed = false;
    const list = raw.filter(item => item && item.conversation_id && typeof item.content === 'string').map(item => {
      if (typeof item.id === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(item.id)) return item;
      changed = true;
      return { ...item, id: crypto.randomUUID(), created_at: item.created_at || new Date().toISOString() };
    });
    if (changed) writeOutbox(uid, list);
    return list;
  } catch { return []; }
}
function writeOutbox(uid, list) {
  try { localStorage.setItem(`madem-outbox:${uid}`, JSON.stringify(list)); return true; }
  catch { return false; }
}
function cacheClearAll() { try { Object.keys(localStorage).filter(k => k.startsWith(CACHE_PREFIX)).forEach(k => localStorage.removeItem(k)); } catch {} }
// Çevrimdışıyken getSession boş dönebilir; cihazda kayıtlı oturumu kullan.
function readStoredSession() { try { const k = Object.keys(localStorage).find(x => /^sb-.*-auth-token$/.test(x)); const v = k ? JSON.parse(localStorage.getItem(k)) : null; return v?.user && v?.refresh_token ? v : null; } catch { return null; } }
const dayLabel = value => {
  const d = new Date(value), now = new Date(), y = new Date(); y.setDate(now.getDate() - 1);
  if (d.toDateString() === now.toDateString()) return 'Bugün';
  if (d.toDateString() === y.toDateString()) return 'Dün';
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
};
const firstUrl = text => { const m = String(text || '').match(/https?:\/\/[^\s<>"']+/i); return m ? m[0].replace(/[.,;:!?)]+$/, '') : null; };
const MENTION_RE = /(@[\p{L}\p{N}_.]*[\p{L}\p{N}_])/u;
// Uygulama açıkken yeni mesajda "dıt dıt" sesi (iki kısa bip). Kapatmak için localStorage 'madem-sound' = 'off'
let beepCtx = null;
const playMessageBeep = () => {
  try {
    if (localStorage.getItem('madem-sound') === 'off') return;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    beepCtx = beepCtx || new AC();
    if (beepCtx.state === 'suspended') beepCtx.resume();
    [0, 0.17].forEach(offset => {
      const o = beepCtx.createOscillator(); const g = beepCtx.createGain(); const t = beepCtx.currentTime + offset;
      o.type = 'sine'; o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
      o.connect(g); g.connect(beepCtx.destination); o.start(t); o.stop(t + 0.13);
    });
  } catch {}
};
const ADMIN_DELETED_TEXT = 'Bu mesaj yönetici tarafından silindi';
const deletedLabel = m => (m?.content === ADMIN_DELETED_TEXT ? ADMIN_DELETED_TEXT : 'Bu mesaj silindi');
const MENTION_ALL_RE = /(^|[^\p{L}\p{N}_])@herkes(?![\p{L}\p{N}_])/iu;
const mentionsUser = (text, username) => { if (!text) return false; if (MENTION_ALL_RE.test(String(text))) return true; if (!username) return false; const esc = String(username).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); return new RegExp(`(^|[^\\p{L}\\p{N}_])@${esc}(?![\\p{L}\\p{N}_])`, 'iu').test(String(text)); };
const renderMentions = (text, myUsername) => String(text).split(MENTION_RE).map((part, i) => part.startsWith('@') && part.length > 1 ? <span key={i} className={`mention ${part.slice(1).toLowerCase() === 'herkes' || (myUsername && part.slice(1).toLowerCase() === String(myUsername).toLowerCase()) ? 'mention-me' : ''}`}>{part}</span> : part);
const EMOJIS = ['😀','😁','😂','🤣','😊','😍','😘','😎','🤔','😅','😢','😭','😡','🥳','😴','🤗','👍','👎','👏','🙏','💪','🙌','👋','🤝','❤️','💔','🔥','✨','🎉','💯','😮','😉'];
const REACTIONS = ['❤️','😂','👍','😮','😢','🔥'];
const previewCache = new Map();
function LinkCard({ url }) {
  const [data, setData] = useState(previewCache.get(url) || null);
  useEffect(() => {
    if (previewCache.has(url)) { setData(previewCache.get(url)); return; }
    let alive = true;
    supabase.functions.invoke('madem-link-preview', { body: { url } }).then(({ data: d, error: e }) => {
      const value = !e && d && !d.error ? d : { failed: true };
      previewCache.set(url, value); if (alive) setData(value);
    }).catch(() => { previewCache.set(url, { failed: true }); });
    return () => { alive = false; };
  }, [url]);
  if (!data || data.failed) return null;
  return <a className="link-card" href={data.url || url} target="_blank" rel="noreferrer noopener" onClick={e => e.stopPropagation()}>{data.image && <img src={data.image} alt="" loading="lazy"/>}<div><b>{data.title}</b>{data.description && <p>{data.description}</p>}<small>{data.site}</small></div></a>;
}


// Read receipts are monotonic: once a message has been read, a late/stale
// SELECT response or realtime payload must never paint it as unread again.
function mergeReceiptRows(previous, incoming, allowedMessageIds = null) {
  const allowed = allowedMessageIds ? new Set(allowedMessageIds) : null;
  const keyOf = row => `${row.message_id}:${row.user_id}`;
  const merged = new Map();
  for (const row of previous || []) {
    if (!allowed || allowed.has(row.message_id)) merged.set(keyOf(row), row);
  }
  for (const row of incoming || []) {
    if (allowed && !allowed.has(row.message_id)) continue;
    const key = keyOf(row);
    const old = merged.get(key);
    merged.set(key, {
      ...(old || {}),
      ...row,
      delivered_at: old?.delivered_at || row.delivered_at || null,
      read_at: old?.read_at || row.read_at || null,
    });
  }
  return [...merged.values()];
}

function App() {
  useEffect(() => { observePerformance(); }, []);
  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => { window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); };
  }, []);

  useEffect(() => {
    if (!('serviceWorker' in navigator) || !(location.protocol === 'https:' || location.hostname === 'localhost')) return;
    let refreshing = false;
    navigator.serviceWorker.register('/sw.js').then(reg => {
      // Yeni sürüm geldiyse arka planda al; bir sonraki açılışta devreye girer
      reg.update().catch(() => {});
      reg.addEventListener('updatefound', () => {
        const nw = reg.installing;
        if (!nw) return;
        nw.addEventListener('statechange', () => {
          if (nw.state === 'installed' && navigator.serviceWorker.controller) {
            // Sessiz güncelleme: yeni SW'yi hemen devreye al
            nw.postMessage({ type: 'SKIP_WAITING' });
          }
        });
      });
    }).catch(err => console.warn('PWA service worker kaydedilemedi:', err));
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      // İsteğe bağlı: sayfayı yenilemek yerine sadece yeni SW kontrolü alsın
    });
  }, []);

  // PWA: Ana ekrana ekle (Chrome/Edge Android)
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isStandalone, setIsStandalone] = useState(() =>
    window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true
  );
  useEffect(() => {
    const onBip = (e) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', onBip);
    const onInstalled = () => { setInstallPrompt(null); setIsStandalone(true); };
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBip);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);
  async function installPwa() {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') setInstallPrompt(null);
  }
  const [selectedMessageMenu, setSelectedMessageMenu] = useState(null); const [messageMenuMode, setMessageMenuMode] = useState('emoji'); const longPressRef = useRef({ timer: null, fired: false, x: 0, y: 0 });
  const [session, setSession] = useState(null); const [authReady, setAuthReady] = useState(false); const [profile, setProfile] = useState(null);
  const [section, setSection] = useState('chats'); const [conversations, setConversations] = useState([]); const [activeId, setActiveId] = useState(null); const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  const [messages, setMessages] = useState([]); const [draft, setDraft] = useState(''); const [query, setQuery] = useState(''); const draftKey = session?.user?.id && activeId ? `madem-draft:${session.user.id}:${activeId}` : null;
  const [people, setPeople] = useState([]); const [showNew, setShowNew] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [groupMode, setGroupMode] = useState(false); const [groupTitle, setGroupTitle] = useState(''); const [selectedPeople, setSelectedPeople] = useState([]); const [replyTo, setReplyTo] = useState(null); const [reactions, setReactions] = useState([]); const [themePref, setThemePref] = useState(() => { try { const v = localStorage.getItem('madem-theme'); return v === 'dark' || v === 'light' ? v : 'system'; } catch { return 'system'; } }); const [systemDark, setSystemDark] = useState(() => { try { return window.matchMedia('(prefers-color-scheme: dark)').matches; } catch { return false; } }); const theme = themePref === 'system' ? (systemDark ? 'dark' : 'light') : themePref;
  const [showChatMenu, setShowChatMenu] = useState(false); const [showTopMenu, setShowTopMenu] = useState(false); useEffect(() => { if (!showNew) setGroupMode(false); }, [showNew]);  const [editingMessage, setEditingMessage] = useState(null); const [editDraft, setEditDraft] = useState(''); const [deletingMessage, setDeletingMessage] = useState(null); const [confirmState, setConfirmState] = useState(null); const confirmResolveRef = useRef(null); const [messageActionBusy, setMessageActionBusy] = useState(false); const [profileName, setProfileName] = useState(''); const [profileBio, setProfileBio] = useState(''); const [messageAuthors, setMessageAuthors] = useState({}); const [onlineIds, setOnlineIds] = useState([]); const avatarInputRef = useRef(null);
  const [receipts, setReceipts] = useState([]); const [presenceMap, setPresenceMap] = useState({}); const [conversationStates, setConversationStates] = useState({}); const [showArchived, setShowArchived] = useState(false); const [typingIds, setTypingIds] = useState([]); const [mediaUrls, setMediaUrls] = useState({}); const mediaUrlExpiryRef = useRef({}); const [isRecording, setIsRecording] = useState(false); const recorderRef = useRef(null); const recordedChunksRef = useRef([]); const mediaInputRef = useRef(null); const [mfaSetup, setMfaSetup] = useState(null); const [mfaEnabled, setMfaEnabled] = useState(false); const [mfaRequired, setMfaRequired] = useState(false); const [mfaCode, setMfaCode] = useState(''); const [mfaFactorId, setMfaFactorId] = useState(null); const [mfaChallengeId, setMfaChallengeId] = useState(null); const mediaFailRef = useRef({}); const skipScrollRef = useRef(false); const [hasMore, setHasMore] = useState(false); const [loadingOlder, setLoadingOlder] = useState(false); const messagesRef = useRef([]); const markedReadRef = useRef(new Set()); const typedRef = useRef(false); const [userQuery, setUserQuery] = useState(''); const [blockedUsers, setBlockedUsers] = useState([]); const [pushEnabled, setPushEnabled] = useState(false); const [showGroupInfo, setShowGroupInfo] = useState(false); const [groupMembers, setGroupMembers] = useState([]); const [groupInfoTitle, setGroupInfoTitle] = useState(''); const [addQuery, setAddQuery] = useState(''); const [addResults, setAddResults] = useState([]); const streamRef = useRef(null); const recordStartRef = useRef(0); const groupAvatarRef = useRef(null); const [outbox, setOutbox] = useState([]); const [hiddenIds, setHiddenIds] = useState([]); const [favorites, setFavorites] = useState([]); const [favoriteJumpId, setFavoriteJumpId] = useState(null); const [selectMode, setSelectMode] = useState(false); const [selectedIds, setSelectedIds] = useState([]); const [forwardMsgs, setForwardMsgs] = useState(null); const [showEmoji, setShowEmoji] = useState(false); const [inChatQuery, setInChatQuery] = useState(''); const [showInChatSearch, setShowInChatSearch] = useState(false); const [searchHits, setSearchHits] = useState([]); const [showGallery, setShowGallery] = useState(false); const [galleryItems, setGalleryItems] = useState([]); const [notifs, setNotifs] = useState([]); const [unreadNotifCount, setUnreadNotifCount] = useState(0); const [pollForm, setPollForm] = useState(null); const [polls, setPolls] = useState({}); const [pollVotes, setPollVotes] = useState([]); const [pollTick, setPollTick] = useState(0); const [readersFor, setReadersFor] = useState(null); const [inviteCode, setInviteCode] = useState(null); const [exporting, setExporting] = useState(false); const [pwForm, setPwForm] = useState(null);
  const bottomRef = useRef(null); const active = conversations.find(c => c.id === activeId);
  const [memberSheet, setMemberSheet] = useState(null); const [joinRequests, setJoinRequests] = useState([]); const [descDraft, setDescDraft] = useState(''); const [mentionQuery, setMentionQuery] = useState(null); const swipeRef = useRef(null);
  messagesRef.current = messages; const conversationsRef0 = useRef([]); conversationsRef0.current = conversations;
  const isBlocked = blockedUsers.some(b => b.id === active?.otherId);
  const isGroupAdmin = groupMembers.some(m => m.id === session?.user?.id && m.role === 'admin');
  const canPost = !active?.is_group || !active.only_admins_send || active.myRole === 'admin';
  const canPin = !active?.is_group || active?.myRole === 'admin';
  const favIds = useMemo(() => new Set(favorites.map(f => f.message_id)), [favorites]);
  // Kişiler sekmesi yalnızca gerçekten sohbet edilen bireysel hesapları gösterir.
  // Grup sohbetleri ve kişinin kendi not sohbeti burada tekrarlanmaz.
  const contactConversations = useMemo(() => {
    const seen = new Set();
    return (conversations || []).filter(c => {
      if (c.is_group || c.isSelf || !c.otherId || seen.has(c.otherId)) return false;
      seen.add(c.otherId); return true;
    }).sort((a, b) => new Date(b.lastMessage?.created_at || b.created_at || 0) - new Date(a.lastMessage?.created_at || a.created_at || 0));
  }, [conversations]);
  const pendingMsgs = useMemo(() => (session?.user?.id && activeId) ? outbox.filter(o => o.conversation_id === activeId).map(o => ({ id: o.id, conversation_id: o.conversation_id, sender_id: session.user.id, content: o.content, reply_to: o.reply_to, created_at: o.created_at, pending: true })) : [], [outbox, activeId, session?.user?.id]);
  const visibleMessages = useMemo(() => {
    const hidden = new Set(hiddenIds); const q = inChatQuery.trim().toLowerCase();
    return [...messages, ...pendingMsgs].filter(m => !hidden.has(m.id) && (!q || String(m.content || '').toLowerCase().includes(q)));
  }, [messages, pendingMsgs, hiddenIds, inChatQuery]);
  const pinnedMessage = useMemo(() => [...messages].reverse().find(m => m.pinned_at && !m.deleted_at) || null, [messages]);
  useEffect(() => { setJoinRequests([]); setMentionQuery(null); if (!activeId) return; const c = conversationsRef0.current.find(x => x.id === activeId); if (c?.is_group) { loadGroupMembers(activeId); if (c.myRole === 'admin') loadJoinRequests(activeId); } }, [activeId]);
  const mentionOptions = mentionQuery === null ? [] : [
    ...('herkes'.startsWith(mentionQuery) && groupMembers.length > 1 ? [{ id: '__all__', username: 'herkes', display_name: 'Herkes', isAll: true }] : []),
    ...groupMembers.filter(u => u.id !== session?.user?.id && `${u.username} ${u.display_name || ''}`.toLowerCase().includes(mentionQuery))
  ].slice(0, 7);
  // Sekme başlığı: okunmamış sohbet sayısı, örn. (3) madem
  const [tabVisible, setTabVisible] = useState(() => document.visibilityState === 'visible');
  useEffect(() => { const h = () => setTabVisible(document.visibilityState === 'visible'); document.addEventListener('visibilitychange', h); return () => document.removeEventListener('visibilitychange', h); }, []);
  const unreadChatCount = useMemo(() => conversations.filter(c => c.unread && !c.userState?.archived_at && !(c.userState?.muted_until && new Date(c.userState.muted_until) > new Date()) && !(c.id === activeId && tabVisible)).length, [conversations, activeId, tabVisible]);
  useEffect(() => { document.title = unreadChatCount > 0 ? `(${unreadChatCount}) madem` : 'madem — Mesajlaşma'; }, [unreadChatCount]);
  useEffect(() => () => { document.title = 'madem — Mesajlaşma'; }, []);
  // Okunmamış @ bahsetmeleri: sonradan başka mesaj gelse bile sohbet açılana kadar rozet kalır
  useEffect(() => {
    try { navigator.storage?.persist?.(); } catch {}
    const clearNotifications = () => {
      if (document.visibilityState !== 'visible') return;
      try { navigator.clearAppBadge?.(); } catch {}
      navigator.serviceWorker?.ready.then(reg => reg.getNotifications()).then(list => list.forEach(n => n.close())).catch(() => {});
    };
    clearNotifications();
    document.addEventListener('visibilitychange', clearNotifications); window.addEventListener('focus', clearNotifications);
    return () => { document.removeEventListener('visibilitychange', clearNotifications); window.removeEventListener('focus', clearNotifications); };
  }, []);
  const [mentionedIds, setMentionedIds] = useState([]);
  const myUsernameRef = useRef(null); myUsernameRef.current = profile?.username;
  const activeIdRef = useRef(null); activeIdRef.current = activeId;
  useEffect(() => { if (activeId) setMentionedIds(ids => ids.includes(activeId) ? ids.filter(id => id !== activeId) : ids); }, [activeId]);
  // Okunmamış mesaj ayracı: sohbet açılınca okundu işaretlenmeden önce ilk okunmamış mesaj bulunur
  const [unreadAnchor, setUnreadAnchor] = useState(null);
  const [anchorReadyFor, setAnchorReadyFor] = useState(null);
  useEffect(() => { setUnreadAnchor(null); setAnchorReadyFor(null); }, [activeId]);
  useEffect(() => {
    if (!activeId || !session?.user?.id || anchorReadyFor === activeId) return;
    const mine = messages.filter(m => m.conversation_id === activeId);
    if (!mine.length) { const t = setTimeout(() => setAnchorReadyFor(activeId), 4000); return () => clearTimeout(t); }
    let cancelled = false;
    const candidates = mine.filter(m => m.sender_id !== session.user.id && !m.deleted_at).sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    (async () => {
      let anchor = null;
      if (candidates.length) {
        const { data, error } = await supabase.from('message_receipts').select('message_id, read_at').eq('user_id', session.user.id).in('message_id', candidates.map(m => m.id));
        if (!error) {
          const readIds = new Set((data || []).filter(r => r.read_at).map(r => r.message_id));
          const unread = candidates.filter(m => !readIds.has(m.id));
          if (unread.length) anchor = { id: unread[0].id, count: unread.length };
        }
      }
      if (cancelled) return;
      setUnreadAnchor(anchor); setAnchorReadyFor(activeId);
      if (anchor) setTimeout(() => document.getElementById('unread-divider')?.scrollIntoView({ block: 'center' }), 250);
    })();
    return () => { cancelled = true; };
  }, [activeId, messages, anchorReadyFor, session?.user?.id]);
  const mutedNow = Boolean(active?.userState?.muted_until && new Date(active.userState.muted_until) > new Date());

  // Taslaklar: sohbet başına yerel depolama
  function updateDraft(value) {
    typedRef.current = true; setDraft(value);
    if (!draftKey) return;
    try { value ? localStorage.setItem(draftKey, value) : localStorage.removeItem(draftKey); } catch {}
  }
  useEffect(() => {
    let v = ''; if (draftKey) { try { v = localStorage.getItem(draftKey) || ''; } catch {} }
    typedRef.current = false; setDraft(v);
  }, [draftKey]);

  // Android FCM: bildirime dokununca sohbeti aç (uygulama kapalıyken bile), girişte token'ı kaydet
  const [pendingConv, setPendingConv] = useState(null);
  useEffect(() => registerFCMNotificationOpenHandler(setPendingConv), []);
  useEffect(() => { if (pendingConv && session?.user?.id) { setSection('chats'); setActiveId(pendingConv); setPendingConv(null); } }, [pendingConv, session?.user?.id]);
  useEffect(() => {
    if (!session?.user?.id || !isNativeAndroid()) return;
    autoRegisterAndroidPush().then(ok => setPushEnabled(Boolean(ok))).catch(e => console.warn('FCM', e));
  }, [session?.user?.id]);

  // Bildirime tıklayınca sohbeti aç (service worker mesajı veya ?c= bağlantısı)
  useEffect(() => {
    const onMsg = e => { if (e.data?.type === 'open-conversation' && e.data.conversationId) { setSection('chats'); setActiveId(e.data.conversationId); } };
    navigator.serviceWorker?.addEventListener('message', onMsg);
    return () => navigator.serviceWorker?.removeEventListener('message', onMsg);
  }, []);
  useEffect(() => {
    if (!session?.user?.id) return;
    const c = new URLSearchParams(location.search).get('c');
    if (c) { setActiveId(c); history.replaceState(null, '', location.pathname); }
  }, [session?.user?.id]);

  // Engellenen kullanıcılar
  const loadBlocked = useCallback(async () => {
    if (!session?.user?.id) { setBlockedUsers([]); return; }
    const { data: rows } = await supabase.from('user_blocks').select('blocked_id').eq('blocker_id', session.user.id);
    const ids = (rows || []).map(r => r.blocked_id);
    if (!ids.length) { setBlockedUsers([]); return; }
    const { data: ps } = await supabase.from('profiles').select('id,username,display_name,avatar_url').in('id', ids);
    setBlockedUsers(ps || []);
  }, [session?.user?.id]);
  useEffect(() => { loadBlocked(); }, [loadBlocked]);

  // Kendimden silinenler + favoriler
  useEffect(() => {
    if (!session?.user?.id) { setHiddenIds([]); setFavorites([]); return; }
    const uid0 = session.user.id; const c0 = cacheGet(uid0, 'favs'); if (c0) { setHiddenIds(c0.h || []); setFavorites(c0.f || []); }
    (async () => {
      const [{ data: h, error: hErr }, { data: f, error: fErr }] = await Promise.all([
        supabase.from('message_hidden').select('message_id'),
        supabase.from('message_favorites').select('message_id,created_at,messages(id,conversation_id,content,message_type,created_at,sender_id)').order('created_at', { ascending: false })
      ]);
      if (hErr || fErr) return;
      const hid = (h || []).map(x => x.message_id); setHiddenIds(hid); setFavorites(f || []); cacheSet(uid0, 'favs', { h: hid, f: f || [] });
    })();
  }, [session?.user?.id]);

  // Sohbet değişince seçim/arama durumunu sıfırla
  useEffect(() => { setSelectMode(false); setSelectedIds([]); setShowInChatSearch(false); setInChatQuery(''); setShowEmoji(false); }, [activeId]);

  // Davet bağlantısı ile gruba katıl (?join=kod)
  useEffect(() => {
    if (!session?.user?.id) return;
    const code = new URLSearchParams(location.search).get('join');
    if (!code) return;
    history.replaceState(null, '', location.pathname);
    (async () => {
      const { data, error: e } = await supabase.rpc('join_group_by_invite', { invite: code });
      if (e) { setError(e.message); return; }
      if (!data) { setError('Katılma isteğin yöneticilere gönderildi. Onaylanınca gruba eklenirsin.'); return; }
      await loadConversationsRef.current?.(); setSection('chats'); setActiveId(data); setError('Gruba katıldın.');
    })();
  }, [session?.user?.id]);

  // Tüm sohbetlerde mesaj araması
  useEffect(() => {
    const t = query.trim();
    if (section !== 'chats' || t.length < 2) { setSearchHits([]); return; }
    let alive = true;
    const id = setTimeout(async () => { const { data } = await supabase.rpc('search_messages', { term: t }); if (alive) setSearchHits(data || []); }, 350);
    return () => { alive = false; clearTimeout(id); };
  }, [query, section]);

  // Bildirim merkezi: sayfa açıkken yeni bildirimleri gerçek zamanlı yenile.
  useEffect(() => {
    const uid = session?.user?.id;
    if (section !== 'notifications' || !uid) return;
    let alive = true;
    const refresh = async () => {
      const { data, error: loadError } = await supabase.from('notifications').select('*')
        .eq('user_id', uid).neq('kind', 'call').order('created_at', { ascending: false }).limit(60);
      if (!alive) return;
      if (loadError) { setError('Bildirimler yüklenemedi. Bağlantını kontrol edip tekrar dene.'); return; }
      setNotifs(data || []);
    };
    refresh();
    const channel = supabase.channel(`madem-notification-list-${uid}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${uid}` }, refresh)
      .subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [section, session?.user?.id]);

  // Anketler
  const pollKey = messages.filter(m => m.message_type === 'poll').map(m => m.id).join(',');
  useEffect(() => {
    if (!pollKey) { setPolls({}); setPollVotes([]); return; }
    let alive = true;
    const load = async () => {
      const ids = pollKey.split(',');
      const { data: ps } = await supabase.from('polls').select('id,message_id,question,multiple,poll_options(id,label,position)').in('message_id', ids);
      const pids = (ps || []).map(p => p.id);
      const { data: vs } = pids.length ? await supabase.from('poll_votes').select('poll_id,option_id,user_id').in('poll_id', pids) : { data: [] };
      if (!alive) return;
      setPolls(Object.fromEntries((ps || []).map(p => [p.message_id, { ...p, options: [...(p.poll_options || [])].sort((a, b) => a.position - b.position) }])));
      setPollVotes(vs || []);
    };
    load();
    const ch = supabase.channel(`polls-${activeId}-${pollKey.length}`).on('postgres_changes', { event: '*', schema: 'public', table: 'poll_votes' }, load).subscribe();
    return () => { alive = false; supabase.removeChannel(ch); };
  }, [pollKey, activeId, pollTick]);

  // Yeni sohbet penceresi kendi arama kutusunu kullanır
  useEffect(() => { if (showNew || section === 'contacts') setUserQuery(''); }, [showNew, section]);

  // Grup üye ekleme araması
  useEffect(() => {
    if (!showGroupInfo || addQuery.trim().length < 2) { setAddResults([]); return; }
    const t = setTimeout(async () => {
      const term = addQuery.trim().replace(/[^a-zA-Z0-9_]/g, '');
      if (term.length < 2) return;
      const { data } = await supabase.from('profiles').select('id,username,display_name,avatar_url').ilike('username', `%${term.replace(/_/g, '\\_')}%`).limit(8);
      setAddResults((data || []).filter(x => !groupMembers.some(m => m.id === x.id)));
    }, 250);
    return () => clearTimeout(t);
  }, [showGroupInfo, addQuery, groupMembers]);

  // Web Push abonelik durumu
  useEffect(() => {
    if (isNativeAndroid() || !('serviceWorker' in navigator) || !('PushManager' in window)) return;
    navigator.serviceWorker.ready.then(r => r.pushManager.getSubscription()).then(sub => { setPushEnabled(Boolean(sub)); const j = sub?.toJSON?.(); if (j?.endpoint && j.keys?.p256dh && j.keys?.auth) supabase.rpc('claim_push_subscription', { p_endpoint: j.endpoint, p_p256dh: j.keys.p256dh, p_auth: j.keys.auth }).then(() => {}, () => {}); }).catch(() => {});
  }, [session?.user?.id]);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => { setSession(data.session || readStoredSession()); setAuthReady(true); }).catch(() => { setSession(readStoredSession()); setAuthReady(true); });
    // Geçici null oturumlar (yenileme sırasında) kullanıcıyı atmasın: yalnızca gerçek çıkışta oturumu temizle.
    const { data: listener } = supabase.auth.onAuthStateChange((event, next) => {
      if (next) setSession(next);
      else if (event === 'SIGNED_OUT') setSession(null);
    });
    const onVis = () => { if (document.visibilityState === 'visible') { supabase.auth.startAutoRefresh(); supabase.auth.getSession(); } else supabase.auth.stopAutoRefresh(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { listener.subscription.unsubscribe(); document.removeEventListener('visibilitychange', onVis); };
  }, []);

  useEffect(() => {
    if (!session?.user?.id) { setOnlineIds([]); return; }
    const channel = supabase.channel('madem-presence', { config: { presence: { key: session.user.id } } });
    channel.on('presence', { event: 'sync' }, () => {
      const state = channel.presenceState();
      const ids = Object.values(state).flat().map((entry) => entry.user_id).filter(Boolean);
      setOnlineIds([...new Set(ids)]);
    }).subscribe(async status => {
      if (status === 'SUBSCRIBED') { await channel.track({ user_id: session.user.id, online_at: new Date().toISOString() }); await supabase.from('user_presence').upsert({ user_id: session.user.id, is_online: true, last_seen_at: new Date().toISOString(), updated_at: new Date().toISOString() }); }
    });
    return () => { supabase.from('user_presence').upsert({ user_id: session.user.id, is_online: false, last_seen_at: new Date().toISOString(), updated_at: new Date().toISOString() }); supabase.removeChannel(channel); };
  }, [session?.user?.id]);

  useEffect(() => {
    if (!session?.user?.id) return;
    const beat = (forceOffline = false) => { const now = new Date().toISOString(); supabase.from('user_presence').upsert({ user_id: session.user.id, is_online: !forceOffline && document.visibilityState === 'visible', last_seen_at: now, updated_at: now }); };
    const timer = setInterval(() => beat(), 45000);
    const onVis = () => beat();
    const onHide = () => beat(true);
    document.addEventListener('visibilitychange', onVis); window.addEventListener('pagehide', onHide);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', onVis); window.removeEventListener('pagehide', onHide); };
  }, [session?.user?.id]);

  const loadProfile = useCallback(async () => {
    if (!session?.user) return;
    const { data, error: err } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (err) setError(err.message); else { setProfile(data); setProfileName(data?.display_name || ''); setProfileBio(data?.bio || ''); }
  }, [session?.user?.id]);

  const loadConversations = useCallback(async () => {
    if (!session?.user) return;
    const { data: memberships, error: err } = await supabase.from('conversation_members').select('conversation_id, role').eq('user_id', session.user.id);
    if (err) { if (navigator.onLine) setError(err.message); return; }
    if (!memberships?.length) { setConversations([]); return; }
    const ids = memberships.map(m => m.conversation_id);
    const [{ data: convs, error: ce }, { data: members, error: me }, { data: states }] = await Promise.all([
      supabase.from('conversations').select('*').in('id', ids).order('created_at', { ascending: false }),
      supabase.from('conversation_members').select('conversation_id, user_id').in('conversation_id', ids),
      supabase.from('conversation_user_state').select('*').eq('user_id', session.user.id).in('conversation_id', ids)
    ]);
    setConversationStates(Object.fromEntries((states || []).map(x => [x.conversation_id, x])));
    if (ce || me) { setError((ce || me).message); return; }
    const otherIds = [...new Set((members || []).filter(m => m.user_id !== session.user.id).map(m => m.user_id))];
    const [{ data: profiles }, { data: presenceRows }] = await Promise.all([
      otherIds.length ? supabase.from('profiles').select('id, username, display_name, avatar_url').in('id', otherIds) : Promise.resolve({ data: [] }),
      otherIds.length ? supabase.from('user_presence').select('user_id,is_online,last_seen_at').in('user_id', otherIds) : Promise.resolve({ data: [] })
    ]);
    setPresenceMap(Object.fromEntries((presenceRows || []).map(row => [row.user_id, row])));
    const pmap = Object.fromEntries((profiles || []).map(p => [p.id, p]));
    // Prefer the indexed database summary RPC (one round-trip). If it has not
    // been applied yet, fall back to batched queries so the app still works.
    let summaryRows = null;
    const { data: rpcRows, error: rpcError } = await supabase.rpc('madem_conversation_summaries', { conversation_ids: ids });
    if (!rpcError && Array.isArray(rpcRows)) {
      summaryRows = rpcRows;
    } else {
      const { data: recentMessages, error: messagesError } = await supabase.from('messages')
        .select('id, conversation_id, content, created_at, sender_id, message_type')
        .in('conversation_id', ids).order('created_at', { ascending: false });
      if (messagesError) { setError(messagesError.message); return; }
      const latestByConversation = new Map();
      for (const message of (recentMessages || [])) {
        if (!latestByConversation.has(message.conversation_id)) latestByConversation.set(message.conversation_id, message);
      }
      const lastIds = [...latestByConversation.values()].filter(m => m.sender_id !== session.user.id).map(m => m.id);
      const { data: readRows } = lastIds.length ? await supabase.from('message_receipts').select('message_id, read_at').eq('user_id', session.user.id).in('message_id', lastIds) : { data: [] };
      const readByMessage = new Map((readRows || []).map(row => [row.message_id, row.read_at]));
      summaryRows = (convs || []).map(c => {
        const last = latestByConversation.get(c.id) || null;
        return { conversation_id: c.id, last_message_id: last?.id ?? null, last_content: last?.content ?? null, last_created_at: last?.created_at ?? null, last_sender_id: last?.sender_id ?? null, last_message_type: last?.message_type ?? null, last_read_at: last ? (readByMessage.get(last.id) ?? null) : null };
      });
    }
    const summaryByConversation = new Map((summaryRows || []).map(row => [row.conversation_id, row]));
    const result = (convs || []).map(c => {
      const cm = (members || []).filter(m => m.conversation_id === c.id);
      const other = cm.find(m => m.user_id !== session.user.id);
      const isSelf = !c.is_group && !other;
      const person = isSelf ? pmap[session.user.id] : other ? pmap[other.user_id] : null;
      const summary = summaryByConversation.get(c.id) || {};
      const last = summary.last_message_id ? { id: summary.last_message_id, content: summary.last_content, created_at: summary.last_created_at, sender_id: summary.last_sender_id, message_type: summary.last_message_type } : null;
      const clearedAt = (states || []).find(x => x.conversation_id === c.id)?.deleted_at; const lastShown = last && clearedAt && new Date(last.created_at) <= new Date(clearedAt) ? null : last;
      return { ...c, myRole: memberships.find(x => x.conversation_id === c.id)?.role, memberIds: cm.map(m => m.user_id), unread: Boolean(lastShown && lastShown.sender_id !== session.user.id && !summary.last_read_at), hasUnreadMention: Boolean(summary.has_unread_mention), otherId: other?.user_id, isSelf, person, titleText: c.is_group ? (c.title || 'Yeni grup') : isSelf ? `${person?.display_name || person?.username || 'Ben'} (Siz)` : (person?.display_name || person?.username || 'Sohbet'), lastMessage: lastShown, userState: (states || []).find(x => x.conversation_id === c.id) || {} };
    });
    result.sort((a, b) => new Date(b.lastMessage?.created_at || b.created_at) - new Date(a.lastMessage?.created_at || a.created_at));
    setConversations(result); cacheSet(session.user.id, 'convs', result);
    if (activeId && !result.some(c => c.id === activeId)) setActiveId(null);
  }, [session?.user?.id, activeId]);

  useEffect(() => { if (session?.user?.id) { const c = cacheGet(session.user.id, 'convs'); if (c) setConversations(prev => prev.length ? prev : c); } }, [session?.user?.id]);
  useEffect(() => { if (session?.user?.id) { loadProfile(); loadConversations(); } else { setProfile(null); setConversations([]); setActiveId(null); } }, [session?.user?.id, loadProfile, loadConversations]);

  // Mavi okunmamış noktası yalnızca okundu bilgisi sunucuya kaydedilince temizlenir.

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('madem-theme', themePref); } catch { /* Depolama kapalıysa arayüz yine açılmalı. */ }
  }, [theme, themePref]);
  // "Sistem" seçiliyken cihazın açık/koyu ayarı değişince arayüz de anında değişsin.
  useEffect(() => {
    let mq; try { mq = window.matchMedia('(prefers-color-scheme: dark)'); } catch { return; }
    const onChange = e => setSystemDark(e.matches);
    setSystemDark(mq.matches);
    mq.addEventListener?.('change', onChange);
    return () => mq.removeEventListener?.('change', onChange);
  }, []);

  // Okunmamış bildirim sayısı menüde de görünür; bildirim sayfasını açmak gerekmez.
  useEffect(() => {
    const uid = session?.user?.id;
    if (!uid) { setUnreadNotifCount(0); return; }
    let alive = true;
    const refreshUnread = async () => {
      const { count, error: countError } = await supabase.from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid).is('read_at', null).neq('kind', 'call');
      if (alive && !countError) setUnreadNotifCount(count || 0);
    };
    refreshUnread();
    const channel = supabase.channel(`madem-unread-notifications-${uid}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${uid}` }, refreshUnread)
      .subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [session?.user?.id]);

  useEffect(() => {
    if (!activeId || !session) { setMessages([]); setReactions([]); return; }
    let alive = true;
    const mc = cacheGet(session.user.id, `msgs:${activeId}`); if (mc) { setMessages(mc.m || []); setReactions(mc.r || []); setMessageAuthors(mc.a || {}); }
    async function fetchMessages() {
      const { data: rawRows, error: err } = await supabase.from('messages').select('*').eq('conversation_id', activeId).order('created_at', { ascending: false }).limit(PAGE_SIZE);
      const data = rawRows ? [...rawRows].reverse() : rawRows;
      if (alive) setHasMore((rawRows || []).length >= PAGE_SIZE);
      const ids = [...new Set((data || []).map(m => m.sender_id))];
      const [{ data: reactionData }, { data: authorData }] = await Promise.all([
        (data || []).length ? supabase.from('message_reactions').select('*').in('message_id', data.map(m => m.id)) : Promise.resolve({ data: [] }),
        ids.length ? supabase.from('profiles').select('id,username,display_name,avatar_url').in('id', ids) : Promise.resolve({ data: [] })
      ]);
      if (alive) { if (err) { if (navigator.onLine) setError(err.message); } else { setMessages(data || []); setReactions(reactionData || []); setMessageAuthors(Object.fromEntries((authorData || []).map(p => [p.id,p]))); } }
    }
    fetchMessages();
    const channel = supabase.channel(`messages-${activeId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `conversation_id=eq.${activeId}` }, payload => {
      if (payload.eventType === 'INSERT') { setMessages(prev => prev.some(m => m.id === payload.new.id) ? prev : [...prev, payload.new]); if (payload.new.sender_id !== session.user.id) { supabase.from('profiles').select('id,username,display_name,avatar_url').eq('id', payload.new.sender_id).maybeSingle().then(({ data: author }) => { if (author) setMessageAuthors(prev => ({ ...prev, [author.id]: author })); }); }  }
      else if (payload.eventType === 'UPDATE') setMessages(prev => prev.map(m => m.id === payload.new.id ? payload.new : m));
      else if (payload.eventType === 'DELETE') setMessages(prev => prev.filter(m => m.id !== payload.old.id));
      scheduleLoadConversations();
    }).on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions' }, payload => {
      if (payload.eventType === 'INSERT' && messagesRef.current.some(m => m.id === payload.new.message_id)) setReactions(prev => prev.some(r => r.id === payload.new.id) ? prev : [...prev, payload.new]);
      if (payload.eventType === 'DELETE') setReactions(prev => prev.filter(r => r.id !== payload.old.id));
    }).subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [activeId, session?.user?.id, loadConversations]);
  useEffect(() => { if (!activeId || !session?.user?.id || !messages.length || !messages.every(m => m.conversation_id === activeId)) return; cacheSet(session.user.id, `msgs:${activeId}`, { m: messages.slice(-500), r: reactions, a: messageAuthors }); }, [messages, reactions, messageAuthors, activeId, session?.user?.id]);
  useEffect(() => { if (skipScrollRef.current) { skipScrollRef.current = false; return; } bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  useEffect(() => { if (!favoriteJumpId || !messages.length) return; const el = document.getElementById(`message-${favoriteJumpId}`); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('message-highlight'); setTimeout(() => el.classList.remove('message-highlight'), 1600); setFavoriteJumpId(null); } else if (messages[0]?.conversation_id === activeId) { if (hasMore && !loadingOlder) loadOlder(); else if (!hasMore) setFavoriteJumpId(null); } }, [messages, favoriteJumpId, hasMore, loadingOlder, activeId]);

  const convIdsKey = conversations.map(c => c.id).sort().join(',');
  const conversationsRef = useRef(conversations); conversationsRef.current = conversations;
  const loadConversationsRef = useRef(null); loadConversationsRef.current = loadConversations;
  // Gelen her mesajda üst üste tam yeniden yükleme yapmamak için birleştirilmiş (debounce) yenileme.
  const loadConvTimerRef = useRef(null);
  const scheduleLoadConversations = useCallback(() => {
    clearTimeout(loadConvTimerRef.current);
    loadConvTimerRef.current = setTimeout(() => loadConversationsRef.current?.(), 400);
  }, []);
  useEffect(() => () => clearTimeout(loadConvTimerRef.current), []);
  // Çevrimdışı gönderme kuyruğu: mesajlar cihazda bekler, internet gelince sırayla gönderilir.
  const flushingRef = useRef(false);
  const flushOutbox = useCallback(async () => {
    const uid = session?.user?.id;
    if (!uid || flushingRef.current || !navigator.onLine) return;
    let list = readOutbox(uid);
    if (!list.length) { setOutbox([]); return; }
    flushingRef.current = true;
    let sentAny = false;
    try {
      // FIFO gönderim: ağ veya izin hatasında öğeyi kuyrukta tut ve sırayı bozma.
      for (const item of [...list]) {
        if (!navigator.onLine) break;
        let err = null;
        try {
          ({ error: err } = await supabase.from('messages').insert({
            id: item.id,
            conversation_id: item.conversation_id,
            sender_id: uid,
            content: item.content,
            reply_to: item.reply_to || null,
            created_at: item.created_at,
          }));
        } catch (networkError) {
          // Supabase istemcisi bazı bağlantı kopmalarında hata nesnesi yerine
          // doğrudan TypeError fırlatabilir. Bu durumda kuyruğu asla temizleme.
          if (!navigator.onLine || /fetch|network|offline|timeout|load failed/i.test(networkError?.message || '')) break;
          setError(networkError?.message || 'Bekleyen mesaj gönderilemedi; kuyrukta korundu.');
          break;
        }
        // Aynı UUID daha önce sunucuya ulaştıysa bu, güvenli yeniden denemedir.
        if (err && err.code !== '23505') {
          if (err.code === '42501' || /row-level security|permission denied/i.test(err.message || '')) {
            setError('Bekleyen mesaj gönderilemedi: bu sohbete mesaj gönderme iznin olmayabilir. Mesaj kuyrukta korunuyor.');
          }
          break;
        }
        list = list.filter(x => x.id !== item.id);
        if (!writeOutbox(uid, list)) {
          // Sunucu kabul etti ama yerel kuyruk yazılamadıysa UUID tekrar denemede çift mesajı önler.
          setError('Mesaj gönderildi; cihaz kuyruğu güncellenemedi. Uygulamayı açık tutup yeniden dene.');
          break;
        }
        setOutbox(list);
        sentAny = true;
      }
    } catch (queueError) {
      console.warn('Mesaj kuyruğu korunarak durduruldu:', queueError?.message || queueError);
    } finally { flushingRef.current = false; }
    if (sentAny) loadConversationsRef.current?.();
  }, [session?.user?.id]);
  useEffect(() => {
    if (!session?.user?.id) { setOutbox([]); return; }
    setOutbox(readOutbox(session.user.id)); flushOutbox();
    const on = () => flushOutbox(); window.addEventListener('online', on); const t = setInterval(on, 15000);
    return () => { window.removeEventListener('online', on); clearInterval(t); };
  }, [session?.user?.id, flushOutbox]);
  useEffect(() => { if (pendingMsgs.length) bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [pendingMsgs.length]);
  // Background alerts for every conversation, not only the open chat.
  useEffect(() => {
    if (!session?.user?.id || !convIdsKey) return;
    const ids = convIdsKey.split(',');
    const channel = supabase.channel(`madem-notifications-${session.user.id}`);
    ids.forEach(conversationId => {
      channel.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` }, payload => {
        const message = payload.new;
        if (!message || message.sender_id === session.user.id) return;
        scheduleLoadConversations();
        if (message.message_type === 'text' && mentionsUser(message.content, myUsernameRef.current) && conversationsRef.current.find(c => c.id === message.conversation_id)?.is_group && !(activeIdRef.current === message.conversation_id && !document.hidden)) {
          setMentionedIds(ids => ids.includes(message.conversation_id) ? ids : [...ids, message.conversation_id]);
        }
        const soundConv = conversationsRef.current.find(c => c.id === message.conversation_id);
        if (!document.hidden && !(soundConv?.userState?.muted_until && new Date(soundConv.userState.muted_until) > new Date())) playMessageBeep();
        if (!document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
        const conv = conversationsRef.current.find(c => c.id === message.conversation_id);
        if (conv?.userState?.muted_until && new Date(conv.userState.muted_until) > new Date()) return;
        showSystemNotification(`${conv?.titleText || 'madem'} · yeni mesaj`, {
          body: previewText(message.content || 'Yeni medya gönderildi').slice(0, 120),
          tag: `madem-${message.conversation_id}`, icon: '/icons/icon-192.png', badge: '/icons/badge-96.png',
          data: { conversationId: message.conversation_id, kind: 'message' }
        });
      });
    });
    channel.subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [session?.user?.id, convIdsKey]);

  useEffect(() => {
    if ((!showNew && section !== 'contacts') || !session || userQuery.trim().length < 2) { setPeople([]); return; }
    const timer = setTimeout(async () => {
      const term = userQuery.trim().replace(/[^a-zA-Z0-9_]/g, '');
      if (term.length < 2) return;
      const { data } = await supabase.from('profiles').select('id, username, display_name, avatar_url, bio').neq('id', session.user.id).ilike('username', `%${term.replace(/_/g, '\\_')}%`).limit(12);
      setPeople(data || []);
    }, 250);
    return () => clearTimeout(timer);
  }, [showNew, section, userQuery, session]);

  useEffect(() => {
    if (!session?.user?.id) return;
    let alive = true;
    (async () => {
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const factor = (factors?.totp || []).find(f => f.status === 'verified');
      if (!alive) return;
      if (factor) {
        setMfaEnabled(true); setMfaFactorId(factor.id);
        const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
        if (alive && aal?.nextLevel === 'aal2' && aal?.currentLevel !== 'aal2') {
          const { data: challenge } = await supabase.auth.mfa.challenge({ factorId: factor.id });
          if (alive && challenge?.id) { setMfaChallengeId(challenge.id); setMfaRequired(true); }
        }
      }
    })();
    return () => { alive = false; };
  }, [session?.user?.id]);

  useEffect(() => {
    if (!activeId || !session?.user?.id) { setTypingIds([]); return; }
    const refreshTyping = async () => {
      const { data } = await supabase.from('typing_indicators').select('user_id,updated_at').eq('conversation_id', activeId).neq('user_id', session.user.id);
      setTypingIds((data || []).filter(x => Date.now() - new Date(x.updated_at).getTime() < 6000).map(x => x.user_id));
    };
    const channel = supabase.channel(`typing-${activeId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'typing_indicators', filter: `conversation_id=eq.${activeId}` }, refreshTyping).subscribe();
    const interval = setInterval(refreshTyping, 2500);
    refreshTyping();
    return () => { clearInterval(interval); supabase.removeChannel(channel); };
  }, [activeId, session?.user?.id]);

  useEffect(() => {
    if (!activeId || !session?.user?.id || !draft.trim() || !typedRef.current) return;
    const timer = setTimeout(() => supabase.from('typing_indicators').upsert({ conversation_id: activeId, user_id: session.user.id, updated_at: new Date().toISOString() }), 150);
    return () => clearTimeout(timer);
  }, [draft, activeId, session?.user?.id]);

  useEffect(() => {
    if (!messages.length || !session?.user?.id || !activeId || anchorReadyFor !== activeId) return;
    let cancelled = false;
    const markVisibleMessagesRead = async () => {
      if (document.visibilityState !== 'visible') return;
      const unread = messages.filter(m => m.sender_id !== session.user.id && !m.deleted_at && !markedReadRef.current.has(m.id));
      if (!unread.length) return;
      const now = new Date().toISOString();
      const { error: receiptError } = await supabase.from('message_receipts').upsert(
        unread.map(m => ({ message_id: m.id, user_id: session.user.id, delivered_at: now, read_at: now })),
        { onConflict: 'message_id,user_id', ignoreDuplicates: true }
      );
      if (!receiptError) unread.forEach(m => markedReadRef.current.add(m.id));
      if (!cancelled && !receiptError) {
        setConversations(prev => prev.map(c => c.id === activeId ? { ...c, unread: false } : c));
        await loadConversations();
      } else if (receiptError) {
        console.error('Mesaj okundu bilgisi kaydedilemedi:', receiptError.message);
      }
    };
    markVisibleMessagesRead();
    const onVisible = () => { if (document.visibilityState === 'visible') markVisibleMessagesRead(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    return () => { cancelled = true; document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('focus', onVisible); };
  }, [messages, activeId, anchorReadyFor, session?.user?.id, loadConversations]);

  useEffect(() => {
    if (!messages.length || !activeId || !session?.user?.id) { setReceipts([]); return; }
    let alive = true;
    const ids = messages.map(m => m.id);
    const refreshReceipts = async () => {
      const { data } = await supabase.from('message_receipts')
        .select('message_id,user_id,delivered_at,read_at').in('message_id', ids);
      if (alive) setReceipts(prev => mergeReceiptRows(prev, data || [], ids));
    };
    // Fetch immediately, then fetch once more after realtime is subscribed.
    // This closes the gap where a read update could happen between the query
    // and subscription becoming active.
    refreshReceipts();
    const channel = supabase.channel(`receipts-${activeId}`).on('postgres_changes', { event: '*', schema: 'public', table: 'message_receipts' }, payload => {
      if (payload.eventType === 'DELETE') setReceipts(prev => prev.filter(x => !(x.message_id === payload.old.message_id && x.user_id === payload.old.user_id)));
      else setReceipts(prev => mergeReceiptRows(prev, [payload.new], ids));
    }).subscribe(status => { if (status === 'SUBSCRIBED') refreshReceipts(); });
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [messages.map(m => m.id).join(','), activeId, session?.user?.id]);

  useEffect(() => {
    if (!messages.length) return;
    let alive = true;
    (async () => {
      const pending = messages.filter(m => m.media_path && (mediaFailRef.current[m.id] || 0) < Date.now() && (!mediaUrls[m.id] || (mediaUrlExpiryRef.current[m.id] || 0) < Date.now() + 60000));
      if (!pending.length) return;
      const entries = await Promise.all(pending.map(async m => {
        const { data } = await supabase.storage.from('madem-media').createSignedUrl(m.media_path, 3600, m.message_type === 'file' ? { download: m.content || true } : undefined);
        if (!data?.signedUrl) { mediaFailRef.current[m.id] = Date.now() + 30000; return null; }
        mediaUrlExpiryRef.current[m.id] = Date.now() + 55 * 60 * 1000; return [m.id, data.signedUrl];
      }));
      const okEntries = entries.filter(Boolean);
      if (alive && okEntries.length) setMediaUrls(prev => ({ ...prev, ...Object.fromEntries(okEntries) }));
    })();
    return () => { alive = false; };
  }, [messages, mediaUrls]);

  async function loadOlder() {
    if (!activeId || loadingOlder || !messages.length) return;
    setLoadingOlder(true);
    try {
      const { data: rows, error: oe } = await supabase.from('messages').select('*').eq('conversation_id', activeId).lt('created_at', messages[0].created_at).order('created_at', { ascending: false }).limit(PAGE_SIZE);
      if (oe) throw oe;
      const older = [...(rows || [])].reverse();
      setHasMore((rows || []).length >= PAGE_SIZE);
      if (!older.length) return;
      const [{ data: rx }, { data: au }] = await Promise.all([
        supabase.from('message_reactions').select('*').in('message_id', older.map(m => m.id)),
        supabase.from('profiles').select('id,username,display_name,avatar_url').in('id', [...new Set(older.map(m => m.sender_id))])
      ]);
      skipScrollRef.current = true;
      const prevH = streamRef.current?.scrollHeight || 0; setMessages(prev => { const seen = new Set(prev.map(m => m.id)); return [...older.filter(m => !seen.has(m.id)), ...prev]; }); setTimeout(() => { const el = streamRef.current; if (el) el.scrollTop += el.scrollHeight - prevH; }, 80);
      setReactions(prev => [...prev, ...(rx || []).filter(r => !prev.some(x => x.id === r.id))]);
      setMessageAuthors(prev => ({ ...prev, ...Object.fromEntries((au || []).map(x => [x.id, x])) }));
    } catch (e) { setError(e.message || 'Eski mesajlar yüklenemedi.'); }
    finally { setLoadingOlder(false); }
  }

  async function uploadMedia(file, kindOverride = null, duration = null) {
    if (!file || !activeId || !session?.user?.id) return;
    if (file.size <= 0) { setError('Boş dosya gönderilemez.'); return; }
    if (file.size > 50 * 1024 * 1024) { setError('Dosya boyutu 50 MB sınırını aşıyor.'); return; }
    const safeMime = getSafeMediaMime(file);
    if (!safeMime) { setError('Bu dosya türüne izin verilmiyor. Görsel, video, ses, PDF, metin veya yaygın Office dosyalarını seç.'); return; }
    const kind = kindOverride || (safeMime.startsWith('image/') ? 'image' : safeMime.startsWith('video/') ? 'video' : safeMime.startsWith('audio/') ? 'voice' : 'file');
    const item = { id: crypto.randomUUID(), user_id: session.user.id, conversation_id: activeId, blob: file, name: file.name || `${kind}-${Date.now()}.webm`, kind, mime: safeMime, size: file.size, duration, reply_to: replyTo?.id || null, created_at: new Date().toISOString() };
    if (!navigator.onLine) {
      try { await enqueueMedia(item); setError('Medya cihazda güvenle sıraya alındı; internet gelince gönderilecek.'); setReplyTo(null); }
      catch (e) { setError(`${e.message || 'Medya sıraya alınamadı.'} Dosya kaybolmasın diye uygulamayı kapatmadan tekrar dene.`); }
      finally { if (mediaInputRef.current) mediaInputRef.current.value = ''; }
      return;
    }
    setBusy(true);
    try {
      const safeName = item.name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0,100);
      const path = `${activeId}/${item.id}-${safeName}`;
      const { error: ue } = await supabase.storage.from('madem-media').upload(path, file, { contentType: item.mime, upsert: true });
      if (ue) throw ue;
      const { error: me } = await supabase.from('messages').insert({ id: item.id, conversation_id: activeId, sender_id: session.user.id, content: kind === 'voice' ? 'Sesli mesaj' : kind === 'image' ? 'Fotoğraf' : kind === 'video' ? 'Video' : item.name, message_type: kind, media_path: path, media_mime_type: item.mime, media_size_bytes: item.size, duration_seconds: duration, reply_to: item.reply_to });
      if (me && me.code !== '23505') throw me;
      setReplyTo(null);
    } catch (e) {
      if (!e?.code || e.code === 'FETCH_ERROR' || /network|fetch|timeout|offline/i.test(e.message || '')) {
        try { await enqueueMedia(item); setError('Bağlantı kesildi; medya cihazda sıraya alındı ve tekrar denenecek.'); }
        catch (qe) { setError(`${e.message || 'Dosya gönderilemedi.'} Medya kuyruğa da kaydedilemedi: ${qe.message || 'depolama hatası'}`); }
      } else setError(e.message || 'Dosya gönderilemedi.');
    } finally { setBusy(false); if (mediaInputRef.current) mediaInputRef.current.value = ''; }
  }

  const flushingMediaRef = useRef(false);
  const flushMediaOutbox = useCallback(async () => {
    const uid = session?.user?.id;
    if (!uid || !navigator.onLine || flushingMediaRef.current) return;
    flushingMediaRef.current = true;
    try {
      const items = await listQueuedMedia(uid);
      for (const item of items) {
        if (!navigator.onLine) break;
        if (!item?.blob || item.blob.size <= 0 || item.blob.size > 50 * 1024 * 1024 || !getSafeMediaMime({ name: item.name, type: item.mime || item.blob.type })) {
          setError('Bekleyen dosyalardan biri güvenlik kontrolünü geçemedi ve gönderilmedi.');
          await removeQueuedMedia(item.id);
          continue;
        }
        const safeName = String(item.name || 'dosya').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0,100);
        const path = `${item.conversation_id}/${item.id}-${safeName}`;
        const queuedMime = getSafeMediaMime({ name: item.name, type: item.mime || item.blob.type });
        const { error: ue } = await supabase.storage.from('madem-media').upload(path, item.blob, { contentType: queuedMime, upsert: true });
        if (ue) break;
        const { error: me } = await supabase.from('messages').insert({ id: item.id, conversation_id: item.conversation_id, sender_id: uid, content: item.kind === 'voice' ? 'Sesli mesaj' : item.kind === 'image' ? 'Fotoğraf' : item.kind === 'video' ? 'Video' : item.name, message_type: item.kind, media_path: path, media_mime_type: queuedMime, media_size_bytes: item.size, duration_seconds: item.duration, reply_to: item.reply_to || null, created_at: item.created_at });
        if (me && me.code !== '23505') break;
        await removeQueuedMedia(item.id);
      }
      loadConversationsRef.current?.();
    } catch (e) { console.warn('Bekleyen medya gönderilemedi:', e.message); }
    finally { flushingMediaRef.current = false; }
  }, [session?.user?.id]);
  useEffect(() => {
    if (!session?.user?.id) return;
    registerCurrentDeviceSession(session.user.id);
    flushMediaOutbox();
    const on = () => { flushMediaOutbox(); registerCurrentDeviceSession(session.user.id); };
    window.addEventListener('online', on);
    const timer = setInterval(flushMediaOutbox, 20000);
    return () => { window.removeEventListener('online', on); clearInterval(timer); };
  }, [session?.user?.id, flushMediaOutbox]);

  async function toggleRecording() {
    if (isRecording) { recorderRef.current?.stop(); setIsRecording(false); return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { setError('Bu tarayıcı ses kaydını desteklemiyor.'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const preferredMime = ['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(t => MediaRecorder.isTypeSupported?.(t));
      const recorder = new MediaRecorder(stream, preferredMime ? { mimeType: preferredMime } : undefined); recorderRef.current = recorder; recordedChunksRef.current = [];
      recorder.ondataavailable = e => { if (e.data.size) recordedChunksRef.current.push(e.data); };
      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(recordedChunksRef.current, { type: recorder.mimeType || 'application/octet-stream' });
        const ext = blob.type.includes('mp4') ? 'm4a' : blob.type.includes('ogg') ? 'ogg' : 'webm';
        const file = new File([blob], `ses-${Date.now()}.${ext}`, { type: blob.type });
        await uploadMedia(file, 'voice', Math.max(1, Math.round((Date.now() - recordStartRef.current) / 1000)));
      };
      recordStartRef.current = Date.now(); recorder.start(); setIsRecording(true);
    } catch (e) { setError(e.message || 'Mikrofon izni alınamadı.'); }
  }

  async function disableMfa() {
    if (!mfaFactorId || !(await askConfirm('İki aşamalı doğrulama kapatılsın mı? Hesabın yalnızca şifreyle korunacak.'))) return;
    const { error: e } = await supabase.auth.mfa.unenroll({ factorId: mfaFactorId });
    if (e) { setError(e.message || 'İki aşamalı doğrulama kapatılamadı.'); return; }
    setMfaEnabled(false); setMfaFactorId(null); setMfaSetup(null); setError('İki aşamalı doğrulama kapatıldı.');
  }
  async function enablePush() {
    if (window.Capacitor?.isNativePlatform?.()) {
      try { await registerAndroidPush(); setPushEnabled(true); setError('Android bildirimleri açıldı.'); }
      catch (e) { setError(e.message || 'Android bildirimleri açılamadı.'); }
      return;
    }
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) { setError('Bu tarayıcı arka plan bildirimini desteklemiyor.'); return; }
    const vapid = import.meta.env.VITE_VAPID_PUBLIC_KEY;
    if (!vapid) { setError('Web bildirimleri henüz yapılandırılmadı. Vercel ortam değişkenlerine VITE_VAPID_PUBLIC_KEY eklenip yeniden yayınlanmalı.'); return; }
    try {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') { setError('Bildirim izni verilmedi.'); return; }
      const reg = await navigator.serviceWorker.ready;
      const sub = (await reg.pushManager.getSubscription()) || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(vapid) });
      const j = sub.toJSON();
      const { error: e } = await supabase.rpc('claim_push_subscription', { p_endpoint: j.endpoint, p_p256dh: j.keys.p256dh, p_auth: j.keys.auth });
      if (e) throw e;
      setPushEnabled(true); setError('Arka plan bildirimleri açıldı.');
    } catch (e) { setError(e.message || 'Bildirim aboneliği oluşturulamadı.'); }
  }
  async function disablePush() {
    if (isNativeAndroid()) { try { await unregisterAndroidPush(); setPushEnabled(false); setError('Android bildirimleri kapatıldı.'); } catch (e) { setError(e.message || 'Bildirimler kapatılamadı.'); } return; }
    try {
      const reg = await navigator.serviceWorker.ready; const sub = await reg.pushManager.getSubscription();
      if (sub) { await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint); await sub.unsubscribe(); }
      setPushEnabled(false); setError('Arka plan bildirimleri kapatıldı.');
    } catch (e) { setError(e.message || 'Bildirimler kapatılamadı.'); }
  }
  async function confirmSignOut() { if (await askConfirm('Çıkış yapmak istiyor musun?')) signOut(); }

  async function loadGroupMembers(convId) {
    const { data: ms, error: e } = await supabase.from('conversation_members').select('user_id, role').eq('conversation_id', convId);
    if (e) { setError(e.message); return; }
    const ids = (ms || []).map(m => m.user_id);
    const { data: ps } = ids.length ? await supabase.from('profiles').select('id,username,display_name,avatar_url').in('id', ids) : { data: [] };
    const pm = Object.fromEntries((ps || []).map(x => [x.id, x]));
    setGroupMembers((ms || []).map(m => ({ ...(pm[m.user_id] || { id: m.user_id, username: 'bilinmiyor' }), role: m.role })));
  }
  function openGroupInfo() {
    if (!active?.is_group) return;
    setGroupInfoTitle(active.title || ''); setDescDraft(active.description || ''); setAddQuery(''); setAddResults([]); setGroupMembers([]); setShowGroupInfo(true); loadGroupMembers(active.id); setInviteCode(null); if (active.myRole === 'admin') { loadInvite(active.id); loadJoinRequests(active.id); }
  }
  async function renameGroup() {
    const t = groupInfoTitle.trim();
    if (!t || t.length > 80) { setError('Grup adı 1–80 karakter olmalı.'); return; }
    const { error: e } = await supabase.rpc('rename_group_conversation', { conv: active.id, new_title: t });
    if (e) setError(e.message); else { setError('Grup adı güncellendi.'); await loadConversations(); }
  }
  async function addGroupMember(person) {
    const { error: e } = await supabase.rpc('add_group_members', { conv: active.id, member_ids: [person.id] });
    if (e) { setError(e.message); return; }
    setAddQuery(''); await loadGroupMembers(active.id); await loadConversations();
  }
  async function removeGroupMember(person) {
    if (!(await askConfirm(`@${person.username} gruptan çıkarılsın mı?`))) return;
    const { error: e } = await supabase.rpc('remove_group_member', { conv: active.id, target: person.id });
    if (e) { setError(e.message); return; }
    await loadGroupMembers(active.id); await loadConversations();
  }
  async function leaveGroup() {
    if (!(await askConfirm('Gruptan ayrılmak istiyor musun?'))) return;
    const id = active.id;
    const { error: e } = await supabase.rpc('leave_group_conversation', { conv: id });
    if (e) { setError(e.message); return; }
    setShowGroupInfo(false); setActiveId(null); await loadConversations();
  }

  async function setConversationFlag(flag, forced) {
    if (!activeId || !session?.user?.id) return;
    const current = conversationStates[activeId] || {};
    const value = forced !== undefined ? forced : (current[flag] ? null : new Date().toISOString());
    const { error: e } = await supabase.from('conversation_user_state').upsert({ conversation_id: activeId, user_id: session.user.id, [flag]: value, updated_at: new Date().toISOString() }, { onConflict: 'conversation_id,user_id' });
    if (e) setError(e.message); else { setConversationStates(prev => ({ ...prev, [activeId]: { ...prev[activeId], [flag]: value } })); await loadConversations(); }
  }

  async function blockActiveUser() {
    if (!active?.otherId || !(await askConfirm(`@${active.person?.username || 'bu kullanıcı'} engellensin mi?`))) return;
    const { error: e } = await supabase.from('user_blocks').insert({ blocker_id: session.user.id, blocked_id: active.otherId });
    if (e && !String(e.message).includes('duplicate')) setError(e.message); else { setError('Kullanıcı engellendi.'); loadBlocked(); }
  }
  async function unblockUser(id) {
    const { error: e } = await supabase.from('user_blocks').delete().eq('blocker_id', session.user.id).eq('blocked_id', id);
    if (e) setError(e.message); else { setError('Engel kaldırıldı.'); loadBlocked(); }
  }


  async function setupMfa() {
    const { data, error: e } = await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'madem doğrulayıcı' });
    if (e) { setError(e.message); return; }
    setMfaSetup(data); setMfaFactorId(data.id);
  }
  async function verifyMfaSetup() {
    if (!mfaSetup?.id || mfaCode.length < 6) { setError('Doğrulama uygulamasındaki 6 haneli kodu gir.'); return; }
    const { data: challenge, error: ce } = await supabase.auth.mfa.challenge({ factorId: mfaSetup.id });
    if (ce) { setError(ce.message); return; }
    const { error: ve } = await supabase.auth.mfa.verify({ factorId: mfaSetup.id, challengeId: challenge.id, code: mfaCode });
    if (ve) { setError('Kod doğrulanamadı.'); return; }
    setMfaSetup(null); setMfaEnabled(true); setMfaCode(''); setMfaRequired(false); setError('İki aşamalı doğrulama etkinleştirildi.');
  }
  async function verifyMfaLogin() {
    if (!mfaFactorId || !mfaChallengeId || mfaCode.length < 6) { setError('6 haneli doğrulama kodunu gir.'); return; }
    const { error: e } = await supabase.auth.mfa.verify({ factorId: mfaFactorId, challengeId: mfaChallengeId, code: mfaCode });
    if (e) setError('Kod yanlış veya süresi dolmuş. Yeni bir kod dene.'); else { setMfaRequired(false); setMfaCode(''); }
  }
  async function deleteAccount() {
    if (!(await askConfirm('Hesabın, profilin ve hesaba bağlı verilerin kalıcı olarak silinecek. Devam etmek istiyor musun?'))) return;
    const { error: e } = await supabase.functions.invoke('madem-delete-account', { body: { confirm: true } });
    if (e) { setError(e.message || 'Hesap silinemedi.'); return; }
    cacheClearAll(); await supabase.auth.signOut(); setSession(null); setError('Hesabın kalıcı olarak silindi.');
  }

  async function sendMessage(e) {
    e.preventDefault(); const content = draft.trim(); if (!content || !activeId || !session) return;
    const messageId = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    const conversationId = activeId;
    const replyId = replyTo?.id || null;
    updateDraft('');
    const queueMsg = () => {
      const uid = session.user.id;
      const item = { id: messageId, conversation_id: conversationId, content, reply_to: replyId, created_at: createdAt };
      const existing = readOutbox(uid);
      if (existing.some(x => x.id === item.id)) { setOutbox(existing); return; }
      const list = [...existing, item];
      if (!writeOutbox(uid, list)) { updateDraft(content); setError('Cihaz depolaması dolu; mesaj kaydedilemedi. Depolama alanı açıp tekrar gönder.'); return; }
      setOutbox(list); setReplyTo(null);
    };
    if (!navigator.onLine) { queueMsg(); return; }
    try { await supabase.from('typing_indicators').delete().eq('conversation_id', conversationId).eq('user_id', session.user.id); } catch {}
    try {
      const { error: err } = await supabase.from('messages').insert({ id: messageId, conversation_id: conversationId, sender_id: session.user.id, content, reply_to: replyId, created_at: createdAt });
      if (err && err.code !== '23505' && (!err.code || err.code === 'FETCH_ERROR' || /fetch|network|offline|timeout/i.test(err.message || ''))) { queueMsg(); return; }
      if (err && err.code !== '23505') { updateDraft(content); setError(/row-level security/i.test(err.message) ? 'Mesaj gönderilemedi. Bu kullanıcıyla aranda engel olabilir.' : err.message); } else setReplyTo(null);
    } catch (networkError) {
      if (!navigator.onLine || /fetch|network|offline|timeout|load failed/i.test(networkError?.message || '')) { queueMsg(); return; }
      updateDraft(content);
      setError(networkError?.message || 'Mesaj gönderilemedi. Yazdığın metin taslakta korundu.');
    }
  }
  async function startChat(person) {
    setBusy(true); setError('');
    try {
      const existing = conversations.find(c => person.id === session.user.id ? c.isSelf : (!c.is_group && c.otherId === person.id));
      if (existing) { setActiveId(existing.id); setShowNew(false); setSection('chats'); return; }
      // The database RPC creates the conversation and both memberships atomically;
      // direct inserts from the browser are intentionally restricted by RLS.
      const { data: conversationId, error: ce } = await supabase.rpc('open_direct_conversation', { target_user_id: person.id });
      if (ce) throw ce;
      if (!conversationId) throw new Error('Sohbet oluşturulamadı. Lütfen tekrar dene.');
      setShowNew(false); setSection('chats'); setQuery('');
      await loadConversations();
      setActiveId(conversationId);
    } catch (err) { setError(err.message || 'Sohbet açılamadı.'); }
    finally { setBusy(false); }
  }
  async function createGroup() {
    if (!groupTitle.trim() || selectedPeople.length < 2) { setError('Grup adı ve en az iki kişi seçmelisin.'); return; }
    setBusy(true);
    try {
      // Create the group and all memberships atomically through a SECURITY DEFINER RPC;
      // browser-side inserts are blocked by the conversations table's RLS policies.
      const { data: conversationId, error: ce } = await supabase.rpc('create_group_conversation', {
        group_title: groupTitle.trim().slice(0, 80),
        member_ids: selectedPeople,
      });
      if (ce) throw ce;
      if (!conversationId) throw new Error('Grup oluşturulamadı. Lütfen tekrar dene.');
      setShowNew(false); setGroupMode(false); setSelectedPeople([]); setGroupTitle(''); setQuery(''); await loadConversations(); setActiveId(conversationId); setSection('chats');
    } catch (e) { setError(e.message || 'Grup oluşturulamadı.'); } finally { setBusy(false); }
  }
  async function toggleReaction(message, reaction) {
    const mine = reactions.find(r => r.message_id === message.id && r.user_id === session.user.id && r.reaction === reaction);
    if (mine) { const { error: e } = await supabase.from('message_reactions').delete().eq('id', mine.id); if (e) setError(e.message); }
    else { const { error: e } = await supabase.from('message_reactions').insert({ message_id: message.id, user_id: session.user.id, reaction }); if (e) setError(e.message); }
  }
  function editMessage(message) { setEditingMessage(message); setEditDraft(message.content || ''); }
  async function saveEditedMessage(event) {
    event.preventDefault();
    if (!editingMessage || messageActionBusy) return;
    const content = editDraft.trim();
    if (!content) { setError('Mesaj boş olamaz.'); return; }
    if (content.length > 10000) { setError('Mesaj en fazla 10.000 karakter olabilir.'); return; }
    setMessageActionBusy(true);
    const { error: updateError } = await supabase.from('messages').update({ content, edited_at: new Date().toISOString() }).eq('id', editingMessage.id).eq('sender_id', session.user.id);
    setMessageActionBusy(false);
    if (updateError) { setError(updateError.message); return; }
    setMessages(prev => prev.map(message => message.id === editingMessage.id ? { ...message, content, edited_at: new Date().toISOString() } : message));
    setEditingMessage(null); setEditDraft('');
    await loadConversations();
  }
  // Tarayıcının window.confirm penceresi yerine uygulama içi onay penceresi
  function askConfirm(text) { return new Promise(resolve => { confirmResolveRef.current?.(false); confirmResolveRef.current = resolve; setConfirmState({ text }); }); }
  function closeConfirm(result) { confirmResolveRef.current?.(result); confirmResolveRef.current = null; setConfirmState(null); }
  function deleteMessage(message) { setDeletingMessage(message); }
  // Dokununca yalnızca emoji; uzun basınca (veya sağ tık) emoji hariç diğer işlemler
  function openMessageMenu(id, mode) { setSelectedMessageMenu(prev => (prev === id && messageMenuMode === mode) ? null : id); setMessageMenuMode(mode); }
  function cancelLongPress() { clearTimeout(longPressRef.current.timer); longPressRef.current.timer = null; }
  function startLongPress(e, m) {
    if (m.pending || selectMode || e.button > 0) return;
    longPressRef.current.fired = false; longPressRef.current.x = e.clientX; longPressRef.current.y = e.clientY;
    cancelLongPress();
    longPressRef.current.timer = setTimeout(() => { longPressRef.current.fired = true; setSelectedMessageMenu(m.id); setMessageMenuMode('actions'); try { navigator.vibrate?.(15); } catch {} }, 450);
  }
  function moveLongPress(e) { if (longPressRef.current.timer && Math.hypot(e.clientX - longPressRef.current.x, e.clientY - longPressRef.current.y) > 10) cancelLongPress(); }
  async function confirmDeleteMessage() {
    if (!deletingMessage || messageActionBusy) return;
    setMessageActionBusy(true);
    const isOwnMessage = deletingMessage.sender_id === session.user.id;
    // Gönderen de yönetici de aynı sunucu RPC'sini kullanır; yetki kontrolü tek yerde yapılır.
    const { data: oldPath, error: deleteError } = await supabase.rpc('delete_message_for_everyone', { msg: deletingMessage.id });
    const path = oldPath || deletingMessage.media_path;
    if (!deleteError && path) {
      try { await supabase.storage.from('madem-media').remove([path]); }
      catch (storageError) { console.warn('Silinen mesajın medya dosyası temizlenemedi:', storageError); }
    }
    setMessageActionBusy(false);
    if (deleteError) { setError(deleteError.message); return; }
    setMessages(prev => prev.map(message => message.id === deletingMessage.id ? { ...message, content: isOwnMessage ? 'Bu mesaj silindi' : ADMIN_DELETED_TEXT, deleted_at: new Date().toISOString(), media_path: null, media_mime_type: null } : message));
    setDeletingMessage(null);
    await loadConversations();
  }
  async function saveProfile(e) {
    e.preventDefault(); const display_name = profileName.trim(); const bio = profileBio.trim();
    if (!display_name || display_name.length > 60 || bio.length > 300) { setError('Görünen ad 1–60, biyografi en fazla 300 karakter olmalı.'); return; }
    const { error: e2 } = await supabase.from('profiles').update({ display_name, bio, updated_at: new Date().toISOString() }).eq('id', session.user.id);
    if (e2) setError(e2.message); else { setProfile(p => ({ ...p, display_name, bio })); setError('Profil kaydedildi.'); }
  }
  async function uploadAvatar(file) {
    if (!file || !session?.user) return;
    if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) { setError('Profil fotoğrafı PNG, JPG veya WebP olmalı ve 5 MB’ı geçmemeli.'); return; }
    const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
    const path = `${session.user.id}/avatar-${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage.from('madem-avatars').upload(path, file, { upsert: true, contentType: file.type });
    if (uploadError) { setError(uploadError.message); return; }
    const { data } = supabase.storage.from('madem-avatars').getPublicUrl(path);
    const { error: updateError } = await supabase.from('profiles').update({ avatar_url: data.publicUrl, updated_at: new Date().toISOString() }).eq('id', session.user.id);
    if (updateError) setError(updateError.message); else { setProfile(p => ({ ...p, avatar_url: data.publicUrl })); setError('Profil fotoğrafı güncellendi.'); }
  }
  // ---- v9: yeni mesaj/grup işlevleri ----
  function toggleSelect(id) { setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]); }
  async function toggleFavorite(m) {
    if (favIds.has(m.id)) {
      const { error: e } = await supabase.from('message_favorites').delete().eq('message_id', m.id).eq('user_id', session.user.id);
      if (e) { setError(e.message); return; }
      setFavorites(p => p.filter(f => f.message_id !== m.id));
    } else {
      const { error: e } = await supabase.from('message_favorites').insert({ user_id: session.user.id, message_id: m.id });
      if (e) { setError(e.message); return; }
      setFavorites(p => [{ message_id: m.id, created_at: new Date().toISOString(), messages: { id: m.id, conversation_id: m.conversation_id, content: m.content, message_type: m.message_type, created_at: m.created_at, sender_id: m.sender_id } }, ...p]);
    }
  }
  async function favoriteSelected() {
    const targets = messages.filter(m => selectedIds.includes(m.id) && !favIds.has(m.id) && !m.deleted_at);
    for (const m of targets) await toggleFavorite(m);
    setSelectMode(false); setSelectedIds([]); setError('Favorilere eklendi.');
  }
  async function deleteForMe(ids) {
    const fresh = ids.filter(id => !hiddenIds.includes(id));
    if (fresh.length) {
      const { error: e } = await supabase.from('message_hidden').insert(fresh.map(id => ({ user_id: session.user.id, message_id: id })));
      if (e) { setError(e.message); return; }
    }
    setHiddenIds(prev => [...new Set([...prev, ...ids])]); setDeletingMessage(null); setSelectMode(false); setSelectedIds([]);
  }
  async function forwardTo(conv) {
    if (!forwardMsgs?.length) return;
    setMessageActionBusy(true);
    try {
      for (const m of forwardMsgs.filter(x => !x.deleted_at)) {
        let media = {};
        if (m.media_path) {
          const newPath = `${conv.id}/${crypto.randomUUID()}-${m.media_path.split('/').pop().replace(/^[0-9a-f-]{36}-/, '')}`;
          const { error: ce } = await supabase.storage.from('madem-media').copy(m.media_path, newPath);
          if (ce) throw ce;
          media = { media_path: newPath, media_mime_type: m.media_mime_type, media_size_bytes: m.media_size_bytes };
        }
        const { error: ie } = await supabase.from('messages').insert({ conversation_id: conv.id, sender_id: session.user.id, content: m.content, message_type: m.message_type === 'poll' ? 'text' : m.message_type, forwarded_from: m.id, ...media });
        if (ie) throw ie;
      }
      setForwardMsgs(null); setSelectMode(false); setSelectedIds([]); setError('Mesaj iletildi.');
      await loadConversations();
    } catch (e) { setError(/row-level security/i.test(e.message || '') ? 'Mesaj iletilemedi. Bu sohbette yazma iznin yok veya aranda engel var.' : (e.message || 'Mesaj iletilemedi.')); }
    finally { setMessageActionBusy(false); }
  }
  async function togglePin(m) {
    const { error: e } = await supabase.rpc('pin_message', { msg: m.id, pin: !m.pinned_at });
    if (e) { setError(e.message); return; }
    const v = m.pinned_at ? null : new Date().toISOString();
    setMessages(prev => prev.map(x => x.id === m.id ? { ...x, pinned_at: v } : x));
  }
  async function openReaders(m) { if (!active?.is_group) return; await loadGroupMembers(active.id); setReadersFor(m); }
  async function votePoll(optionId) {
    const { error: e } = await supabase.rpc('vote_poll', { option: optionId });
    if (e) setError(e.message); else setPollTick(t => t + 1);
  }
  async function createPoll() {
    const f = pollForm; if (!f) return;
    const q = f.question.trim(); const opts = f.options.map(x => x.trim()).filter(Boolean);
    if (!q || opts.length < 2) { setError('Soru ve en az iki seçenek gir.'); return; }
    setMessageActionBusy(true);
    const { error: e } = await supabase.rpc('create_poll', { conv: active.id, question: q, options: opts, multiple: f.multiple });
    setMessageActionBusy(false);
    if (e) { setError(e.message); return; }
    setPollForm(null);
  }
  function renderPoll(m) {
    const p = polls[m.id]; if (!p) return <i>Anket yükleniyor…</i>;
    const votes = pollVotes.filter(v => v.poll_id === p.id);
    const total = new Set(votes.map(v => v.user_id)).size;
    return <div className="poll-card"><b>📊 {p.question}</b><small>{p.multiple ? 'Birden fazla seçenek işaretlenebilir' : 'Tek seçenek işaretlenebilir'}</small>{p.options.map(o => { const n = votes.filter(v => v.option_id === o.id).length; const mine = votes.some(v => v.option_id === o.id && v.user_id === session.user.id); return <button type="button" key={o.id} className={`poll-opt ${mine ? 'mine' : ''}`} onClick={ev => { ev.stopPropagation(); votePoll(o.id); }}><span className="poll-bar" style={{ width: total ? `${Math.round(n / total * 100)}%` : '0%' }}/><span className="poll-label">{mine ? '✓ ' : ''}{o.label}</span><span className="poll-count">{n}</span></button>; })}<small>{total} kişi oy kullandı</small></div>;
  }
  async function openGallery() {
    if (!active) return; setShowGallery(true); setGalleryItems([]);
    const { data } = await supabase.from('messages').select('id,content,message_type,media_path,created_at').eq('conversation_id', active.id).not('media_path', 'is', null).is('deleted_at', null).order('created_at', { ascending: false }).limit(200);
    const hidden = new Set(hiddenIds); const rows = (data || []).filter(r => !hidden.has(r.id)); if (!rows.length) return;
    const { data: urls } = await supabase.storage.from('madem-media').createSignedUrls(rows.map(r => r.media_path), 3600);
    const byPath = Object.fromEntries((urls || []).map(u => [u.path, u.signedUrl]));
    setGalleryItems(rows.map(r => ({ ...r, url: byPath[r.media_path] })));
  }
  async function exportChat() {
    if (!active || exporting) return;
    setExporting(true); setError('Sohbet dışa aktarılıyor… Medya çoksa biraz sürebilir.');
    try {
      const all = []; let from = 0;
      for (;;) {
        const { data, error: e } = await supabase.from('messages').select('*').eq('conversation_id', active.id).order('created_at', { ascending: true }).range(from, from + 999);
        if (e) throw e; all.push(...(data || [])); if ((data || []).length < 1000) break; from += 1000;
      }
      const senderIds = [...new Set(all.map(m => m.sender_id))];
      const { data: ps } = senderIds.length ? await supabase.from('profiles').select('id,username,display_name').in('id', senderIds) : { data: [] };
      const names = Object.fromEntries((ps || []).map(p => [p.id, p.display_name || p.username]));
      const hidden = new Set(hiddenIds);
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip(); const media = zip.folder('medya'); const lines = []; let n = 0;
      for (const m of all) {
        if (hidden.has(m.id)) continue;
        const stamp = new Date(m.created_at).toLocaleString('tr-TR'); const who = names[m.sender_id] || 'Bilinmeyen';
        let body = m.deleted_at ? deletedLabel(m) : (m.message_type === 'poll' ? `[Anket] ${m.content}` : m.content);
        if (m.media_path && !m.deleted_at) {
          const { data: blob } = await supabase.storage.from('madem-media').download(m.media_path);
          if (blob) { n += 1; const fname = `${String(n).padStart(4, '0')}-${m.media_path.split('/').pop().replace(/^[0-9a-f-]{36}-/, '')}`; media.file(fname, blob); body = `[${m.message_type === 'voice' ? 'Sesli mesaj' : 'Medya'}: medya/${fname}]${m.message_type === 'file' ? ' ' + m.content : ''}`; }
        }
        lines.push(`[${stamp}] ${who}: ${body}`);
      }
      zip.file('sohbet.txt', lines.join('\n'));
      const out = await zip.generateAsync({ type: 'blob' });
      const a = document.createElement('a'); const href = URL.createObjectURL(out); a.href = href; a.download = `madem-${(active.titleText || 'sohbet').replace(/[^a-zA-Z0-9_-]/g, '_')}.zip`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(href), 10000);
      setError('Sohbet dışa aktarıldı.');
    } catch (e) { setError(e.message || 'Sohbet dışa aktarılamadı.'); } finally { setExporting(false); }
  }
  async function saveGroupDescription() {
    const { error: e } = await supabase.rpc('set_group_description', { conv: active.id, new_description: descDraft.trim() });
    if (e) setError(e.message); else { setError('Grup açıklaması güncellendi.'); await loadConversations(); }
  }
  async function toggleJoinApproval() {
    const { error: e } = await supabase.rpc('set_group_join_approval', { conv: active.id, required: !active.require_join_approval });
    if (e) setError(e.message); else await loadConversations();
  }
  async function loadJoinRequests(convId) {
    const { data: rq } = await supabase.from('group_join_requests').select('id,user_id,created_at').eq('conversation_id', convId).order('created_at');
    const ids = (rq || []).map(r => r.user_id);
    const { data: ps } = ids.length ? await supabase.from('profiles').select('id,username,display_name,avatar_url').in('id', ids) : { data: [] };
    const pm = Object.fromEntries((ps || []).map(x => [x.id, x]));
    setJoinRequests((rq || []).map(r => ({ ...r, profile: pm[r.user_id] || { username: 'bilinmiyor' } })));
  }
  async function resolveJoinRequest(r, approve) {
    const { error: e } = await supabase.rpc('resolve_group_join_request', { req: r.id, approve });
    if (e) { setError(e.message); return; }
    await loadJoinRequests(active.id);
    if (approve) { await loadGroupMembers(active.id); await loadConversations(); }
  }
  async function deleteChat() {
    if (!active) return;
    const text = active.is_group ? 'Bu sohbetteki tüm mesajlar senin için temizlensin mi? Diğer üyeler etkilenmez.' : 'Bu sohbet senden tamamen silinsin mi? Karşı taraf etkilenmez; yeni mesaj gelirse sohbet tekrar görünür.';
    if (!(await askConfirm(text))) return;
    const { error: e } = await supabase.rpc('clear_conversation_for_me', { conv: active.id });
    if (e) { setError(e.message); return; }
    const ids = messagesRef.current.map(m => m.id);
    setHiddenIds(prev => [...new Set([...prev, ...ids])]);
    const wasGroup = active.is_group;
    await setConversationFlag('deleted_at', new Date().toISOString());
    if (!wasGroup) setActiveId(null);
    setError(wasGroup ? 'Sohbet temizlendi.' : 'Sohbet silindi.');
  }
  function pickMention(u) { updateDraft(draft.replace(/@([\p{L}\p{N}_.]*)$/u, `@${u.username} `)); setMentionQuery(null); }
  function swipeMove(e) {
    const st = swipeRef.current; if (!st) return;
    const t = e.touches[0]; const dx = t.clientX - st.x, dy = t.clientY - st.y; const el = e.currentTarget;
    if (Math.abs(dy) > 24 && Math.abs(dy) > Math.abs(dx)) { swipeRef.current = null; el.style.transform = ''; return; }
    if (dx > 8 && Math.abs(dx) > Math.abs(dy)) { st.dx = Math.min(dx, 80); el.style.transform = `translateX(${st.dx}px)`; }
  }
  function swipeEnd(e, m) {
    const st = swipeRef.current; swipeRef.current = null; const el = e.currentTarget;
    el.style.transition = 'transform .15s'; el.style.transform = ''; setTimeout(() => { el.style.transition = ''; }, 200);
    if (st && st.dx >= 55 && !m.pending && !m.deleted_at && !selectMode) { setReplyTo(m); try { navigator.vibrate?.(15); } catch {} }
  }
  async function setMemberRole(person) {
    const next = person.role === 'admin' ? 'member' : 'admin';
    const { error: e } = await supabase.rpc('set_group_member_role', { conv: active.id, target: person.id, new_role: next });
    if (e) { setError(e.message); return; }
    await loadGroupMembers(active.id); await loadConversations();
  }
  async function toggleOnlyAdmins() {
    const { error: e } = await supabase.rpc('set_group_only_admins', { conv: active.id, only_admins: !active.only_admins_send });
    if (e) setError(e.message); else await loadConversations();
  }
  async function uploadGroupAvatar(file) {
    if (!file || !active?.is_group) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) { setError('Grup fotoğrafı PNG, JPG veya WebP olmalı ve 5 MB’ı geçmemeli.'); return; }
    const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
    const path = `${session.user.id}/group-${active.id}-${Date.now()}.${ext}`;
    const { error: ue } = await supabase.storage.from('madem-avatars').upload(path, file, { upsert: true, contentType: file.type });
    if (ue) { setError(ue.message); return; }
    const { data } = supabase.storage.from('madem-avatars').getPublicUrl(path);
    const { error: e } = await supabase.rpc('set_group_avatar', { conv: active.id, new_url: data.publicUrl });
    if (e) setError(e.message); else { setError('Grup fotoğrafı güncellendi.'); await loadConversations(); }
    if (groupAvatarRef.current) groupAvatarRef.current.value = '';
  }
  async function loadInvite(convId) { const { data } = await supabase.from('group_invites').select('code').eq('conversation_id', convId).maybeSingle(); setInviteCode(data?.code || null); }
  async function createInvite() { const { data, error: e } = await supabase.rpc('create_group_invite', { conv: active.id }); if (e) setError(e.message); else setInviteCode(data); }
  async function revokeInvite() { const { error: e } = await supabase.rpc('revoke_group_invite', { conv: active.id }); if (e) setError(e.message); else { setInviteCode(null); setError('Davet bağlantısı iptal edildi.'); } }
  async function markAllNotifs() { const now = new Date().toISOString(); const { error: e } = await supabase.from('notifications').update({ read_at: now }).eq('user_id', session.user.id).is('read_at', null); if (e) { setError(e.message); return; } setNotifs(p => p.map(n => ({ ...n, read_at: n.read_at || now }))); setUnreadNotifCount(0); }
  async function openNotif(n) {
    const now = new Date().toISOString();
    await supabase.from('notifications').update({ read_at: now }).eq('user_id', session.user.id).eq('id', n.id);
    // Okunan bildirim geçmişte kalır; yalnızca okunmamış sayacı azaltılır.
    setNotifs(p => p.map(x => x.id === n.id ? { ...x, read_at: x.read_at || now } : x));
    setUnreadNotifCount(c => Math.max(0, c - (n.read_at ? 0 : 1)));
    if (n.conversation_id) { setSection('chats'); setActiveId(n.conversation_id); }
  }

  async function changePassword(e) {
    e.preventDefault(); const f = pwForm; if (!f || messageActionBusy) return;
    if (f.next.length < 8 || f.next.length > 128) { setError('Yeni şifre en az 8 karakter olmalı.'); return; }
    if (f.next !== f.again) { setError('Yeni şifreler aynı değil.'); return; }
    if (f.next === f.current) { setError('Yeni şifre eskisinden farklı olmalı.'); return; }
    setMessageActionBusy(true);
    try {
      // Mevcut şifreyi, oturum açmadan yalnızca doğrulamak için giriş servisine sor.
      const { data: chk, error: ce } = await supabase.functions.invoke('madem-login', { body: { username: profile?.username, password: f.current } });
      if (ce || !chk?.access_token) { setError('Mevcut şifre yanlış.'); return; }
      const { error: ue } = await supabase.auth.updateUser({ password: f.next });
      if (ue) { setError(ue.message || 'Şifre değiştirilemedi.'); return; }
      setPwForm(null); setError('Şifren değiştirildi.');
    } catch (err) { setError(err.message || 'Şifre değiştirilemedi.'); }
    finally { setMessageActionBusy(false); }
  }

  async function signOut() {
    try { await unregisterAndroidPush(); } catch {}
    // Web push: bu cihazın abonelik kaydını hesaptan sil (tarayıcı aboneliği kalır, bir sonraki girişte giriş yapan hesaba geçer)
    try {
      if ('serviceWorker' in navigator) {
        const reg = await Promise.race([navigator.serviceWorker.ready, new Promise(resolve => setTimeout(() => resolve(null), 2500))]);
        if (reg) {
          const sub = await reg.pushManager.getSubscription();
          if (sub) await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint);
          (await reg.getNotifications()).forEach(n => n.close());
        }
      }
      navigator.clearAppBadge?.();
    } catch {}
    cacheClearAll(); await supabase.auth.signOut();
  }
  const filtered = useMemo(() => conversations.filter(c => !(c.userState?.deleted_at && !c.lastMessage && !c.is_group) && Boolean(c.userState?.archived_at) === showArchived && `${c.titleText} ${c.person?.username || ''} ${c.lastMessage?.content || ''}`.toLowerCase().includes(query.toLowerCase())).sort((a,b) => Number(Boolean(conversationStates[b.id]?.pinned_at))-Number(Boolean(conversationStates[a.id]?.pinned_at))), [conversations, query, showArchived, conversationStates]);

  if (!isSupabaseConfigured) return <div className="setup-screen"><div className="brand-mark"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><h1><span className="brand-ma">ma</span><span className="brand-dem">dem</span> kuruluma hazır.</h1><p>Supabase bağlantı bilgileri eksik. İki ortam değişkeni tanımlanmalı: <code>VITE_SUPABASE_URL</code> ve <code>VITE_SUPABASE_PUBLISHABLE_KEY</code>.</p><div className="setup-steps"><b>1.</b> Supabase → Project Settings → API'den Project URL ve publishable key'i al<br/><b>2.</b> <b>Vercel:</b> Settings → Environment Variables bölümüne iki değişkeni ekle, ardından <b>Redeploy</b> yap<br/><b>3.</b> <b>Yerel:</b> <code>.env.example</code> dosyasını <code>.env</code> olarak kopyala, değerleri yaz, <code>npm run dev</code> çalıştır</div><p className="muted">Gerçek kullanıcı ve mesaj verileri, demo verisi yerine Supabase üzerinde tutulur.</p></div>;
  if (!authReady) return null;
  if (!session) return <AuthScreen />;
  if (mfaRequired) return <main className="auth-shell"><section className="auth-card"><div className="brand-lockup"><div className="brand-mark"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><div><div className="brand-name"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><div className="brand-tagline">iki aşamalı doğrulama</div></div></div><h1>Güvenlik kodunu gir.</h1><p>Doğrulama uygulamandaki 6 haneli kodla girişini tamamla.</p><form className="auth-form" onSubmit={e => { e.preventDefault(); verifyMfaLogin(); }}><label>Doğrulama kodu<input inputMode="numeric" autoComplete="one-time-code" value={mfaCode} onChange={e => setMfaCode(e.target.value.replace(/\D/g,'').slice(0,6))} minLength={6} maxLength={6} required /></label><button className="primary-btn wide" type="submit">Doğrula <ShieldCheck size={16}/></button></form>{error && <div className="alert error">{error}</div>}</section></main>;

  return <div className={`app-shell ${!isOnline ? 'is-offline' : ''}`}>
    {!isOnline && <div className="offline-status" role="status">İnternet bağlantısı yok · Mesajların cihazda sıraya alınır</div>}
    <aside className="rail"><div className="rail-logo" aria-label="madem"><span className="brand-ma">ma</span><span className="brand-dem">dem</span></div><div className="rail-spacer"/><button className="rail-profile" title="Çıkış yap" onClick={confirmSignOut}><Avatar name={profile?.display_name || profile?.username} url={profile?.avatar_url} size="sm"/></button></aside>
    <section className={`sidebar ${activeId && section === 'chats' ? 'sidebar-mobile-hidden' : ''}`}>
      <header className="side-header"><div className="side-title">{section !== 'chats' && <button className="icon-btn back-top" title="Sohbetlere dön" aria-label="Sohbetlere dön" onClick={() => { setShowTopMenu(false); setSection('chats'); }}><ArrowLeft size={19}/></button>}<div><p className="eyebrow">MESAJLARIN</p><h1>{section === 'chats' ? 'Sohbetler' : section === 'contacts' ? 'Kişiler' : section === 'favorites' ? 'Favoriler' : section === 'notifications' ? 'Bildirimler' : 'Ayarlar'}</h1></div></div><div className="top-actions"><div className="chat-menu-wrap"><button className="icon-btn" title="Menü" aria-label="Menü" aria-expanded={showTopMenu} onClick={() => setShowTopMenu(v => !v)}><MoreHorizontal size={20}/></button>{showTopMenu && <><div className="top-menu-backdrop" onClick={() => setShowTopMenu(false)}/><div className="chat-menu top-menu" role="menu"><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('chats'); setShowNew(true); setQuery(''); setGroupMode(true); setSelectedPeople([]); }}>Yeni grup</button><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('chats'); setShowNew(true); setQuery(''); setGroupMode(false); setSelectedPeople([]); }}>Yeni sohbet</button><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('contacts'); }}>Kişi bul</button><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('favorites'); }}>Favoriler</button><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('settings'); }}>Ayarlar</button><button role="menuitem" onClick={() => { setShowTopMenu(false); setSection('chats'); setShowArchived(true); }}>Arşivlenen sohbetler</button><button role="menuitem" onClick={() => { setShowTopMenu(false); confirmSignOut(); }}>Çıkış yap</button></div></>}</div></div></header>
      {section === 'chats' && <><div className="search-box"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Sohbetlerde ara…"/></div><div className="sidebar-label"><button className="text-btn" onClick={() => setShowArchived(v => !v)}>{showArchived ? 'ARŞİVLENENLER' : 'SON SOHBETLER'}</button><span>{filtered.length} · <button className="text-btn" onClick={() => setShowArchived(v => !v)}>{showArchived ? 'Sohbetlere dön' : 'Arşiv'}</button></span></div><div className="conversation-list">{searchHits.length > 0 && <div className="search-hits"><p className="sidebar-label">MESAJLAR · {searchHits.length}</p>{searchHits.map(h => { const hc = conversations.find(c => c.id === h.conversation_id); return <button key={h.message_id} className="conversation-item" onClick={() => { setSection('chats'); setActiveId(h.conversation_id); setFavoriteJumpId(h.message_id); }}><div className="conversation-copy"><div className="conversation-top"><b>{hc?.titleText || 'Sohbet'}</b><time>{dateLabel(h.created_at)}</time></div><p>{previewText(h.content)}</p></div></button>; })}</div>}{filtered.map(c => <button key={c.id} className={`conversation-item ${activeId === c.id ? 'active' : ''}`} onClick={() => { setActiveId(c.id); }}><Avatar name={c.titleText} url={c.is_group ? c.avatar_url : c.person?.avatar_url} online={Boolean(c.otherId && onlineIds.includes(c.otherId))}/><div className="conversation-copy"><div className="conversation-top"><b>{conversationStates[c.id]?.pinned_at && <Pin size={12}/>} {c.titleText}</b><time>{c.lastMessage ? dateLabel(c.lastMessage.created_at) : ''}</time></div><p>{c.lastMessage ? `${c.lastMessage.sender_id === session.user.id && c.lastMessage.message_type !== 'system' ? 'Sen: ' : ''}${previewText(c.lastMessage.content)}` : 'Sohbete başla'}</p>{c.unread && activeId !== c.id && <span className="unread-blue-dot" aria-label="Okunmamış mesaj" title="Yeni mesaj"/>}{activeId !== c.id && c.is_group && (c.hasUnreadMention || mentionedIds.includes(c.id) || (c.unread && mentionsUser(c.lastMessage?.content, profile?.username))) && <span className="mention-badge" title="Senden bahsedildi">@</span>}</div></button>)}{!filtered.length && <div className="empty-list"><div className="empty-icon"><MessageCircle size={22}/></div><b>{query ? 'Sonuç bulunamadı' : 'Henüz sohbetin yok'}</b><p>{query ? 'Başka bir kelime deneyebilirsin.' : 'İlk mesajını göndermek için yeni sohbet başlat.'}</p>{!query && <button className="text-btn" onClick={() => setShowNew(true)}>Birini bul <ArrowUpRight size={15}/></button>}</div>}</div></>}
      {section === 'contacts' && <div className="side-panel"><div className="search-box"><Search size={17}/><input value={userQuery} onChange={e => setUserQuery(e.target.value)} placeholder="Kullanıcı adı ara…"/></div><div className="people-results">{userQuery.trim().length >= 2 ? <>{people.map(p => <button key={p.id} className="person-result" onClick={() => startChat(p)} disabled={busy}><Avatar name={p.display_name || p.username} url={p.avatar_url}/><div><b>{p.display_name || p.username}</b><span>@{p.username}</span></div><span className="person-open"><MessageCircle size={17}/></span></button>)}{!people.length && <div className="no-people">Eşleşen kullanıcı yok. Kullanıcı adını kontrol edip tekrar dene.</div>}</> : <>{contactConversations.filter(c => !userQuery || c.titleText?.toLowerCase().includes(userQuery.toLowerCase())).map(c => <button key={c.id} className="person-result" onClick={() => { setSection('chats'); setActiveId(c.id); }}><Avatar name={c.titleText} url={c.person?.avatar_url}/><div><b>{c.titleText}</b><span>{c.lastMessage ? previewText(c.lastMessage.content) : 'Sohbet'}</span></div><span className="person-open"><MessageCircle size={17}/></span></button>)}{!contactConversations.length && <div className="no-people">Henüz konuştuğun bir kişi yok. Yeni birini bulmak için kullanıcı adını ara.</div>}</>}</div></div>}
      {section === 'favorites' && <div className="side-panel"><p className="sidebar-label">FAVORİ MESAJLAR · {favorites.length}</p><div className="conversation-list">{favorites.map(f => { const fm = f.messages; const fc = conversations.find(c => c.id === fm?.conversation_id); return <button key={f.message_id} className="conversation-item" onClick={() => { if (fm) { setSection('chats'); setActiveId(fm.conversation_id); setFavoriteJumpId(fm.id); } }}><div className="conversation-copy"><div className="conversation-top"><b>{fc?.titleText || 'Sohbet'}</b><time>{fm ? dateLabel(fm.created_at) : ''}</time></div><p>{previewText(fm?.content || '')}</p></div></button>; })}{!favorites.length && <div className="empty-list"><div className="empty-icon"><Star size={22}/></div><b>Henüz favori mesajın yok</b><p>Bir mesajın üzerine gelip yıldız simgesine dokun.</p></div>}</div></div>}
      {section === 'notifications' && <div className="side-panel"><div className="sidebar-label"><span>BİLDİRİMLER · {notifs.filter(n => !n.read_at).length} yeni</span><button type="button" className="text-btn" onClick={markAllNotifs}>Tümünü okundu yap</button></div><div className="conversation-list">{notifs.map(n => <button key={n.id} className="conversation-item" onClick={() => openNotif(n)}><div className="conversation-copy"><div className="conversation-top"><b>{n.title}</b><time>{dateLabel(n.created_at)}</time></div><p>{previewText(n.body || '')}</p>{!n.read_at && <span className="unread-blue-dot" aria-label="Okunmamış"/>}</div></button>)}{!notifs.length && <div className="empty-list"><div className="empty-icon"><Bell size={22}/></div><b>Bildirim yok</b><p>Yeni mesaj bildirimleri burada listelenir.</p></div>}</div></div>}
      {section === 'settings' && <div className="settings-card"><div className="settings-person"><button className="avatar-upload" type="button" onClick={() => avatarInputRef.current?.click()} title="Profil fotoğrafını değiştir"><Avatar name={profile?.display_name || profile?.username} url={profile?.avatar_url} size="lg"/><span>Değiştir</span></button><input ref={avatarInputRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => uploadAvatar(e.target.files?.[0])}/><div><b>{profile?.display_name || 'madem kullanıcısı'}</b><p>@{profile?.username || 'kullanıcı'}</p></div></div><form className="profile-edit-form" onSubmit={saveProfile}><label>Görünen ad<input value={profileName} onChange={e => setProfileName(e.target.value)} maxLength={60} required/></label><label>Biyografi<textarea value={profileBio} onChange={e => setProfileBio(e.target.value)} maxLength={300} rows={3} placeholder="Kendinden biraz bahset…"/></label><button className="primary-btn wide" type="submit">Profili kaydet</button></form><div className="settings-row"><div className="settings-icon"><UserRound size={17}/></div><div><b>Hesap</b><p>@{profile?.username || 'kullanıcı adı'}</p></div></div><div className="settings-row theme-setting"><div className="settings-icon"><Activity size={17}/></div><div><b>Görünüm</b><p>{themePref === 'system' ? `Sistem (şu an ${theme === 'dark' ? 'koyu' : 'açık'})` : theme === 'dark' ? 'Koyu tema etkin' : 'Açık tema etkin'}</p></div><select className="theme-select" aria-label="Tema" value={themePref} onChange={e => setThemePref(e.target.value)}><option value="system">Sistem</option><option value="light">Açık</option><option value="dark">Koyu</option></select></div>{!isStandalone && <div className="settings-row"><div className="settings-icon"><Plus size={17}/></div><div><b>Uygulamayı yükle</b><p>{installPrompt ? 'Ana ekrana ekle — tarayıcı çubuğu olmadan açılır' : 'Tarayıcı menüsünden “Ana ekrana ekle / Install app” seç'}</p></div>{installPrompt ? <button className="text-btn" onClick={installPwa}>Yükle</button> : null}</div>}
<div className="settings-row"><div className="settings-icon"><Bell size={17}/></div><div><b>Arka plan bildirimleri</b><p>{pushEnabled ? 'Uygulama kapalıyken de mesaj bildirimi alırsın' : 'Uygulama kapalıyken mesaj bildirimi al'}</p></div><button className="text-btn" onClick={pushEnabled ? disablePush : enablePush}>{pushEnabled ? 'Kapat' : 'Aç'}</button></div><div className="settings-row"><div className="settings-icon"><ShieldCheck size={17}/></div><div><b>Şifre</b><p>Hesap şifreni değiştir</p></div><button className="text-btn" onClick={() => setPwForm(pwForm ? null : { current: '', next: '', again: '' })}>{pwForm ? 'Vazgeç' : 'Değiştir'}</button></div>{pwForm && <form className="pw-form" onSubmit={changePassword}><label>Mevcut şifre<input type="password" autoComplete="current-password" value={pwForm.current} onChange={e => setPwForm(f => ({ ...f, current: e.target.value }))} required/></label><label>Yeni şifre (en az 8 karakter)<input type="password" autoComplete="new-password" minLength={8} maxLength={128} value={pwForm.next} onChange={e => setPwForm(f => ({ ...f, next: e.target.value }))} required/></label><label>Yeni şifre (tekrar)<input type="password" autoComplete="new-password" minLength={8} maxLength={128} value={pwForm.again} onChange={e => setPwForm(f => ({ ...f, again: e.target.value }))} required/></label><button className="primary-btn wide" type="submit" disabled={messageActionBusy}>{messageActionBusy ? 'Kaydediliyor…' : 'Şifreyi değiştir'}</button></form>}<div className="settings-row security-row"><div className="settings-icon"><ShieldCheck size={17}/></div><div><b>İki aşamalı doğrulama</b><p>{mfaEnabled ? 'Doğrulayıcı uygulama etkin' : 'Kimlik doğrulama uygulamasıyla hesabını koru'}</p></div>{mfaEnabled ? <button className="text-btn" onClick={disableMfa}>Kapat</button> : <button className="text-btn" onClick={setupMfa}>Kur</button>}</div>{mfaSetup && <div className="mfa-setup"><p>Bu QR kodu bir doğrulayıcı uygulamayla tara.</p><img alt="İki aşamalı doğrulama QR kodu" src={mfaSetup.totp?.qr_code}/><p className="mfa-secret">Manuel anahtar: {mfaSetup.totp?.secret}</p><form onSubmit={e => { e.preventDefault(); verifyMfaSetup(); }}><label>6 haneli kod<input value={mfaCode} onChange={e => setMfaCode(e.target.value.replace(/\D/g,'').slice(0,6))} inputMode="numeric" maxLength={6} required/></label><button className="primary-btn wide" type="submit">Doğrulamayı tamamla</button></form></div>}<div className="settings-row"><div className="settings-icon"><ShieldAlert size={17}/></div><div><b>Engellenenler</b><p>{blockedUsers.length ? `${blockedUsers.length} kişi engelli` : 'Kimseyi engellemedin'}</p></div></div>{blockedUsers.map(b => <div className="settings-row" key={b.id}><Avatar name={b.display_name || b.username} url={b.avatar_url} size="sm"/><div><b>{b.display_name || b.username}</b><p>@{b.username}</p></div><button className="text-btn" onClick={() => unblockUser(b.id)}>Kaldır</button></div>)}<button className="logout-btn" onClick={deleteAccount}><Trash2 size={16}/> Hesabımı kalıcı olarak sil</button><button className="logout-btn" onClick={confirmSignOut}><LogOut size={16}/> Çıkış yap</button></div>}
      <footer className="sidebar-footer"><div className="footer-avatar"><Avatar name={profile?.display_name || profile?.username} url={profile?.avatar_url} size="sm" online/></div><div className="footer-user"><b>{profile?.display_name || profile?.username || 'madem kullanıcısı'}</b><span>@{profile?.username || 'madem'}</span></div><button className="icon-btn subtle" onClick={confirmSignOut} title="Çıkış yap"><LogOut size={18}/></button></footer>
    </section>
    <main className={`main-panel ${activeId && section === 'chats' ? 'main-mobile-active' : ''}`}>
      {section !== 'chats' ? <div className="main-empty"><div className="empty-illustration"><div className="empty-bubble bubble-one"><MessageCircle size={26}/></div><div className="empty-bubble bubble-two"><Users size={23}/></div><div className="empty-orb"/></div><p className="eyebrow">MADEM'E HOŞ GELDİN</p><h2>Bağlantıda kalmak<br/>artık daha kolay.</h2><p className="empty-desc">Sohbetlerin ve insanlarla kurduğun bağlar burada başlıyor.</p><button className="primary-btn" onClick={() => { setSection('chats'); setShowNew(true); }}>Yeni sohbet başlat <ArrowUpRight size={16}/></button></div> : active ? <><header className="chat-header"><button className="back-btn" onClick={() => setActiveId(null)}><ArrowLeft size={19}/></button><Avatar name={active.titleText} url={active.is_group ? active.avatar_url : active.person?.avatar_url} online={Boolean(active.otherId && onlineIds.includes(active.otherId))}/><div className="chat-heading"><b>{active.titleText}</b><span>{typingIds.length ? 'yazıyor…' : active.isSelf ? 'Kendine notlar' : active.person ? (onlineIds.includes(active.otherId) ? 'çevrimiçi' : presenceMap[active.otherId]?.last_seen_at ? `son görülme ${new Date(presenceMap[active.otherId].last_seen_at).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}` : `@${active.person.username}`) : (active.description ? active.description.split('\n')[0].slice(0, 70) : 'Grup sohbeti')}</span></div><div className="chat-actions"><span className="action-divider"/><div className="chat-menu-wrap"><button className="icon-btn" title="Sohbet seçenekleri" aria-expanded={showChatMenu} onClick={() => setShowChatMenu(v => !v)}><MoreHorizontal size={20}/></button>{showChatMenu && <div className="chat-menu" role="menu">{active.is_group && <button role="menuitem" onClick={() => { setShowChatMenu(false); openGroupInfo(); }}>Grup bilgisi{isGroupAdmin && joinRequests.length ? ` · ${joinRequests.length} istek` : ''}</button>}<button role="menuitem" onClick={() => { setShowChatMenu(false); setShowInChatSearch(true); }}>Sohbette ara</button><button role="menuitem" onClick={() => { setShowChatMenu(false); openGallery(); }}>Medya galerisi</button><button role="menuitem" onClick={() => { setShowChatMenu(false); exportChat(); }}>Sohbeti dışa aktar</button><button role="menuitem" onClick={async () => { setShowChatMenu(false); await setConversationFlag('muted_until', mutedNow ? null : '2100-01-01T00:00:00Z'); }}>{mutedNow ? 'Bildirimleri aç' : 'Bildirimleri sessize al'}</button><button role="menuitem" onClick={() => { setShowChatMenu(false); setSelectMode(true); setSelectedIds([]); }}>Mesajları seç</button>{active.is_group && canPost && <button role="menuitem" onClick={() => { setShowChatMenu(false); setPollForm({ question: '', options: ['', ''], multiple: false }); }}>Anket oluştur</button>}{!active.is_group && <button role="menuitem" onClick={async () => { setShowChatMenu(false); await setConversationFlag('archived_at'); }}>{conversationStates[activeId]?.archived_at ? 'Arşivden çıkar' : 'Sohbeti arşivle'}</button>}{active.is_group && <button role="menuitem" onClick={async () => { setShowChatMenu(false); await setConversationFlag('pinned_at'); }}>{conversationStates[activeId]?.pinned_at ? 'Sabitlemeyi kaldır' : 'Sohbeti sabitle'}</button>}<button role="menuitem" className="danger-item" onClick={() => { setShowChatMenu(false); deleteChat(); }}>{active.is_group ? 'Sohbeti temizle' : 'Sohbeti sil'}</button>{active.otherId && <><button role="menuitem" onClick={() => { setShowChatMenu(false); if (isBlocked) unblockUser(active.otherId); else blockActiveUser(); }}>{isBlocked ? 'Engeli kaldır' : 'Kullanıcıyı engelle'}</button></>}</div>}</div></div></header>{showInChatSearch && <div className="inchat-search"><Search size={16}/><input autoFocus value={inChatQuery} onChange={e => setInChatQuery(e.target.value)} placeholder="Bu sohbette ara…"/><button type="button" className="text-btn" onClick={() => { setShowInChatSearch(false); setInChatQuery(''); }}>Kapat</button></div>}{selectMode && <div className="select-bar"><b>{selectedIds.length} seçili</b><button type="button" className="text-btn" disabled={!selectedIds.length} onClick={favoriteSelected}>☆ Favori</button><button type="button" className="text-btn" disabled={!selectedIds.length} onClick={() => setForwardMsgs(messages.filter(m => selectedIds.includes(m.id)))}>↪ İlet</button><button type="button" className="text-btn" disabled={!selectedIds.length} onClick={() => deleteForMe(selectedIds)}>Kendimden sil</button><button type="button" className="text-btn" onClick={() => { setSelectMode(false); setSelectedIds([]); }}>Vazgeç</button></div>}{pinnedMessage && <div className="pinned-banner"><span>📌 {previewText(pinnedMessage.content || '').slice(0, 90)}</span>{canPin && <button type="button" className="text-btn" onClick={() => togglePin(pinnedMessage)}>Kaldır</button>}</div>}<div className="message-stream" ref={streamRef} onClick={e => { if (e.target === e.currentTarget) setSelectedMessageMenu(null); }} onScroll={e => { if (e.currentTarget.scrollTop < 60 && hasMore && !loadingOlder) loadOlder(); }}>{hasMore && <button type="button" className="text-btn load-older" onClick={loadOlder} disabled={loadingOlder}>{loadingOlder ? 'Yükleniyor…' : 'Daha eski mesajları yükle'}</button>}{visibleMessages.map((m, idx) => m.message_type === 'system' ? <React.Fragment key={m.id}>{(idx === 0 || new Date(visibleMessages[idx - 1].created_at).toDateString() !== new Date(m.created_at).toDateString()) && <div className="day-sep"><span>{dayLabel(m.created_at)}</span></div>}{unreadAnchor?.id === m.id && <div id="unread-divider" className="unread-divider"><span>{unreadAnchor.count} okunmamış mesaj</span></div>}<div id={`message-${m.id}`} className="system-msg"><span>{m.content}</span></div></React.Fragment> : <React.Fragment key={m.id}>{(idx === 0 || new Date(visibleMessages[idx - 1].created_at).toDateString() !== new Date(m.created_at).toDateString()) && <div className="day-sep"><span>{dayLabel(m.created_at)}</span></div>}{unreadAnchor?.id === m.id && <div id="unread-divider" className="unread-divider"><span>{unreadAnchor.count} okunmamış mesaj</span></div>}<div id={`message-${m.id}`} className={`message-row ${m.sender_id === session.user.id ? 'mine' : ''} ${selectedIds.includes(m.id) ? 'selected' : ''} ${m.sender_id !== session.user.id && m.message_type === 'text' && mentionsUser(m.content, profile?.username) ? 'mentioned' : ''}`} onTouchStart={e => { const t = e.touches[0]; swipeRef.current = { x: t.clientX, y: t.clientY, dx: 0 }; }} onTouchMove={swipeMove} onTouchEnd={e => swipeEnd(e, m)} onTouchCancel={e => { swipeRef.current = null; e.currentTarget.style.transform = ''; }}>{selectMode && <input type="checkbox" className="sel-box" checked={selectedIds.includes(m.id)} readOnly/>}{m.sender_id !== session.user.id && <Avatar name={messageAuthors[m.sender_id]?.display_name || messageAuthors[m.sender_id]?.username || active.titleText} url={messageAuthors[m.sender_id]?.avatar_url} size="xs"/>}<div className="message-content">{active.is_group && m.sender_id !== session.user.id && <div className="group-sender-name" style={isGroupAdmin ? { cursor: 'pointer' } : undefined} onClick={() => { const gm = groupMembers.find(x => x.id === m.sender_id); if (isGroupAdmin && gm) setMemberSheet(gm); }}>{messageAuthors[m.sender_id]?.display_name || messageAuthors[m.sender_id]?.username || 'Grup üyesi'}</div>}<div className="message-bubble" title={new Date(m.created_at).toLocaleString('tr-TR')} onPointerDown={e => startLongPress(e, m)} onPointerMove={moveLongPress} onPointerUp={cancelLongPress} onPointerLeave={cancelLongPress} onPointerCancel={cancelLongPress} onContextMenu={e => { e.preventDefault(); if (m.pending || selectMode) return; cancelLongPress(); longPressRef.current.fired = true; setSelectedMessageMenu(m.id); setMessageMenuMode('actions'); }} onClick={e => { if (longPressRef.current.fired) { longPressRef.current.fired = false; return; } if (m.pending) return; if (inChatQuery.trim()) { setShowInChatSearch(false); setInChatQuery(''); setFavoriteJumpId(m.id); return; } if (selectMode) { toggleSelect(m.id); return; } openMessageMenu(m.id, 'emoji'); e.currentTarget.parentElement?.classList.toggle('show-time'); }}>{m.pending && !active.isSelf && <div className="fwd-label">⏳ İnternet gelince gönderilecek</div>}{m.forwarded_from && !m.deleted_at && <div className="fwd-label">↪ İletildi</div>}{m.reply_to && <div className="reply-quote">{(() => { const original = messages.find(item => item.id === m.reply_to); const author = original ? (messageAuthors[original.sender_id]?.display_name || messageAuthors[original.sender_id]?.username || (original.sender_id === session.user.id ? 'Sen' : 'Üye')) : 'Önceki mesaj'; return <><b>{author}</b><span>{original ? (original.deleted_at ? deletedLabel(original) : (original.content || (original.message_type === 'image' ? 'Fotoğraf' : original.message_type === 'video' ? 'Video' : original.message_type === 'voice' ? 'Sesli mesaj' : 'Dosya'))) : 'Mesaj artık kullanılamıyor'}</span></>; })()}</div>}{m.deleted_at ? <i>{deletedLabel(m)}</i> : m.message_type === 'poll' ? renderPoll(m) : m.media_path ? <div className="media-message">{m.message_type === 'image' && mediaUrls[m.id] ? <a href={mediaUrls[m.id]} target="_blank" rel="noreferrer"><img src={mediaUrls[m.id]} alt={m.content || 'Gönderilen fotoğraf'}/></a> : m.message_type === 'video' && mediaUrls[m.id] ? <video controls src={mediaUrls[m.id]}/> : m.message_type === 'voice' && mediaUrls[m.id] ? <><audio controls preload="metadata" src={mediaUrls[m.id]} onLoadedMetadata={e => { e.currentTarget.playbackRate = 1; }} /><button type="button" className="speed-btn" title="Oynatma hızı" onClick={e => { e.stopPropagation(); const a = e.currentTarget.previousSibling; const nx = ({ 1: 1.5, 1.5: 2, 2: 1 })[a.playbackRate] || 1; a.playbackRate = nx; e.currentTarget.textContent = `${nx}×`; }}>1×</button></> : <a href={mediaUrls[m.id] || '#'} target="_blank" rel="noreferrer"><Paperclip size={16}/> {m.content || 'Dosyayı aç'}</a>}</div> : (m.message_type === 'text' && m.content ? renderMentions(m.content, profile?.username) : m.content)}</div>{!m.deleted_at && m.message_type === 'text' && firstUrl(m.content) && <LinkCard url={firstUrl(m.content)}/>}<div className="message-meta"><time>{clock(m.created_at)}</time><button type="button" className="message-options-trigger" title="Mesaj seçenekleri" aria-label="Mesaj seçenekleri" aria-expanded={selectedMessageMenu === m.id} onClick={e => { e.stopPropagation(); setSelectedMessageMenu(prev => prev === m.id ? null : m.id); }}><MoreHorizontal size={15}/></button>{m.sender_id === session.user.id && !active.isSelf && !m.pending && (() => { const recipients = (active.memberIds || []).filter(id => id !== m.sender_id); const readCount = recipients.filter(id => receipts.some(r => r.message_id === m.id && r.user_id === id && Boolean(r.read_at))).length; const allRead = recipients.length > 0 && readCount === recipients.length; const tickRead = active.is_group ? readCount > 0 : allRead; const statusText = active.is_group ? (readCount > 0 ? `Görüldü ${readCount}/${recipients.length}` : 'Gönderildi') : (allRead ? 'Görüldü' : 'Gönderildi'); return <span className={`read-state ${tickRead ? 'is-read' : 'is-sent'}`} title={statusText} onClick={active.is_group ? e => { e.stopPropagation(); openReaders(m); } : undefined} style={active.is_group ? { cursor: 'pointer' } : undefined}><CheckCheck size={14} className={tickRead ? 'read-check is-read' : 'read-check'}/>{statusText}</span>; })()}</div><div className={`message-tools ${selectedMessageMenu === m.id ? 'visible' : ''}`}>{messageMenuMode === 'emoji' ? (!m.deleted_at && REACTIONS.map(emo => <button key={emo} title={emo} onClick={() => toggleReaction(m, emo)}>{emo}</button>)) : <><button title="Yanıtla" onClick={() => setReplyTo(m)}>↩</button>{!m.deleted_at && <><button title={favIds.has(m.id) ? 'Favoriden çıkar' : 'Favorilere ekle'} onClick={() => toggleFavorite(m)}>{favIds.has(m.id) ? '★' : '☆'}</button><button title="İlet" onClick={() => setForwardMsgs([m])}>↪</button>{canPin && <button title={m.pinned_at ? 'Sabitlemeyi kaldır' : 'Mesajı sabitle'} onClick={() => togglePin(m)}>📌</button>}<button title="Seç" onClick={() => { setSelectMode(true); setSelectedIds([m.id]); }}>☑</button></>}{m.sender_id === session.user.id && !m.deleted_at && m.message_type !== 'poll' && <button title="Düzenle" onClick={() => editMessage(m)}>✎</button>}{!m.deleted_at && <button type="button" className="message-delete-action" title="Mesajı sil" aria-label="Mesajı sil" onClick={() => deleteMessage(m)}><Trash2 size={13}/><span>Sil</span></button>}</>}</div><div className="reaction-list">{[...new Set(reactions.filter(r => r.message_id === m.id).map(r => r.reaction))].map(emo => <button key={emo} onClick={() => toggleReaction(m,emo)}>{emo} {reactions.filter(r => r.message_id === m.id && r.reaction === emo).length}</button>)}</div></div></div></React.Fragment>)}{!messages.length && <div className="first-message"><div className="first-message-icon"><MessageCircle size={22}/></div><b>İlk mesajı sen gönder.</b><p>Bu sohbetin başlangıcı olsun.</p></div>}<div ref={bottomRef}/></div><form className="composer" onSubmit={sendMessage}>{replyTo && <div className="replying-to">Yanıt: {previewText(replyTo.content || '').slice(0,90)}<button type="button" onClick={() => setReplyTo(null)}>×</button></div>}<input ref={mediaInputRef} type="file" hidden accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,audio/webm,audio/ogg,audio/mpeg,audio/mp4,application/pdf,text/plain,application/zip,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation" onChange={e => uploadMedia(e.target.files?.[0])}/><button type="button" className="composer-icon" title="Fotoğraf, video veya dosya ekle" onClick={() => mediaInputRef.current?.click()}><Plus size={20}/></button><button type="button" className={`composer-icon ${isRecording ? 'recording' : ''}`} title={isRecording ? 'Ses kaydını bitir ve gönder' : 'Sesli mesaj kaydet'} onClick={toggleRecording}>{isRecording ? <StopCircle size={19}/> : <Mic size={19}/>}</button><div className="composer-input">{mentionOptions.length > 0 && <div className="mention-pop">{mentionOptions.map(u => <button type="button" key={u.id} onClick={() => pickMention(u)}>{u.isAll ? <span className="mention-all-ico"><Users size={15}/></span> : <Avatar name={u.display_name || u.username} url={u.avatar_url} size="xs"/>}<b>{u.display_name || u.username}</b><span>{u.isAll ? 'Tüm üyeleri etiketle' : `@${u.username}`}</span></button>)}</div>}<input value={draft} onChange={e => { updateDraft(e.target.value); const mm = active?.is_group ? e.target.value.match(/(?:^|\s)@([\p{L}\p{N}_.]*)$/u) : null; setMentionQuery(mm ? mm[1].toLowerCase() : null); }} placeholder={canPost ? 'Bir mesaj yaz…' : 'Bu grupta yalnızca yöneticiler yazabilir'} disabled={!canPost} maxLength={10000} autoComplete="off" enterKeyHint="send"/><button type="button" title="Emoji" onClick={() => setShowEmoji(v => !v)}><Smile size={19}/></button>{showEmoji && <div className="emoji-pop">{EMOJIS.map(emo => <button type="button" key={emo} onClick={() => updateDraft(draft + emo)}>{emo}</button>)}</div>}</div><button type="submit" className="send-btn" disabled={!draft.trim() || !canPost} title="Gönder"><Send size={17}/></button></form></> : <div className="main-empty"><div className="empty-illustration"><div className="empty-bubble bubble-one"><MessageCircle size={26}/></div><div className="empty-bubble bubble-two"><Users size={23}/></div><div className="empty-orb"/></div><p className="eyebrow">HER ŞEY BİR MESAJLA BAŞLAR</p><h2>Bir merhaba<br/>göndermeye ne dersin?</h2><p className="empty-desc">Birini bul, sohbete başla ve bağlantıda kal.</p><button className="primary-btn" onClick={() => setShowNew(true)}>Yeni sohbet başlat <ArrowUpRight size={16}/></button></div>}
    </main>
    {showNew && <div className="modal-backdrop" onClick={() => setShowNew(false)}><div className="new-chat-modal" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">MADEM AĞI</p><h2>{groupMode ? (selectedPeople.length > 0 && groupTitle.trim() ? groupTitle.trim() : 'Yeni grup') : 'Yeni sohbet'}</h2></div><button className="icon-btn" onClick={() => setShowNew(false)}><X size={20}/></button></header>{groupMode && !(selectedPeople.length > 0 && groupTitle.trim()) && <label className="group-title-input">Grup adı<input value={groupTitle} onChange={e => setGroupTitle(e.target.value)} placeholder="Örn. Arkadaşlar" maxLength={80}/></label>}<div className="search-box modal-search"><Search size={17}/><input autoFocus type="text" name="madem-user-search" value={userQuery} onChange={e => setUserQuery(e.target.value)} placeholder="Kullanıcı adı ara…" autoComplete="off" autoCorrect="off" autoCapitalize="none" spellCheck={false} enterKeyHint="search" data-lpignore="true" data-form-type="other"/></div><p className="modal-hint">Bir kullanıcı adı yaz. En az 2 karakterle arama yapılır.</p><div className="people-results">{!groupMode && userQuery.trim().length < 2 && <button className="person-result" onClick={() => startChat({ id: session.user.id })} disabled={busy}><Avatar name={profile?.display_name || profile?.username} url={profile?.avatar_url}/><div><b>Kendine mesaj</b><span>Notlarını ve bağlantılarını kaydet</span></div><span className="person-open"><MessageCircle size={17}/></span></button>}{people.map(p => groupMode ? <button key={p.id} className="person-result" onClick={() => setSelectedPeople(prev => prev.includes(p.id) ? prev.filter(id => id !== p.id) : prev.length >= 255 ? prev : [...prev, p.id])}><input type="checkbox" checked={selectedPeople.includes(p.id)} readOnly/><Avatar name={p.display_name || p.username} url={p.avatar_url}/><div><b>{p.display_name || p.username}</b><span>@{p.username}</span></div></button> : <button key={p.id} className="person-result" onClick={() => startChat(p)} disabled={busy}><Avatar name={p.display_name || p.username} url={p.avatar_url}/><div><b>{p.display_name || p.username}</b><span>@{p.username}</span></div><span className="person-open"><MessageCircle size={17}/></span></button>) }{userQuery.trim().length >= 2 && !people.length && <div className="no-people">Eşleşen kullanıcı yok.</div>}{userQuery.trim().length < 2 && <div className="no-people">Kullanıcı adı yazarak başla.</div>}</div>{groupMode && <button className="primary-btn wide group-create-btn" disabled={busy || selectedPeople.length < 2 || selectedPeople.length > 255 || !groupTitle.trim()} onClick={createGroup}>Grubu oluştur ({selectedPeople.length} kişi)</button>}{groupMode && <p className="group-validation-hint">En fazla 256 kişi · {selectedPeople.length + 1}/256 seçili</p>}</div></div>}
    {editingMessage && <div className="modal-backdrop" onClick={() => { if (!messageActionBusy) { setEditingMessage(null); setEditDraft(''); } }}><section className="message-action-modal" role="dialog" aria-modal="true" aria-labelledby="edit-message-title" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">MESAJ İŞLEMİ</p><h2 id="edit-message-title">Mesajı düzenle</h2></div><button type="button" className="icon-btn" aria-label="Kapat" disabled={messageActionBusy} onClick={() => { setEditingMessage(null); setEditDraft(''); }}><X size={19}/></button></header><form onSubmit={saveEditedMessage}><label htmlFor="edit-message-input">Mesaj metni</label><textarea id="edit-message-input" autoFocus value={editDraft} onChange={e => setEditDraft(e.target.value)} maxLength={10000} rows={5} required disabled={messageActionBusy}/><div className="message-modal-footer"><span>{editDraft.length}/10000</span><button type="button" className="secondary-btn" disabled={messageActionBusy} onClick={() => { setEditingMessage(null); setEditDraft(''); }}>Vazgeç</button><button type="submit" className="primary-btn" disabled={messageActionBusy || !editDraft.trim()}>{messageActionBusy ? 'Kaydediliyor…' : 'Değişiklikleri kaydet'}</button></div></form></section></div>}
    {confirmState && <div className="modal-backdrop" onClick={() => closeConfirm(false)}><section className="message-action-modal confirm-delete-modal" role="alertdialog" aria-modal="true" onClick={e => e.stopPropagation()}><div className="confirm-delete-icon"><Trash2 size={22}/></div><h2>Emin misin?</h2><p>{confirmState.text}</p><div className="message-modal-footer"><button type="button" className="secondary-btn" onClick={() => closeConfirm(false)}>Vazgeç</button><button type="button" className="danger-btn" onClick={() => closeConfirm(true)}>Evet</button></div></section></div>}
    {deletingMessage && <div className="modal-backdrop" onClick={() => { if (!messageActionBusy) setDeletingMessage(null); }}><section className="message-action-modal confirm-delete-modal" role="alertdialog" aria-modal="true" aria-labelledby="delete-message-title" onClick={e => e.stopPropagation()}><div className="confirm-delete-icon"><Trash2 size={22}/></div><h2 id="delete-message-title">Mesaj silinsin mi?</h2><p>“Kendimden sil” yalnızca senin ekranından kaldırır. <b>“Herkesten sil”</b> gönderdiğin mesajı sohbetin tüm katılımcılarından kaldırır. Bu işlem geri alınamaz.</p><div className="message-modal-footer"><button type="button" className="secondary-btn" disabled={messageActionBusy} onClick={() => setDeletingMessage(null)}>Vazgeç</button><button type="button" className="danger-btn" disabled={messageActionBusy} onClick={() => deleteForMe([deletingMessage.id])}>Kendimden sil</button>{(deletingMessage.sender_id === session.user.id || (active?.is_group && active.myRole === 'admin' && deletingMessage.message_type !== 'system')) && <button type="button" className="danger-btn delete-everyone-btn" disabled={messageActionBusy} onClick={confirmDeleteMessage}>{messageActionBusy ? 'Siliniyor…' : (deletingMessage.sender_id === session.user.id ? 'Herkesten sil' : 'Herkesten sil (yönetici)')}</button>}</div></section></div>}
    {showGroupInfo && active?.is_group && <div className="modal-backdrop" onClick={() => setShowGroupInfo(false)}><section className="message-action-modal group-info-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">GRUP</p><h2>Grup bilgisi</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setShowGroupInfo(false)}><X size={19}/></button></header>
      {isGroupAdmin ? <form className="group-rename" onSubmit={e => { e.preventDefault(); renameGroup(); }}><label>Grup adı<input value={groupInfoTitle} onChange={e => setGroupInfoTitle(e.target.value)} maxLength={80}/></label><button className="primary-btn" type="submit" disabled={!groupInfoTitle.trim() || groupInfoTitle.trim() === (active.title || '')}>Kaydet</button></form> : <p className="modal-hint"><b>{active.title}</b></p>}
      {isGroupAdmin && <div className="group-settings"><input ref={groupAvatarRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => uploadGroupAvatar(e.target.files?.[0])}/><button type="button" className="text-btn" onClick={() => groupAvatarRef.current?.click()}>Grup fotoğrafını değiştir</button><label className="inline-check"><input type="checkbox" checked={Boolean(active.only_admins_send)} onChange={toggleOnlyAdmins}/> Yalnızca yöneticiler mesaj yazabilsin</label><label className="inline-check"><input type="checkbox" checked={Boolean(active.require_join_approval)} onChange={toggleJoinApproval}/> Katılma isteklerini yönetici onaylasın</label><div className="invite-box">{inviteCode ? <><input readOnly value={`${location.origin}/?join=${inviteCode}`} onFocus={e => e.target.select()}/><button type="button" className="text-btn" onClick={() => { navigator.clipboard?.writeText(`${location.origin}/?join=${inviteCode}`); setError('Davet bağlantısı kopyalandı.'); }}>Kopyala</button><button type="button" className="text-btn" onClick={revokeInvite}>İptal et</button></> : <button type="button" className="text-btn" onClick={createInvite}>Davet bağlantısı oluştur</button>}</div></div>}
      {isGroupAdmin ? <form className="group-rename" onSubmit={e => { e.preventDefault(); saveGroupDescription(); }}><label>Grup açıklaması<textarea value={descDraft} onChange={e => setDescDraft(e.target.value)} maxLength={500} rows={3} placeholder="Grubun amacını yaz…"/></label><button className="primary-btn" type="submit" disabled={descDraft.trim() === (active.description || '')}>Kaydet</button></form> : (active.description ? <p className="group-desc">{active.description}</p> : null)}
      {isGroupAdmin && joinRequests.length > 0 && <><p className="sidebar-label">KATILMA İSTEKLERİ · {joinRequests.length}</p><div className="people-results">{joinRequests.map(r => <div key={r.id} className="person-result"><Avatar name={r.profile.display_name || r.profile.username} url={r.profile.avatar_url} size="sm"/><div><b>{r.profile.display_name || r.profile.username}</b><span>@{r.profile.username}</span></div><button type="button" className="text-btn" onClick={() => resolveJoinRequest(r, true)}>Onayla</button><button type="button" className="text-btn" onClick={() => resolveJoinRequest(r, false)}>Reddet</button></div>)}</div></>}
      <p className="sidebar-label">ÜYELER · {groupMembers.length}</p>
      <div className="people-results">{groupMembers.map(m => <div key={m.id} className="person-result"><Avatar name={m.display_name || m.username} url={m.avatar_url} size="sm"/><div><b>{m.display_name || m.username}{m.role === 'admin' ? ' · yönetici' : ''}</b><span>@{m.username}</span></div>{isGroupAdmin && m.id !== session.user.id && <button type="button" className="text-btn" onClick={() => setMemberSheet(m)}>Yönet</button>}</div>)}</div>
      {isGroupAdmin && <><div className="search-box modal-search"><Search size={17}/><input value={addQuery} onChange={e => setAddQuery(e.target.value)} placeholder="Üye eklemek için kullanıcı adı ara…"/></div><div className="people-results">{addResults.map(x => <button type="button" key={x.id} className="person-result" onClick={() => addGroupMember(x)}><Avatar name={x.display_name || x.username} url={x.avatar_url} size="sm"/><div><b>{x.display_name || x.username}</b><span>@{x.username}</span></div><span className="person-open"><Plus size={17}/></span></button>)}</div></>}
      <div className="message-modal-footer"><button type="button" className="danger-btn" onClick={leaveGroup}>Gruptan ayrıl</button></div></section></div>}
    {memberSheet && <div className="modal-backdrop" onClick={() => setMemberSheet(null)}><section className="message-action-modal member-sheet" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">ÜYE</p><h2>{memberSheet.display_name || memberSheet.username}</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setMemberSheet(null)}><X size={19}/></button></header><p className="modal-hint">@{memberSheet.username}{memberSheet.role === 'admin' ? ' · yönetici' : ''}</p><div className="member-sheet-actions"><button type="button" className="primary-btn wide" onClick={async () => { const m = memberSheet; setMemberSheet(null); await setMemberRole(m); }}>{memberSheet.role === 'admin' ? 'Yöneticiliği al' : 'Yönetici yap'}</button><button type="button" className="danger-btn wide" onClick={async () => { const m = memberSheet; setMemberSheet(null); await removeGroupMember(m); }}>Gruptan çıkar</button></div></section></div>}
    {forwardMsgs && <div className="modal-backdrop" onClick={() => !messageActionBusy && setForwardMsgs(null)}><section className="message-action-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">İLET</p><h2>{forwardMsgs.length} mesaj iletilsin</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setForwardMsgs(null)}><X size={19}/></button></header><div className="people-results">{conversations.filter(c => !(c.is_group && c.only_admins_send && c.myRole !== 'admin')).map(c => <button type="button" key={c.id} className="person-result" disabled={messageActionBusy} onClick={() => forwardTo(c)}><Avatar name={c.titleText} url={c.is_group ? c.avatar_url : c.person?.avatar_url} size="sm"/><div><b>{c.titleText}</b><span>{c.is_group ? 'Grup' : `@${c.person?.username || ''}`}</span></div></button>)}</div></section></div>}
    {pollForm && <div className="modal-backdrop" onClick={() => !messageActionBusy && setPollForm(null)}><section className="message-action-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">GRUP ANKETİ</p><h2>Anket oluştur</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setPollForm(null)}><X size={19}/></button></header><form className="poll-form" onSubmit={e => { e.preventDefault(); createPoll(); }}><label>Soru<input value={pollForm.question} maxLength={200} onChange={e => setPollForm(f => ({ ...f, question: e.target.value }))} required/></label>{pollForm.options.map((o, i) => <label key={i}>Seçenek {i + 1}<input value={o} maxLength={100} onChange={e => setPollForm(f => ({ ...f, options: f.options.map((x, j) => j === i ? e.target.value : x) }))}/></label>)}{pollForm.options.length < 10 && <button type="button" className="text-btn" onClick={() => setPollForm(f => ({ ...f, options: [...f.options, ''] }))}>+ Seçenek ekle</button>}<label className="inline-check"><input type="checkbox" checked={pollForm.multiple} onChange={e => setPollForm(f => ({ ...f, multiple: e.target.checked }))}/> Birden fazla seçenek işaretlenebilsin</label><div className="message-modal-footer"><button type="button" className="secondary-btn" onClick={() => setPollForm(null)}>Vazgeç</button><button type="submit" className="primary-btn" disabled={messageActionBusy}>{messageActionBusy ? 'Gönderiliyor…' : 'Anketi gönder'}</button></div></form></section></div>}
    {showGallery && <div className="modal-backdrop" onClick={() => setShowGallery(false)}><section className="message-action-modal gallery-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">MEDYA</p><h2>Medya galerisi</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setShowGallery(false)}><X size={19}/></button></header><div className="gallery-grid">{galleryItems.map(g => g.message_type === 'image' && g.url ? <a key={g.id} href={g.url} target="_blank" rel="noreferrer"><img src={g.url} alt={g.content || 'Fotoğraf'} loading="lazy"/></a> : g.message_type === 'video' && g.url ? <video key={g.id} src={g.url} controls preload="metadata"/> : <a key={g.id} className="gallery-file" href={g.url || '#'} target="_blank" rel="noreferrer"><Paperclip size={16}/> {g.message_type === 'voice' ? 'Sesli mesaj' : (g.content || 'Dosya')}</a>)}{!galleryItems.length && <p className="modal-hint">Bu sohbette henüz medya yok.</p>}</div></section></div>}
    {readersFor && <div className="modal-backdrop" onClick={() => setReadersFor(null)}><section className="message-action-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}><header><div><p className="eyebrow">OKUNDU BİLGİSİ</p><h2>Mesajı kimler okudu?</h2></div><button type="button" className="icon-btn" aria-label="Kapat" onClick={() => setReadersFor(null)}><X size={19}/></button></header><div className="people-results">{groupMembers.filter(u => u.id !== readersFor.sender_id).map(u => { const r = receipts.find(x => x.message_id === readersFor.id && x.user_id === u.id && x.read_at); return <div key={u.id} className="person-result"><Avatar name={u.display_name || u.username} url={u.avatar_url} size="sm"/><div><b>{u.display_name || u.username}</b><span>{r ? `Okudu · ${new Date(r.read_at).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}` : 'Henüz okumadı'}</span></div></div>; })}</div></section></div>}
    {error && <div className="toast"><CircleHelp size={17}/><span>{error}</span><button onClick={() => setError('')}><X size={16}/></button></div>}
  </div>;
}

class AppErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error) { console.error('madem render error:', error); }
  render() {
    if (this.state.hasError) return <main style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24, background: '#f7f8fa', color: '#17202a', fontFamily: 'system-ui, sans-serif' }}><section style={{ maxWidth: 420, textAlign: 'center', background: '#fff', padding: 28, borderRadius: 18, boxShadow: '0 12px 40px #17202a12' }}><div style={{ fontSize: 32, fontWeight: 800, color: '#167d62' }}>m.</div><h1 style={{ fontSize: 22 }}>Bir sorun oluştu</h1><p style={{ lineHeight: 1.6 }}>Uygulama beklenmeyen bir hatayla karşılaştı. Sayfayı yenileyerek tekrar deneyebilirsin.</p><button style={{ border: 0, borderRadius: 10, padding: '12px 18px', background: '#167d62', color: '#fff', fontWeight: 700, cursor: 'pointer' }} onClick={() => window.location.reload()}>Sayfayı yenile</button></section></main>;
    return this.props.children;
  }
}

function Root() {
  // Yapılandırma eksikse App içindeki kurulum ekranı gösterilir.
  return <App/>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><AppErrorBoundary><Root/></AppErrorBoundary></React.StrictMode>);
