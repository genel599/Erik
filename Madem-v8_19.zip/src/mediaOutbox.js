const DB_NAME = 'madem-offline-media';
const STORE = 'items';
function openDb() {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) return reject(new Error('Bu cihaz çevrimdışı medya kuyruğunu desteklemiyor.'));
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => { const db = req.result; if (!db.objectStoreNames.contains(STORE)) { const s = db.createObjectStore(STORE, { keyPath: 'id' }); s.createIndex('user_id', 'user_id', { unique: false }); } };
    req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error || new Error('Medya kuyruğu açılamadı.'));
  });
}
export async function enqueueMedia(item) {
  const db = await openDb();
  try { await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put(item); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); }); }
  finally { db.close(); }
}
export async function listQueuedMedia(userId) {
  const db = await openDb();
  try { return await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readonly'); const req = tx.objectStore(STORE).index('user_id').getAll(userId); req.onsuccess = () => resolve(req.result || []); req.onerror = () => reject(req.error); }); }
  finally { db.close(); }
}
export async function removeQueuedMedia(id) {
  const db = await openDb();
  try { await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(id); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
  finally { db.close(); }
}
