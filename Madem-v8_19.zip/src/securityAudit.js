// Madem v15.3 güvenlik yardımcıları
// Hassas bilgilerin loglara yazılmasını önlemek için kullanılır.
export function safeLog(event, data = {}) {
  const clean = { ...data };
  delete clean.password;
  delete clean.token;
  delete clean.access_token;
  if (import.meta.env.DEV) console.info(`[Madem] ${event}`, clean);
}
