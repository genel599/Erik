# Madem v15 - İlk Güncelleme

- Hata yakalama sistemi güçlendirildi.
- Hata kayıtları daha anlamlı hale getirildi.
- Mevcut mesajlaşma özellikleri korunuyor.
- Büyük özellik değişiklikleri yapılmadan önce uyumluluk kontrolü yapılacak.
