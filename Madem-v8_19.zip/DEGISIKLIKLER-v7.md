# v7 değişiklikleri (v6'nın üzerine)

## Önemli keşif
`sw.js` ve `manifest.webmanifest` proje kökündeydi; Vite `public/` dışındaki dosyaları `dist`'e kopyalamaz, yani canlıda ikisi de yoktu (PWA/bildirim çalışamazdı). İkisi `public/` içine taşındı. PWA ikonları (`public/icons/`) eklendi.

## Yeni / düzeltilen
- **Taslaklar:** sohbet başına cihazda saklanır; sohbet değiştirince geri gelir, gönderince silinir. Taslak yüklenince "yazıyor…" göstergesi tetiklenmez.
- **Engelleme:** Ayarlar → Engellenenler listesi + "Kaldır"; sohbet menüsünde "Engeli kaldır". Engelli kullanıcıya yazınca anlaşılır hata.
- **2FA:** Ayarlar'da "Kapat" düğmesi. (Supabase TOTP kurtarma kodu üretmez; cihaz kaybı için hesap kurtarma akışı ayrıca tasarlanmalı.)
- **Grup yönetimi:** sohbet menüsü → Grup bilgisi: üye listesi, ad değiştirme, üye ekleme/çıkarma (yönetici), gruptan ayrılma (son yönetici ayrılırsa en eski üye yönetici olur, boş grup silinir).
- **Arşiv / sabitleme** artık hem birebir hem grup sohbetlerinde.
- **Arka plan bildirimleri (Web Push):** service worker `push`/`notificationclick`, Ayarlar'da "Arka plan bildirimleri", `push_subscriptions` tablosu, `madem-push` Edge Function. Bildirime tıklayınca ilgili sohbet açılır. Aramada bildirimden açılınca hâlâ çalan arama gösterilir.
- **Android bildirimi:** `new Notification` yerine service worker `showNotification`.
- **Bildirim kanalı** artık her sohbet listesi yenilemesinde değil, yalnızca sohbet kimlikleri değişince yeniden kurulur.
- **Okundu bilgisi:** zaten okunmuş mesajlara tekrar yazılmaz (`ignoreDuplicates`), `hasFocus` şartı kaldırıldı.
- **Çevrimiçi/son görülme:** 45 sn'de bir kalp atışı + sekme gizlenince/kapanınca güncellenir.
- **Silinen mesajın dosyası** storage'dan silinir, `media_path` temizlenir.
- **Reaksiyon realtime** yalnızca açık sohbetin mesajlarına uygulanır.
- **Yeni sohbet penceresi** kendi arama kutusunu kullanır; "⌘ K" ipucu kaldırıldı; `_` joker karakteri kaçırıldı.
- **Çıkış** artık onay ister; "⋯" simgesi çıkış simgesine çevrildi.
- **Edge Functions:** giriş (10 dk'da 8 deneme) ve kayıt (saatte 5) için en-iyi-çaba hız sınırı; hesap silinirken avatar ve medya dosyaları temizlenir.

## Dağıtım adımları (sırayla)
1. `supabase/migrations/20261011140000_madem_groups_and_push.sql` dosyasını uygula (yedek aldıktan sonra).
2. VAPID anahtarı üret: `npx web-push generate-vapid-keys`.
   - Public anahtar → Vercel ortam değişkeni `VITE_VAPID_PUBLIC_KEY`.
   - Private anahtar + `VAPID_PUBLIC_KEY`, `VAPID_SUBJECT` (`mailto:...`), `PUSH_WEBHOOK_SECRET` → `supabase secrets set ...`
3. `supabase functions deploy madem-push --no-verify-jwt` (ve güncellenen `madem-login`, `madem-register`, `madem-delete-account`).
4. Supabase → Database → Webhooks: tablo `notifications`, olay `INSERT`, hedef `madem-push` fonksiyonu, başlık `x-madem-webhook-secret: <PUSH_WEBHOOK_SECRET>`.
5. İsteğe bağlı TURN: `VITE_TURN_URL`, `VITE_TURN_USERNAME`, `VITE_TURN_CREDENTIAL`.
6. `npm install && npm run build` ile derlemeyi doğrula, sonra yayınla.

## Hâlâ yapılmayanlar
- iOS Safari'de Web Push yalnızca ana ekrana eklenmiş PWA'da çalışır; mağaza uygulaması için FCM/APNs ayrıca gerekir.
- Grup araması (SFU), yönetici şikâyet paneli, 2FA kurtarma kodları.
- Çok katmanlı `!important` CSS temizliği (görsel regresyon riski nedeniyle dokunulmadı).

## v8
- Okunmamış mesajların mavi noktası geri geldi: `.unread-blue-dot` CSS kuralı v5 paketinde kaybolmuştu (eski paketlerde vardı), nokta DOM'da vardı ama görünmezdi.
