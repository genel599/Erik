# v9 değişiklikleri

> Derleme (`npm run build`) ve canlı test bu ortamda yapılamadı (npm kayıt deposuna erişim yok). Kod sözdizimi ve tanımsız değişken kontrolünden geçti; çalışma davranışı iki hesapla test edilmelidir.

## v9.2
- Telefonda sohbet başlığındaki ⋯ (sohbet seçenekleri) menüsü gizleniyordu; düzeltildi. Görüntülü arama düğmesi küçük ekranlarda da görünür.

## v9.1
- Arama geçmişi ve Ayarlar paneli artık aşağı kaydırılabiliyor.
- Ayarlar'a "Şifre → Değiştir" eklendi (mevcut şifre doğrulanır, yeni şifre en az 8 karakter).

## Düzeltilen hatalar
- `20261009192606_madem_message_notifications.sql`: eksik parantez eklendi (migration artık çalışır).
- `push_subscriptions`: iki farklı şema birleştirildi (`endpoint/p256dh/auth` + eski `platform/token` boş bırakılabilir). Web Push artık kaydedilebilir.
- `madem-media` bucket'ında dosya türü kısıtı kaldırıldı.
- Mesaj saati artık yalnızca mesaja dokununca görünür (önceden her zaman görünüyordu).
- Arşiv yalnızca bire bir, sabitleme yalnızca gruplarda (seçilen gereksinime uygun).

## Güvenlik (yeni migration: `20261011150000_madem_fixes_and_features.sql`)
- Profilde kullanıcı adı değiştirilemez; ad/biyografi uzunluğu veritabanında denetlenir.
- Engellenen kullanıcı arama başlatamaz / sinyal gönderemez; grup oluştururken engel kontrolü var.
- Mesaj güncellemede `created_at`, `sender_id`, tür vb. değiştirilemez; silinen mesaj geri getirilemez; sabitleme yalnızca izinli RPC ile.
- Arama kaydı alanları değiştirilemez; sonlanmış arama güncellenemez.

## Yeni özellikler
Mesajlar: iletme (medya kopyalanır), sabitleme (bire birde herkes, grupta yöneticiler), favoriler + Favoriler bölümü, çoklu seçim (favori / ilet / kendimden sil), kendimden sil + herkesten sil, sohbet içi arama, tüm sohbetlerde mesaj arama, medya galerisi, sohbeti dışa aktarma (metin + medya, ZIP), bağlantı önizleme, günlük tarih ayraçları, yukarı kaydırınca eski mesajları yükleme, emoji seçici, 6 reaksiyon, ses hızı (1×/1.5×/2×) ve ses süresi, dosya indirme.
Gruplar: anketler, davet bağlantısı (yönetici), yönetici atama/alma, grup fotoğrafı, "yalnızca yöneticiler yazsın" izni, okuyan üyelerin listesi (mesajın "Görüldü" yazısına dokun).
Diğer: bildirim merkezi, sohbet sessize alma, Kişiler sekmesinde doğrudan kullanıcı arama (biyografi görünür).

## Dağıtım adımları (sırayla)
1. Yedek al, sonra `supabase/migrations/20261009192606_...` dosyasını (düzeltilmiş) ve ardından `20261011150000_madem_fixes_and_features.sql` dosyasını uygula. Canlıda `messages` tablosunda başka bir INSERT politikası varsa (`select policyname from pg_policies where tablename='messages'`) kaldır; yoksa engel/yönetici-izni kuralları atlanır.
2. `supabase functions deploy madem-link-preview` (JWT doğrulaması açık kalsın).
3. `npm install` (yeni bağımlılık: `jszip`) → `npm run build`.
4. Önceki sürümden kalan adımlar (VAPID, madem-push, webhook) için `DEGISIKLIKLER-v7.md`.

## Yapılmayanlar / bilinen sınırlar
- Hız sınırı hâlâ bellek içi; gerçek bot koruması (CAPTCHA) eklenmedi.
- Hesap silmede şifre yeniden doğrulama ve 1000+ medya dosyası için sayfalama yok.
- `src/supabase.js` env boşken yerleşik URL/anahtara düşer (bilerek bırakıldı; dağıtımı bozmamak için).
- 2FA kurtarma kodları, grup araması (SFU), yönetici şikâyet paneli yok.
- Bağlantı önizleme bazı sitelerde (bot engelleyenler) boş kalır.
- Dışa aktarma çok büyük sohbetlerde tarayıcı belleğini zorlayabilir.
