# Madem bildirim sistemi

## Hazır olanlar
- Supabase veritabanında Android cihaz token tablosu ve kayıt/silme RPC'leri.
- Web Push abonelik alanları (`endpoint`, `p256dh`, `auth`) ve mevcut aboneliklerle uyum.
- Yeni bildirim kaydından sonra `madem-push` Edge Function'ını çağıran veritabanı tetikleyicisi.
- VAPID anahtarları Supabase Vault içinde şifreli saklanır.
- Edge Function bildirim içeriğini istemciden almak yerine doğrudan `notifications` tablosundan okur.
- Kullanılmayan/sona ermiş Web Push abonelikleri otomatik temizlenir.

## Web/PWA
Üretim ortamında `VITE_VAPID_PUBLIC_KEY` ortam değişkeni tanımlı olmalıdır. Bu değer herkese açık anahtardır; özel VAPID anahtarı yalnızca Supabase Vault'ta saklanır.

## Android
Android tarafında uygulama `register_device_token` RPC'si ile FCM cihaz token'ını kaydeder. Gerçek Android gönderimi için Firebase Console'dan Madem Android uygulamasına ait servis hesabı JSON'u gerekir. Bu JSON kaynak koduna veya Vercel'e eklenmemelidir; Supabase Vault'ta `madem_firebase_service_account` adıyla saklanmalıdır.

## Güvenlik
- Supabase service-role anahtarı istemciye konmaz.
- Push webhook anahtarı ve VAPID özel anahtarı Supabase Vault'ta tutulur.
- `madem_get_push_config()` yalnızca `service_role` rolüne açıktır.
