# madem — Tarayıcı / PWA (Web Push) kurulumu

Android FCM'e ek olarak, madem-push fonksiyonu artık `push_subscriptions` tablosundaki tarayıcı aboneliklerine de gönderir.

1. VAPID anahtarı üret (bilgisayarda): `npx web-push generate-vapid-keys`
2. Supabase secret'ları:
   ```
   supabase secrets set VAPID_PUBLIC_KEY=<public> VAPID_PRIVATE_KEY=<private> VAPID_SUBJECT=mailto:sen@ornek.com
   supabase functions deploy madem-push --no-verify-jwt
   ```
3. Migration: `supabase db push` (20261012140000_madem_webpush_trigger.sql)
4. Vercel > Settings > Environment Variables: `VITE_VAPID_PUBLIC_KEY=<public>` (aynı public anahtar), sonra yeniden deploy.
5. Telefonda Chrome'da siteyi aç → Ayarlar → "Arka plan bildirimleri → Aç". İzin ver.
   iPhone'da önce "Ana ekrana ekle" ile PWA olarak kurmak gerekir.
6. Test: başka hesaptan mesaj at, uygulama kapalıyken bildirim gelmeli.

Sorun giderme: Functions → madem-push → Logs. `vapid_missing` = secret'lar yok. `net._http_response` tablosunda 401 = WEBHOOK_SECRET uyuşmuyor.
