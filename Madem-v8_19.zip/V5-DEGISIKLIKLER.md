# Madem v5 — değişiklik özeti

## İstemci (Vercel)
- Bildirim sayfası artık açıkken Realtime ile güncellenir ve okunan bildirimleri geçmişte tutar.
- Dosya seçme ve gönderme akışına güvenli MIME/uzantı allowlist'i eklendi; boş ve 50 MB üzerindeki dosyalar reddedilir.
- Çevrimdışı kuyruğa alınmış eski dosyalar yeniden gönderilmeden önce aynı güvenlik kontrolünden geçirilir.
- Ayarlar ekranının küçük ekranlarda kaydırılması ve klavye ile odak görünürlüğü iyileştirildi.
- Kişi arama, engellenenler listesi, tema, şifre ve MFA özellikleri korunmuştur.

## Sunucu (Supabase; Vercel bunu otomatik dağıtmaz)
- Yeni SQL migration'ı medya bucket'ına MIME allowlist ve 50 MB sunucu sınırı uygular.
- Giriş/kayıt Edge Function'ları bellek içi sayacın yerine atomik, hashlenmiş anahtar kullanan veritabanı rate limiter'ına bağlandı.
- Bu sunucu tarafı değişikliklerin çalışması için migration önce uygulanmalı, sonra `madem-login` ve `madem-register` Edge Function'ları dağıtılmalıdır. Ayrıntı: `DEPLOY-SON-KONTROL.md`.

## Doğrulama sınırları
- `src/main.jsx` JSX/TypeScript parser kontrolünden geçti.
- JavaScript yardımcı dosyalarının `node --check` kontrolleri geçti.
- Edge Function TypeScript'i, Deno çalışma zamanı tipleri bulunmadığından genel TypeScript derleyicisiyle tam tip kontrolünden geçirilemedi; görünen hatalar Deno ve uzak import tanımlarının bulunmamasıdır.
- Tam `npm run build` yapılamadı: bağımlılıklar kurulu değil ve çevrimdışı npm önbelleğinde tüm paketler bulunmuyor. Bu nedenle Vercel dağıtımından önce/sonra build durumunu kontrol et.
