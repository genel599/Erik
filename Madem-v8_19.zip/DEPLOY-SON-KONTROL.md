# Madem v7 — dağıtım notları

## Vercel'e yükleme
- ZIP'i yeni/ayrı Vercel projesine yükle; çalışan eski projeyi silme veya üzerine yazma.
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- `VITE_SUPABASE_URL` ve `VITE_SUPABASE_PUBLISHABLE_KEY` ortam değişkenleri doğru Supabase projesini göstermeli.
- Web Push kullanılacaksa `VITE_VAPID_PUBLIC_KEY` de Vercel Environment Variables bölümünde tanımlı olmalı. Bu anahtar yalnızca herkese açık VAPID anahtarıdır; özel anahtar eklenmemelidir.

## Supabase tarafı — Vercel ZIP yüklemesi bunları otomatik uygulamaz
1. Önce `supabase/migrations/20261029130000_madem_security_storage_rate_limit.sql` dosyasını doğru Supabase projesinde SQL Editor üzerinden veya Supabase CLI ile uygula.
2. Ardından `supabase/functions/_shared/rateLimit.ts`, `madem-login` ve `madem-register` Edge Function dosyalarını birlikte deploy et.
3. Fonksiyonların ortamında `SUPABASE_URL` ve `SUPABASE_SERVICE_ROLE_KEY` bulunmalı. Service-role anahtarını Vercel'in `VITE_` değişkenlerine veya istemci koduna ASLA koyma.
4. Giriş ve kayıt işlemlerini test et. Veritabanı rate-limit RPC'si erişilemezse güncellenmiş auth fonksiyonları güvenli tarafta kalıp 503 döndürür; bu durumda migration/fonksiyon dağıtım sırasını kontrol et.

## Ek kontrol (v6 ile geldi)
- Vercel'de `VITE_SUPABASE_URL` ve `VITE_SUPABASE_PUBLISHABLE_KEY` artık zorunlu; tanımlı değilse uygulama kurulum ekranında kalır.
- Edge Function ortamında IP başlığı (`cf-connecting-ip`, `x-real-ip` veya `x-forwarded-for`) gelmezse giriş/kayıt 503 verir. Deploy sonrası bir giriş denemesi yap.

## Değişiklikler
- Bildirim listesi sayfa açıkken Realtime ile yenilenir; okunan bildirimler listede geçmiş olarak kalır.
- Dosya gönderimi için istemci tarafında tür/uzantı kontrolü, 50 MB sınırı ve çevrimdışı kuyruğa tekrar kontrol eklendi.
- Medya Storage bucket'ı için MIME allowlist ve 50 MB sunucu sınırı içeren migration eklendi.
- Giriş/kayıt deneme sayacı artık süreç belleğine değil, veritabanında atomik ve hashlenmiş anahtarlarla çalışan rate limiter'a bağlandı.
- Mevcut engellenen kullanıcılar, şifre/2FA ve tema ayarları korunmuştur.

## Test durumu
- ZIP bütünlüğü, JavaScript sözdizimi ve statik kontroller yerel olarak yapılacak.
- Canlı Supabase migration'ı ve Edge Function dağıtımı bu ZIP'in parçası olarak otomatik çalışmaz.
