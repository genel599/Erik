import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { checkRateLimit } from "../_shared/rateLimit.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

function response(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: cors });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return response(405, { error: "Yalnızca POST kullanılabilir." });

  try {
    const { username, password, displayName } = await req.json();
    const normalized = String(username ?? "").trim().toLowerCase();
    const name = String(displayName ?? "").trim();
    if (!/^[a-z0-9_]{3,24}$/.test(normalized)) {
      return response(400, { error: "Kullanıcı adı 3–24 karakter olmalı; yalnızca harf, rakam ve _ kullanılabilir." });
    }
    if (typeof password !== "string" || password.length < 8 || password.length > 128) {
      return response(400, { error: "Şifre en az 8 karakter olmalı." });
    }
    if (!name || name.length > 60) {
      return response(400, { error: "Görünen ad 1–60 karakter arasında olmalı." });
    }

    const limited = await checkRateLimit(req, "register", "account-create", 5, 60 * 60);
    if (limited === null) return response(503, { error: "Kayıt servisi geçici olarak kullanılamıyor. Lütfen daha sonra tekrar dene." });
    if (limited) return response(429, { error: "Bu ağdan çok fazla kayıt denemesi yapıldı. Daha sonra tekrar dene." });

    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) return response(500, { error: "Kayıt servisi yapılandırılmamış." });

    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const { data: existing, error: lookupError } = await admin
      .from("profiles").select("id").eq("username", normalized).maybeSingle();
    if (lookupError) return response(500, { error: "Kayıt şu anda tamamlanamadı." });
    if (existing) return response(409, { error: "Bu kullanıcı adı zaten kullanılıyor." });

    // Supabase Auth requires an email identifier internally. This non-deliverable alias is never shown to users.
    const internalEmail = normalized + "@accounts.madem.invalid";
    const { data, error } = await admin.auth.admin.createUser({
      email: internalEmail,
      password,
      email_confirm: true,
      user_metadata: { username: normalized, display_name: name },
    });
    if (error) {
      if (/already|duplicate|unique/i.test(error.message)) {
        return response(409, { error: "Bu kullanıcı adı zaten kullanılıyor." });
      }
      return response(400, { error: "Hesap oluşturulamadı. Bilgilerini kontrol edip tekrar dene." });
    }
    return response(201, { id: data.user.id, username: normalized });
  } catch {
    return response(400, { error: "İstek okunamadı. Bilgilerini kontrol edip tekrar dene." });
  }
});
