import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
const respond = (status: number, body: Record<string, unknown>) => new Response(JSON.stringify(body), { status, headers: cors });

function blockedHost(host: string) {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan")) return true;
  if (h.includes(":")) return true;
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const [a, b, c, d] = m.slice(1).map(Number);
    if ([a, b, c, d].some(n => n < 0 || n > 255)) return true;
    if (a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || (a === 192 && b === 0 && c === 0) || (a === 198 && (b === 18 || b === 19))) return true;
    return false;
  }
  if (/^(0x[\da-f]+|\d+)$/i.test(h) || !h.includes(".")) return true;
  return false;
}
const decode = (s: string) => s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
function meta(html: string, key: string) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re1 = new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]*content=["']([^"']*)["'][^>]*>`, "i");
  const re2 = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${escaped}["'][^>]*>`, "i");
  const m = html.match(re1) || html.match(re2);
  return m ? decode(m[1]) : "";
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return respond(405, { error: "Yalnızca POST kullanılabilir." });
  try {
    const body = await req.json();
    const raw = typeof body?.url === "string" ? body.url : "";
    if (raw.length > 2048) return respond(400, { error: "Adres çok uzun." });
    let target: URL;
    try { target = new URL(raw); } catch { return respond(400, { error: "Geçersiz adres." }); }
    if (!["http:", "https:"].includes(target.protocol) || target.username || target.password || blockedHost(target.hostname) || (target.port && !["80", "443"].includes(target.port))) {
      return respond(400, { error: "Bu adres için önizleme yapılamaz." });
    }
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000);
    let res: Response;
    try { res = await fetch(target.toString(), { signal: ctrl.signal, redirect: "manual", headers: { "User-Agent": "Mozilla/5.0 (compatible; madem-link-preview/1.0)", Accept: "text/html" } }); }
    finally { clearTimeout(timer); }
    if (res.status >= 300 && res.status < 400) return respond(200, { url: target.toString(), title: target.hostname, description: "", image: "", site: target.hostname });
    const type = res.headers.get("content-type") ?? "";
    if (!res.ok || !type.includes("text/html")) return respond(200, { url: target.toString(), title: target.hostname, description: "", image: "", site: target.hostname });
    const reader = res.body?.getReader(); let html = ""; let size = 0; const dec = new TextDecoder();
    while (reader && size < 200_000) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.length; html += dec.decode(value, { stream: true });
      if (html.includes("</head>")) break;
    }
    try { await reader?.cancel(); } catch {}
    const title = meta(html, "og:title") || decode((html.match(/<title[^>]*>([^<]*)<\/title>/i) ?? [])[1] ?? "") || target.hostname;
    const description = meta(html, "og:description") || meta(html, "description");
    let image = meta(html, "og:image");
    if (image) { try { image = new URL(image, target).toString(); if (!image.startsWith("https://")) image = ""; } catch { image = ""; } }
    return respond(200, { url: target.toString(), title: title.slice(0, 160), description: description.slice(0, 240), image, site: meta(html, "og:site_name") || target.hostname });
  } catch { return respond(200, { error: "Önizleme alınamadı." }); }
});
