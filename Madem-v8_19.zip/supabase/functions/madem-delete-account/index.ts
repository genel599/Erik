import "jsr:@supabase/functions-js/edge-runtime.d.ts";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
function respond(status: number, body: Record<string, unknown>) { return new Response(JSON.stringify(body), { status, headers: cors }); }
async function purgeStorage(url: string, serviceKey: string, userId: string) {
  const h = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "Content-Type": "application/json" };
  try {
    const list = await fetch(`${url}/storage/v1/object/list/madem-avatars`, { method: "POST", headers: h, body: JSON.stringify({ prefix: userId, limit: 100 }) });
    if (list.ok) {
      const items = await list.json();
      const names = (items as { name: string }[]).map((i) => `${userId}/${i.name}`);
      if (names.length) await fetch(`${url}/storage/v1/object/madem-avatars`, { method: "DELETE", headers: h, body: JSON.stringify({ prefixes: names }) });
    }
    const msgs = await fetch(`${url}/rest/v1/messages?sender_id=eq.${encodeURIComponent(userId)}&media_path=not.is.null&select=media_path&limit=1000`, { headers: h });
    if (msgs.ok) {
      const paths = ((await msgs.json()) as { media_path: string }[]).map((r) => r.media_path);
      for (let i = 0; i < paths.length; i += 100) await fetch(`${url}/storage/v1/object/madem-media`, { method: "DELETE", headers: h, body: JSON.stringify({ prefixes: paths.slice(i, i + 100) }) });
    }
  } catch { /* en iyi çaba: hesap silme dosya temizliğine takılmasın */ }
}
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return respond(405, { error: "Yalnızca POST kullanılabilir." });
  const authHeader = req.headers.get("Authorization") ?? ""; const accessToken = authHeader.replace(/^Bearer\s+/i, "");
  if (!accessToken || accessToken === authHeader) return respond(401, { error: "Oturum gerekli." });
  const url = Deno.env.get("SUPABASE_URL"); const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY"); const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anonKey || !serviceKey) return respond(500, { error: "Hesap silme servisi yapılandırılmamış." });
  try {
    const who = await fetch(`${url}/auth/v1/user`, { headers: { apikey: anonKey, Authorization: `Bearer ${accessToken}` } });
    if (!who.ok) return respond(401, { error: "Oturum geçersiz veya süresi dolmuş." });
    const user = await who.json(); if (!user?.id) return respond(401, { error: "Kullanıcı doğrulanamadı." });
    await purgeStorage(url, serviceKey, user.id);
    const accountDelete = await fetch(`${url}/auth/v1/admin/users/${encodeURIComponent(user.id)}`, { method: "DELETE", headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` } });
    if (!accountDelete.ok) return respond(500, { error: "Hesap silinemedi. Lütfen daha sonra tekrar dene." });
    const profileDelete = await fetch(`${url}/rest/v1/profiles?id=eq.${encodeURIComponent(user.id)}`, { method: "DELETE", headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, Prefer: "return=minimal" } });
    if (!profileDelete.ok) return respond(500, { error: "Hesap silindi ancak profil temizliği tamamlanamadı. Yönetici kontrolü gerekiyor." });
    return respond(200, { ok: true, message: "Hesabın ve profilin kalıcı olarak silindi." });
  } catch { return respond(500, { error: "İşlem tamamlanamadı. Lütfen tekrar dene." }); }
});
