// Firebase Cloud Messaging (HTTP v1) yardımcıları — servis hesabı ile OAuth, mesaj gönderimi.
export type ServiceAccount = { project_id: string; client_email: string; private_key: string; token_uri?: string };

const enc = new TextEncoder();

export function b64url(input: ArrayBuffer | Uint8Array | string): string {
  const bytes = typeof input === 'string' ? enc.encode(input) : input instanceof Uint8Array ? input : new Uint8Array(input);
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function parseServiceAccount(raw: string | undefined | null): ServiceAccount {
  if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT secret tanımlı değil');
  const text = raw.trim().startsWith('{') ? raw : atob(raw.trim()); // düz JSON veya base64 JSON
  const sa = JSON.parse(text);
  if (!sa.project_id || !sa.client_email || !sa.private_key) throw new Error('Servis hesabı JSON eksik alan içeriyor');
  sa.private_key = String(sa.private_key).replace(/\\n/g, '\n');
  return sa as ServiceAccount;
}

async function importKey(pem: string): Promise<CryptoKey> {
  const body = pem.replace(/-----(BEGIN|END) PRIVATE KEY-----/g, '').replace(/\s+/g, '');
  const der = Uint8Array.from(atob(body), (c) => c.charCodeAt(0));
  return crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
}

export async function signJwt(sa: ServiceAccount, nowSec = Math.floor(Date.now() / 1000)): Promise<string> {
  const header = b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claims = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: sa.token_uri || 'https://oauth2.googleapis.com/token',
    iat: nowSec,
    exp: nowSec + 3600,
  }));
  const data = `${header}.${claims}`;
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', await importKey(sa.private_key), enc.encode(data));
  return `${data}.${b64url(sig)}`;
}

let cached: { token: string; exp: number } | null = null;

export async function getAccessToken(sa: ServiceAccount, fetchFn: typeof fetch = fetch): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.exp - 120 > now) return cached.token;
  const res = await fetchFn(sa.token_uri || 'https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: await signJwt(sa, now) }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) throw new Error(`OAuth token alınamadı (${res.status}): ${json.error_description || json.error || 'bilinmeyen hata'}`);
  cached = { token: json.access_token, exp: now + Number(json.expires_in || 3600) };
  return cached.token;
}

export type PushInput = { token: string; title: string; body: string; data: Record<string, string>; tag?: string };
export type PushResult = { token: string; ok: boolean; status: number; unregistered: boolean; error?: string };

export async function sendFcm(sa: ServiceAccount, accessToken: string, m: PushInput, fetchFn: typeof fetch = fetch): Promise<PushResult> {
  const res = await fetchFn(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${accessToken}` },
    body: JSON.stringify({
      message: {
        token: m.token,
        notification: { title: m.title, body: m.body },
        data: m.data,
        android: { priority: 'HIGH', notification: { channel_id: 'messages', sound: 'default', tag: m.tag || undefined } },
      },
    }),
  });
  if (res.ok) { await res.text().catch(() => ''); return { token: m.token, ok: true, status: res.status, unregistered: false }; }
  const err = await res.json().catch(() => ({}));
  const details = JSON.stringify(err?.error?.details ?? '');
  const unregistered = res.status === 404 || err?.error?.status === 'NOT_FOUND' || details.includes('UNREGISTERED');
  return { token: m.token, ok: false, status: res.status, unregistered, error: err?.error?.message || `HTTP ${res.status}` };
}
