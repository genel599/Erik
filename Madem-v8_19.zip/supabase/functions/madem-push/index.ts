// madem-push: notifications satırından Android FCM ve tarayıcı Web Push gönderir.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import webpush from 'npm:web-push@3.6.7';
import { getAccessToken, parseServiceAccount, sendFcm } from './fcm.ts';

const json = (obj: unknown, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });

function safeEqual(a: string, b: string): boolean {
  const x = new TextEncoder().encode(a);
  const y = new TextEncoder().encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceRoleKey) return json({ error: 'server_configuration_error' }, 500);

  try {
    const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: config, error: configError } = await supabase.rpc('madem_get_push_config');
    if (configError) throw configError;

    const expectedSecret = String(config?.madem_push_webhook_secret ?? '');
    const receivedSecret = req.headers.get('x-madem-secret') ?? '';
    if (!expectedSecret || !safeEqual(receivedSecret, expectedSecret)) return json({ error: 'unauthorized' }, 401);

    const body = await req.json().catch(() => null);
    const userId = String(body?.user_id ?? '');
    const notificationId = String(body?.notification_id ?? '');
    if (!UUID.test(userId) || !UUID.test(notificationId)) return json({ error: 'bad_request' }, 400);

    // Push payload is read from the actual notification row, never trusted from the webhook body.
    const { data: notification, error: notificationError } = await supabase
      .from('notifications')
      .select('id,user_id,conversation_id,kind,title,body')
      .eq('id', notificationId)
      .eq('user_id', userId)
      .maybeSingle();
    if (notificationError) throw notificationError;
    if (!notification) return json({ error: 'notification_not_found' }, 404);

    const conversationId = String(notification.conversation_id ?? '');
    const title = String(notification.title ?? 'madem').slice(0, 120);
    const text = String(notification.body ?? '').slice(0, 300);
    const kind = String(notification.kind ?? 'message');

    const [{ data: tokenRows, error: tokenError }, { data: subRows, error: subError }] = await Promise.all([
      supabase.from('device_tokens').select('token').eq('user_id', userId),
      supabase.from('push_subscriptions').select('endpoint,p256dh,auth').eq('user_id', userId)
        .not('endpoint', 'is', null).not('p256dh', 'is', null).not('auth', 'is', null),
    ]);
    if (tokenError) throw tokenError;
    if (subError) throw subError;

    const tokens = (tokenRows ?? []).map((row) => String(row.token)).filter(Boolean);
    const subs = (subRows ?? []).filter((row) => row.endpoint && row.p256dh && row.auth);
    if (!tokens.length && !subs.length) return json({ sent: 0, reason: 'no_targets' });

    const result: Record<string, unknown> = {};

    // Android FCM HTTP v1. Firebase credentials are optional until an Android app is registered.
    if (tokens.length) {
      const rawServiceAccount = config?.madem_firebase_service_account;
      if (!rawServiceAccount) {
        result.fcm = { sent: 0, error: 'firebase_not_configured' };
      } else {
        try {
          const serviceAccount = parseServiceAccount(String(rawServiceAccount));
          const accessToken = await getAccessToken(serviceAccount);
          const data = { type: 'chat', conversationId, kind, notificationId };
          const sends = await Promise.all(tokens.map((token) => sendFcm(serviceAccount, accessToken, {
            token, title, body: text, data, tag: conversationId || undefined,
          })));
          const dead = sends.filter((item) => item.unregistered).map((item) => item.token);
          if (dead.length) await supabase.from('device_tokens').delete().in('token', dead);
          const failed = sends.filter((item) => !item.ok && !item.unregistered);
          if (failed.length) console.error('FCM send failures:', JSON.stringify(failed.map((item) => ({ status: item.status, error: item.error }))));
          result.fcm = { sent: sends.filter((item) => item.ok).length, removed: dead.length, failed: failed.length };
        } catch (error) {
          console.error('FCM error:', error instanceof Error ? error.message : error);
          result.fcm = { sent: 0, error: 'fcm_failed' };
        }
      }
    }

    // Browser/PWA Web Push (VAPID).
    if (subs.length) {
      const publicKey = String(config?.madem_vapid_public_key ?? '');
      const privateKey = String(config?.madem_vapid_private_key ?? '');
      const subject = String(config?.madem_vapid_subject ?? 'https://madem-v812.vercel.app');
      if (!publicKey || !privateKey) {
        result.web = { sent: 0, error: 'vapid_not_configured' };
      } else {
        webpush.setVapidDetails(subject, publicKey, privateKey);
        const payload = JSON.stringify({
          title,
          body: text,
          conversationId: conversationId || null,
          kind,
          tag: conversationId ? `madem-${conversationId}` : 'madem-general',
        });
        const sends = await Promise.all(subs.map(async (subscription) => {
          try {
            await webpush.sendNotification({
              endpoint: String(subscription.endpoint),
              keys: { p256dh: String(subscription.p256dh), auth: String(subscription.auth) },
            }, payload, { TTL: 3600, urgency: 'high' });
            return { endpoint: String(subscription.endpoint), ok: true, gone: false };
          } catch (error) {
            const status = Number((error as { statusCode?: number })?.statusCode ?? 0);
            return { endpoint: String(subscription.endpoint), ok: false, gone: status === 404 || status === 410, status };
          }
        }));
        const gone = sends.filter((item) => item.gone).map((item) => item.endpoint);
        if (gone.length) await supabase.from('push_subscriptions').delete().in('endpoint', gone);
        const failed = sends.filter((item) => !item.ok && !item.gone);
        if (failed.length) console.error('Web Push send failures:', JSON.stringify(failed.map((item) => ({ status: item.status }))));
        result.web = { sent: sends.filter((item) => item.ok).length, removed: gone.length, failed: failed.length };
      }
    }

    return json(result);
  } catch (error) {
    console.error('madem-push error:', error instanceof Error ? error.message : error);
    return json({ error: 'push_failed' }, 500);
  }
});
