import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { checkRateLimit } from "../_shared/rateLimit.ts";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
function respond(status: number, body: Record<string, unknown>) { return new Response(JSON.stringify(body), { status, headers: cors }); }
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return respond(405, { error: "Yalnızca POST kullanılabilir." });
  try {
    const body = await req.json(); const username = String(body?.username ?? "").trim().toLowerCase(); const password = body?.password;
    if (!/^[a-z0-9_]{3,24}$/.test(username) || typeof password !== "string" || password.length < 1 || password.length > 128) return respond(400, { error: "Kullanıcı adı veya şifre hatalı." });
    const limited = await checkRateLimit(req, "login", username, 8, 10 * 60);
    if (limited === null) return respond(503, { error: "Giriş servisi geçici olarak kullanılamıyor. Lütfen daha sonra tekrar dene." });
    if (limited) return respond(429, { error: "Çok fazla deneme yaptın. Birkaç dakika sonra tekrar dene." });
    const url = Deno.env.get("SUPABASE_URL"); const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    if (!url || !anonKey) return respond(500, { error: "Giriş servisi yapılandırılmamış." });
    const authResponse = await fetch(`${url}/auth/v1/token?grant_type=password`, { method: "POST", headers: { apikey: anonKey, "Content-Type": "application/json" }, body: JSON.stringify({ email: `${username}@accounts.madem.invalid`, password }) });
    if (!authResponse.ok) return respond(401, { error: "Kullanıcı adı veya şifre hatalı." });
    const session = await authResponse.json();
    if (!session?.access_token || !session?.refresh_token || !session?.user?.id) return respond(502, { error: "Giriş tamamlanamadı. Lütfen tekrar dene." });
    return respond(200, { access_token: session.access_token, refresh_token: session.refresh_token, expires_in: session.expires_in, expires_at: session.expires_at, token_type: session.token_type, user: { id: session.user.id, username, display_name: session.user.user_metadata?.display_name ?? username } });
  } catch { return respond(400, { error: "İstek okunamadı. Bilgilerini kontrol edip tekrar dene." }); }
});
