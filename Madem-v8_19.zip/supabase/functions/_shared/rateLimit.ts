// Shared, persistent rate limiting for public auth Edge Functions.
// The rate-limit key is hashed before it reaches the database; raw IPs are not stored.
export async function checkRateLimit(
  req: Request,
  bucket: string,
  identity: string,
  maxAttempts: number,
  windowSeconds: number,
): Promise<boolean | null> {
  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return null;

  // Prefer platform/proxy-provided client address headers. The hosting proxy must
  // overwrite these headers for IP-based limiting to be reliable.
  const ip = req.headers.get("cf-connecting-ip")?.trim()
    || req.headers.get("x-real-ip")?.trim()
    || (req.headers.get("x-forwarded-for") || "").split(",")[0].trim();
  // Never place all users into a shared "unknown" bucket. If the trusted proxy
  // did not supply an address, fail closed rather than breaking every user's
  // rate-limit quota or allowing requests without reliable throttling.
  if (!ip || ip.toLowerCase() === "unknown") return null;
  const bytes = new TextEncoder().encode(`${bucket}:${ip}:${identity}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const keyHash = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");

  try {
    const response = await fetch(`${url.replace(/\/$/, "")}/rest/v1/rpc/consume_rate_limit`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        p_bucket: bucket,
        p_key_hash: keyHash,
        p_max_attempts: maxAttempts,
        p_window_seconds: windowSeconds,
      }),
    });
    if (!response.ok) return null;
    return (await response.json()) === true;
  } catch {
    return null;
  }
}
