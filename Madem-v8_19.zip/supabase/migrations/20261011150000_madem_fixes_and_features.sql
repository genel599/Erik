-- v9: hata düzeltmeleri, güvenlik sıkılaştırması ve yeni özelliklerin sunucu tarafı.
-- Uygulamadan önce yedek alın. Yeniden çalıştırılabilir olacak şekilde yazıldı.
begin;

-- 1) push_subscriptions: iki farklı şema çakışıyordu; ikisini de destekleyecek şekilde birleştir.
do $$
begin
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='push_subscriptions' and column_name='endpoint') then
    alter table public.push_subscriptions add column endpoint text;
  end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='push_subscriptions' and column_name='p256dh') then
    alter table public.push_subscriptions add column p256dh text;
  end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='push_subscriptions' and column_name='auth') then
    alter table public.push_subscriptions add column auth text;
  end if;
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='push_subscriptions' and column_name='platform') then
    alter table public.push_subscriptions alter column platform drop not null;
    alter table public.push_subscriptions drop constraint if exists push_subscriptions_platform_check;
  end if;
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='push_subscriptions' and column_name='token') then
    alter table public.push_subscriptions alter column token drop not null;
  end if;
end $$;
create unique index if not exists push_subscriptions_endpoint_key on public.push_subscriptions(endpoint);

-- 2) Medya bucket'ında dosya türü kısıtı olmasın.
update storage.buckets set allowed_mime_types = null where id = 'madem-media';

-- 3) Profil alanlarını sunucu tarafında koru (kullanıcı adı değişmez, uzunluk sınırları).
create or replace function private.profiles_guard() returns trigger language plpgsql set search_path = '' as $$
begin
  if new.username is distinct from old.username then raise exception 'Kullanıcı adı değiştirilemez.'; end if;
  if new.display_name is null or char_length(new.display_name) not between 1 and 60 then raise exception 'Görünen ad 1-60 karakter olmalı.'; end if;
  if char_length(coalesce(new.bio, '')) > 300 then raise exception 'Biyografi en fazla 300 karakter olabilir.'; end if;
  return new;
end $$;
drop trigger if exists madem_profiles_guard on public.profiles;
create trigger madem_profiles_guard before update on public.profiles for each row execute function private.profiles_guard();

-- 4) Yardımcı fonksiyonlar
create or replace function private.is_group_admin(conv uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = (select auth.uid()) and m.role = 'admin' and c.is_group);
$$;
create or replace function private.direct_block_exists(conv uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.conversations c
    join public.conversation_members cm on cm.conversation_id = c.id
    join public.user_blocks b on ((b.blocker_id = (select auth.uid()) and b.blocked_id = cm.user_id) or (b.blocked_id = (select auth.uid()) and b.blocker_id = cm.user_id))
    where c.id = conv and c.is_group = false and cm.user_id <> (select auth.uid()));
$$;

-- 5) Grup ayarları
alter table public.conversations add column if not exists avatar_url text;
alter table public.conversations add column if not exists only_admins_send boolean not null default false;

create or replace function private.can_post(conv uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select private.is_conversation_member(conv)
    and not private.direct_block_exists(conv)
    and (not exists (select 1 from public.conversations c where c.id = conv and c.is_group and c.only_admins_send)
         or private.is_group_admin(conv));
$$;

-- 6) Mesaj türleri (anket) ve mesaj ekleme politikası (engel + yalnız yönetici yazma izni)
alter table public.messages drop constraint if exists messages_message_type_check;
alter table public.messages add constraint messages_message_type_check check (message_type in ('text','image','video','file','voice','system','poll'));

drop policy if exists "members can send messages as themselves" on public.messages;
create policy "members can send messages as themselves" on public.messages for insert to authenticated
  with check (sender_id = (select auth.uid()) and private.can_post(conversation_id));

-- 7) Mesaj güncelleme koruması: yalnızca içerik/silme alanları değişebilir; sabitleme yalnızca RPC ile.
create or replace function private.messages_guard() returns trigger language plpgsql set search_path = '' as $$
begin
  if (select auth.uid()) is null then return new; end if;
  if new.conversation_id <> old.conversation_id or new.sender_id <> old.sender_id or new.created_at <> old.created_at
     or new.message_type <> old.message_type or new.reply_to is distinct from old.reply_to or new.forwarded_from is distinct from old.forwarded_from then
    raise exception 'Bu alanlar değiştirilemez.';
  end if;
  if old.deleted_at is not null and new.deleted_at is null then raise exception 'Silinen mesaj geri getirilemez.'; end if;
  if new.pinned_at is distinct from old.pinned_at and coalesce(current_setting('madem.allow_pin', true), '') <> '1' then
    raise exception 'Mesaj sabitleme yalnızca izinli işlemle yapılabilir.';
  end if;
  return new;
end $$;
drop trigger if exists madem_messages_guard on public.messages;
create trigger madem_messages_guard before update on public.messages for each row execute function private.messages_guard();

-- 8) Aramalarda engel kontrolü ve arama kaydı güncelleme koruması
drop policy if exists "Members can initiate calls" on public.call_sessions;
create policy "Members can initiate calls" on public.call_sessions for insert to authenticated
  with check (initiator_id = (select auth.uid()) and private.is_conversation_member(conversation_id) and not private.direct_block_exists(conversation_id));

drop policy if exists "Call participants can send signals" on public.call_signals;
create policy "Call participants can send signals" on public.call_signals for insert to authenticated
  with check (sender_id = (select auth.uid())
    and exists (select 1 from public.call_sessions cs join public.conversation_members sm on sm.conversation_id = cs.conversation_id join public.conversation_members rm on rm.conversation_id = cs.conversation_id
                where cs.id = call_signals.call_id and sm.user_id = (select auth.uid()) and rm.user_id = call_signals.recipient_id)
    and not exists (select 1 from public.call_sessions cs where cs.id = call_signals.call_id and private.direct_block_exists(cs.conversation_id)));

create or replace function private.call_sessions_guard() returns trigger language plpgsql set search_path = '' as $$
begin
  if (select auth.uid()) is null then return new; end if;
  if new.conversation_id <> old.conversation_id or new.initiator_id <> old.initiator_id or new.call_type <> old.call_type or new.started_at <> old.started_at then
    raise exception 'Arama bilgileri değiştirilemez.';
  end if;
  if old.status in ('rejected','missed','ended','cancelled') and new.status is distinct from old.status then
    raise exception 'Sonlanmış arama güncellenemez.';
  end if;
  return new;
end $$;
drop trigger if exists madem_call_sessions_guard on public.call_sessions;
create trigger madem_call_sessions_guard before update on public.call_sessions for each row execute function private.call_sessions_guard();

-- 9) Grup oluşturma: engel kontrolü
create or replace function public.create_group_conversation(group_title text, member_ids uuid[])
returns uuid language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); new_id uuid; member_count integer;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if group_title is null or length(trim(group_title)) < 1 or length(trim(group_title)) > 80 then raise exception 'Grup adı 1-80 karakter olmalı.'; end if;
  if member_ids is null then raise exception 'En az iki kişi seçmelisin.'; end if;
  select count(distinct x) into member_count from unnest(member_ids) as x where x is not null and x <> actor;
  if member_count < 2 then raise exception 'En az iki farklı üye seçmelisin.'; end if;
  if member_count > 255 then raise exception 'Bir grupta en fazla 256 üye olabilir.'; end if;
  if exists (select 1 from unnest(member_ids) as x left join auth.users u on u.id = x where x is not null and x <> actor and u.id is null) then raise exception 'Seçilen kullanıcılardan biri bulunamadı.'; end if;
  if exists (select 1 from public.user_blocks b where (b.blocker_id = actor and b.blocked_id = any(member_ids)) or (b.blocked_id = actor and b.blocker_id = any(member_ids))) then
    raise exception 'Seçilen kişilerden biriyle aranda engel var.';
  end if;
  insert into public.conversations(is_group, title, created_by) values (true, trim(group_title), actor) returning id into new_id;
  insert into public.conversation_members(conversation_id, user_id, role) values (new_id, actor, 'admin');
  insert into public.conversation_members(conversation_id, user_id, role) select new_id, x, 'member' from (select distinct unnest(member_ids) x) s where x is not null and x <> actor;
  return new_id;
end $$;

-- 10) Grup yönetimi RPC'leri
create or replace function public.set_group_member_role(conv uuid, target uuid, new_role text) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  if new_role not in ('admin','member') then raise exception 'Geçersiz rol.'; end if;
  if new_role = 'member' and target = (select auth.uid()) and (select count(*) from public.conversation_members where conversation_id = conv and role = 'admin') < 2 then
    raise exception 'Son yönetici yöneticiliği bırakamaz.';
  end if;
  update public.conversation_members set role = new_role where conversation_id = conv and user_id = target;
end $$;

create or replace function public.set_group_only_admins(conv uuid, only_admins boolean) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  update public.conversations set only_admins_send = coalesce(only_admins, false) where id = conv;
end $$;

create or replace function public.set_group_avatar(conv uuid, new_url text) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  if new_url is not null and char_length(new_url) > 500 then raise exception 'Adres çok uzun.'; end if;
  update public.conversations set avatar_url = new_url where id = conv;
end $$;

create table if not exists public.group_invites (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  code text not null unique,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.group_invites enable row level security;
drop policy if exists "admins read invites" on public.group_invites;
create policy "admins read invites" on public.group_invites for select to authenticated using (private.is_group_admin(conversation_id));

create or replace function public.create_group_invite(conv uuid) returns text language plpgsql security definer set search_path = '' as $$
declare new_code text := replace(gen_random_uuid()::text, '-', '');
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  insert into public.group_invites(conversation_id, code, created_by) values (conv, new_code, (select auth.uid()))
  on conflict (conversation_id) do update set code = excluded.code, created_by = excluded.created_by, created_at = now();
  return new_code;
end $$;

create or replace function public.revoke_group_invite(conv uuid) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  delete from public.group_invites where conversation_id = conv;
end $$;

create or replace function public.join_group_by_invite(invite text) returns uuid language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); conv uuid;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  select conversation_id into conv from public.group_invites where code = invite;
  if conv is null then raise exception 'Davet bağlantısı geçersiz veya iptal edilmiş.'; end if;
  if (select count(*) from public.conversation_members where conversation_id = conv) >= 256 then raise exception 'Bu grup dolu.'; end if;
  insert into public.conversation_members(conversation_id, user_id, role) values (conv, actor, 'member') on conflict do nothing;
  return conv;
end $$;

-- 11) Mesaj sabitleme: bire birde herkes, grupta yalnızca yöneticiler
create or replace function public.pin_message(msg uuid, pin boolean) returns void language plpgsql security definer set search_path = '' as $$
declare conv uuid; grp boolean;
begin
  select m.conversation_id, c.is_group into conv, grp from public.messages m join public.conversations c on c.id = m.conversation_id where m.id = msg;
  if conv is null or not private.is_conversation_member(conv) then raise exception 'Mesaj bulunamadı.'; end if;
  if grp and not private.is_group_admin(conv) then raise exception 'Gruplarda yalnızca yöneticiler mesaj sabitleyebilir.'; end if;
  perform set_config('madem.allow_pin', '1', true);
  update public.messages set pinned_at = case when pin then now() else null end where id = msg;
end $$;

-- 12) Kendimden sil + favoriler
create table if not exists public.message_hidden (
  user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, message_id)
);
alter table public.message_hidden enable row level security;
drop policy if exists "own hidden select" on public.message_hidden;
drop policy if exists "own hidden insert" on public.message_hidden;
drop policy if exists "own hidden delete" on public.message_hidden;
create policy "own hidden select" on public.message_hidden for select to authenticated using (user_id = (select auth.uid()));
create policy "own hidden insert" on public.message_hidden for insert to authenticated with check (user_id = (select auth.uid()) and exists (select 1 from public.messages m where m.id = message_id and private.is_conversation_member(m.conversation_id)));
create policy "own hidden delete" on public.message_hidden for delete to authenticated using (user_id = (select auth.uid()));

create table if not exists public.message_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, message_id)
);
alter table public.message_favorites enable row level security;
drop policy if exists "own favorites select" on public.message_favorites;
drop policy if exists "own favorites insert" on public.message_favorites;
drop policy if exists "own favorites delete" on public.message_favorites;
create policy "own favorites select" on public.message_favorites for select to authenticated using (user_id = (select auth.uid()));
create policy "own favorites insert" on public.message_favorites for insert to authenticated with check (user_id = (select auth.uid()) and exists (select 1 from public.messages m where m.id = message_id and private.is_conversation_member(m.conversation_id)));
create policy "own favorites delete" on public.message_favorites for delete to authenticated using (user_id = (select auth.uid()));

-- 13) Anketler (yalnızca gruplarda)
create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null unique references public.messages(id) on delete cascade,
  question text not null check (char_length(question) between 1 and 200),
  multiple boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  label text not null check (char_length(label) between 1 and 100),
  position integer not null default 0
);
create table if not exists public.poll_votes (
  poll_id uuid not null references public.polls(id) on delete cascade,
  option_id uuid not null references public.poll_options(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (option_id, user_id)
);
create index if not exists poll_votes_poll_idx on public.poll_votes(poll_id);
alter table public.polls enable row level security;
alter table public.poll_options enable row level security;
alter table public.poll_votes enable row level security;
drop policy if exists "members read polls" on public.polls;
drop policy if exists "members read poll options" on public.poll_options;
drop policy if exists "members read poll votes" on public.poll_votes;
create policy "members read polls" on public.polls for select to authenticated using (exists (select 1 from public.messages m where m.id = polls.message_id and private.is_conversation_member(m.conversation_id)));
create policy "members read poll options" on public.poll_options for select to authenticated using (exists (select 1 from public.polls p join public.messages m on m.id = p.message_id where p.id = poll_options.poll_id and private.is_conversation_member(m.conversation_id)));
create policy "members read poll votes" on public.poll_votes for select to authenticated using (exists (select 1 from public.polls p join public.messages m on m.id = p.message_id where p.id = poll_votes.poll_id and private.is_conversation_member(m.conversation_id)));

create or replace function public.create_poll(conv uuid, question text, options text[], multiple boolean default false) returns uuid
language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); msg_id uuid; poll_id uuid; opt text; i integer := 0; clean text[];
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if not exists (select 1 from public.conversations c where c.id = conv and c.is_group) then raise exception 'Anketler yalnızca gruplarda kullanılabilir.'; end if;
  if not private.can_post(conv) then raise exception 'Bu grupta mesaj gönderme iznin yok.'; end if;
  if question is null or char_length(trim(question)) not between 1 and 200 then raise exception 'Soru 1-200 karakter olmalı.'; end if;
  select array_agg(trim(x)) into clean from unnest(options) as x where trim(x) <> '';
  if clean is null or array_length(clean, 1) < 2 or array_length(clean, 1) > 10 then raise exception 'Anket için 2 ile 10 arasında seçenek gerekli.'; end if;
  insert into public.messages(conversation_id, sender_id, content, message_type) values (conv, actor, trim(question), 'poll') returning id into msg_id;
  insert into public.polls(message_id, question, multiple) values (msg_id, trim(question), coalesce(multiple, false)) returning id into poll_id;
  foreach opt in array clean loop
    i := i + 1;
    insert into public.poll_options(poll_id, label, position) values (poll_id, left(opt, 100), i);
  end loop;
  return msg_id;
end $$;

create or replace function public.vote_poll(option uuid) returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); p record; conv uuid;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  select pl.id as pid, pl.multiple, m.conversation_id into p from public.poll_options o join public.polls pl on pl.id = o.poll_id join public.messages m on m.id = pl.message_id where o.id = option;
  if p.pid is null then raise exception 'Seçenek bulunamadı.'; end if;
  if not private.is_conversation_member(p.conversation_id) then raise exception 'Bu anketin üyesi değilsin.'; end if;
  if exists (select 1 from public.poll_votes where option_id = option and user_id = actor) then
    delete from public.poll_votes where option_id = option and user_id = actor;
  else
    if not p.multiple then delete from public.poll_votes where poll_id = p.pid and user_id = actor; end if;
    insert into public.poll_votes(poll_id, option_id, user_id) values (p.pid, option, actor);
  end if;
end $$;

-- 14) Mesaj arama (yalnızca üyesi olunan sohbetler, kendimden silinenler hariç)
create or replace function public.search_messages(term text)
returns table (message_id uuid, conversation_id uuid, content text, created_at timestamptz, sender_id uuid)
language sql stable security invoker set search_path = public as $$
  select m.id, m.conversation_id, m.content, m.created_at, m.sender_id
  from public.messages m
  where m.deleted_at is null
    and char_length(trim(term)) >= 2
    and m.content ilike '%' || replace(replace(replace(trim(term), '\', '\\'), '%', '\%'), '_', '\_') || '%'
    and not exists (select 1 from public.message_hidden h where h.message_id = m.id and h.user_id = (select auth.uid()))
  order by m.created_at desc
  limit 40;
$$;

-- 15) Yetkiler
revoke all on function public.set_group_member_role(uuid, uuid, text) from public, anon;
revoke all on function public.set_group_only_admins(uuid, boolean) from public, anon;
revoke all on function public.set_group_avatar(uuid, text) from public, anon;
revoke all on function public.create_group_invite(uuid) from public, anon;
revoke all on function public.revoke_group_invite(uuid) from public, anon;
revoke all on function public.join_group_by_invite(text) from public, anon;
revoke all on function public.pin_message(uuid, boolean) from public, anon;
revoke all on function public.create_poll(uuid, text, text[], boolean) from public, anon;
revoke all on function public.vote_poll(uuid) from public, anon;
revoke all on function public.search_messages(text) from public, anon;
revoke all on function public.create_group_conversation(text, uuid[]) from public, anon;
grant execute on function public.set_group_member_role(uuid, uuid, text) to authenticated;
grant execute on function public.set_group_only_admins(uuid, boolean) to authenticated;
grant execute on function public.set_group_avatar(uuid, text) to authenticated;
grant execute on function public.create_group_invite(uuid) to authenticated;
grant execute on function public.revoke_group_invite(uuid) to authenticated;
grant execute on function public.join_group_by_invite(text) to authenticated;
grant execute on function public.pin_message(uuid, boolean) to authenticated;
grant execute on function public.create_poll(uuid, text, text[], boolean) to authenticated;
grant execute on function public.vote_poll(uuid) to authenticated;
grant execute on function public.search_messages(text) to authenticated;
grant execute on function public.create_group_conversation(text, uuid[]) to authenticated;

-- 16) Realtime
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'poll_votes') then
    alter publication supabase_realtime add table public.poll_votes;
  end if;
exception when undefined_object then null;
end $$;

commit;
