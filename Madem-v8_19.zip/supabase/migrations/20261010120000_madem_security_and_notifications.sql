-- Security fixes for media deletion and notification preferences.
-- This migration is safe to apply to the existing madem project.
begin;

drop policy if exists "Uploader or conversation members can delete media" on storage.objects;
create policy "Uploader or conversation members can delete media" on storage.objects
for delete to authenticated
using (
  bucket_id = 'madem-media'
  and owner = (select auth.uid())::text
  and exists (
    select 1 from public.conversation_members cm
    where cm.user_id = (select auth.uid())
      and (storage.foldername(name))[1] = cm.conversation_id::text
  )
);

create or replace function public.notify_conversation_members_on_message()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  is_group_chat boolean;
  sender_name text;
begin
  select is_group into is_group_chat from public.conversations where id = new.conversation_id;
  select coalesce(display_name, username, 'Bir kullanıcı') into sender_name from public.profiles where id = new.sender_id;

  insert into public.notifications(user_id, actor_id, conversation_id, message_id, kind, title, body)
  select cm.user_id,
         new.sender_id,
         new.conversation_id,
         new.id,
         case when new.reply_to is not null then 'reply' when is_group_chat then 'group' else 'message' end,
         case when is_group_chat then coalesce((select title from public.conversations where id = new.conversation_id), 'Grup mesajı') else sender_name end,
         left(coalesce(new.content, 'Yeni medya'), 500)
  from public.conversation_members cm
  left join public.user_notification_preferences pref on pref.user_id = cm.user_id
  left join public.conversation_user_state state on state.conversation_id = new.conversation_id and state.user_id = cm.user_id
  where cm.conversation_id = new.conversation_id
    and cm.user_id <> new.sender_id
    and coalesce(state.muted_until, '-infinity'::timestamptz) <= now()
    and case
      when is_group_chat then coalesce(pref.groups_enabled, true)
      else coalesce(pref.messages_enabled, true)
    end;
  return new;
end;
$$;
commit;
