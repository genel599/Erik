create or replace function public.create_group_conversation(group_title text, member_ids uuid[])
returns uuid language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); new_id uuid; member_count integer;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if group_title is null or length(trim(group_title)) < 1 or length(trim(group_title)) > 80 then raise exception 'Grup adı 1-80 karakter olmalı.'; end if;
  if member_ids is null then raise exception 'En az iki kişi seçmelisin.'; end if;
  select count(distinct x) into member_count from unnest(member_ids) as x where x is not null and x <> actor;
  if member_count < 2 then raise exception 'En az iki farklı üye seçmelisin.'; end if;
  if exists (select 1 from unnest(member_ids) as x left join auth.users u on u.id=x where x is not null and x<>actor and u.id is null) then raise exception 'Seçilen kullanıcılardan biri bulunamadı.'; end if;
  insert into public.conversations(is_group,title,created_by) values(true,trim(group_title),actor) returning id into new_id;
  insert into public.conversation_members(conversation_id,user_id,role) values(new_id,actor,'admin');
  insert into public.conversation_members(conversation_id,user_id,role) select new_id,x,'member' from (select distinct unnest(member_ids) x) s where x is not null and x<>actor;
  return new_id;
end; $$;
revoke all on function public.create_group_conversation(text,uuid[]) from public;
grant execute on function public.create_group_conversation(text,uuid[]) to authenticated;
