begin;
create or replace function public.notify_conversation_members_on_call() returns trigger language plpgsql security definer set search_path=public as $$ declare caller_name text; begin select coalesce(display_name,username,'Bir kullanıcı') into caller_name from public.profiles where id=new.initiator_id; insert into public.notifications(user_id,actor_id,conversation_id,kind,title,body) select cm.user_id,new.initiator_id,new.conversation_id,'call',caller_name,case when new.call_type='video' then 'Görüntülü arama' else 'Sesli arama' end from public.conversation_members cm where cm.conversation_id=new.conversation_id and cm.user_id<>new.initiator_id; return new; end $$;
drop trigger if exists madem_notify_members_on_call on public.call_sessions;
create trigger madem_notify_members_on_call after insert on public.call_sessions for each row execute function public.notify_conversation_members_on_call();
commit;
