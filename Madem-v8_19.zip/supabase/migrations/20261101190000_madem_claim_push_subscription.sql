-- madem v8_18: aynı cihazda hesap değişince web push aboneliği giriş yapan hesaba geçer
create or replace function public.claim_push_subscription(p_endpoint text, p_p256dh text, p_auth text)
returns void language plpgsql security definer set search_path = '' as $$
declare v_user uuid := (select auth.uid());
begin
  if v_user is null then raise exception 'not authenticated'; end if;
  if p_endpoint is null or length(p_endpoint) < 20 or length(p_endpoint) > 2048 or p_endpoint !~ '^https://' then raise exception 'invalid endpoint'; end if;
  if p_p256dh is null or p_auth is null then raise exception 'invalid keys'; end if;
  insert into public.push_subscriptions(user_id, endpoint, p256dh, auth)
  values (v_user, p_endpoint, p_p256dh, p_auth)
  on conflict (endpoint) do update set user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth;
end $$;
revoke all on function public.claim_push_subscription(text, text, text) from public, anon;
grant execute on function public.claim_push_subscription(text, text, text) to authenticated;
