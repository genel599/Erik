begin;
create extension if not exists pg_net;
create schema if not exists private;

alter table public.push_subscriptions add column if not exists endpoint text;
alter table public.push_subscriptions add column if not exists p256dh text;
alter table public.push_subscriptions add column if not exists auth text;
alter table public.push_subscriptions alter column platform drop not null;
alter table public.push_subscriptions alter column token drop not null;
create unique index if not exists push_subscriptions_endpoint_uidx on public.push_subscriptions(endpoint);
create index if not exists push_subscriptions_user_endpoint_idx on public.push_subscriptions(user_id) where endpoint is not null;

create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null,
  platform text not null default 'android' check (platform in ('android','ios')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists device_tokens_token_uidx on public.device_tokens(token);
create index if not exists device_tokens_user_id_idx on public.device_tokens(user_id);
alter table public.device_tokens enable row level security;
drop policy if exists "madem_device_tokens_select_own" on public.device_tokens;
drop policy if exists "madem_device_tokens_delete_own" on public.device_tokens;
create policy "madem_device_tokens_select_own" on public.device_tokens for select to authenticated using (user_id = (select auth.uid()));
create policy "madem_device_tokens_delete_own" on public.device_tokens for delete to authenticated using (user_id = (select auth.uid()));
revoke all on public.device_tokens from anon;
grant select, delete on public.device_tokens to authenticated;
grant all on public.device_tokens to service_role;

create or replace function public.register_device_token(p_token text, p_platform text default 'android')
returns void language plpgsql security definer set search_path = '' as $$
declare v_user uuid := (select auth.uid());
begin
  if v_user is null then raise exception 'not authenticated'; end if;
  if p_token is null or length(p_token) < 20 or length(p_token) > 4096 then raise exception 'invalid device token'; end if;
  if coalesce(p_platform, 'android') not in ('android','ios') then raise exception 'invalid platform'; end if;
  insert into public.device_tokens(user_id, token, platform, updated_at)
  values (v_user, p_token, coalesce(p_platform, 'android'), now())
  on conflict (token) do update set user_id = excluded.user_id, platform = excluded.platform, updated_at = now();
end;
$$;
revoke all on function public.register_device_token(text,text) from public, anon;
grant execute on function public.register_device_token(text,text) to authenticated;

create or replace function public.unregister_device_token(p_token text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if (select auth.uid()) is null then raise exception 'not authenticated'; end if;
  delete from public.device_tokens where token = p_token and user_id = (select auth.uid());
end;
$$;
revoke all on function public.unregister_device_token(text) from public, anon;
grant execute on function public.unregister_device_token(text) to authenticated;

create or replace function public.madem_get_push_config()
returns jsonb language sql stable security definer set search_path = '' as $$
  select coalesce(jsonb_object_agg(name, decrypted_secret), '{}'::jsonb)
  from vault.decrypted_secrets
  where name in ('madem_push_webhook_secret','madem_vapid_public_key','madem_vapid_private_key','madem_vapid_subject','madem_firebase_service_account');
$$;
revoke all on function public.madem_get_push_config() from public, anon, authenticated;
grant execute on function public.madem_get_push_config() to service_role;

create or replace function private.madem_push_on_notification()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_secret text;
  v_url text := 'https://aabmnntcmkyosmimjghw.supabase.co/functions/v1/madem-push';
begin
  select decrypted_secret into v_secret from vault.decrypted_secrets where name = 'madem_push_webhook_secret';
  if v_secret is null then raise warning 'madem push skipped: webhook secret is not configured in Vault'; return new; end if;
  if not exists (select 1 from public.device_tokens where user_id = new.user_id)
     and not exists (select 1 from public.push_subscriptions where user_id = new.user_id and endpoint is not null and p256dh is not null and auth is not null) then
    return new;
  end if;
  perform net.http_post(
    url := v_url,
    body := jsonb_build_object('notification_id', new.id, 'user_id', new.user_id),
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-madem-secret', v_secret),
    timeout_milliseconds := 5000
  );
  return new;
exception when others then
  raise warning 'madem push trigger failed: %', sqlerrm;
  return new;
end;
$$;
drop trigger if exists madem_push_on_notification on public.notifications;
create trigger madem_push_on_notification after insert on public.notifications for each row execute function private.madem_push_on_notification();
commit;
