-- madem v8_7: grup sistem mesajları ("X gruba katıldı / gruptan çıkarıldı ...")
begin;

-- Yardımcılar (yalnızca diğer security definer fonksiyonlar çağırır)
create or replace function private.profile_label(uid uuid) returns text language sql stable security definer set search_path = '' as $$
  select coalesce(nullif(btrim(display_name), ''), username, 'Bir kullanıcı') from public.profiles where id = uid;
$$;
create or replace function private.post_system_message(conv uuid, actor uuid, body text) returns void language plpgsql security definer set search_path = '' as $$
begin
  insert into public.messages(conversation_id, sender_id, content, message_type) values (conv, actor, left(body, 500), 'system');
end $$;
revoke all on function private.profile_label(uuid) from public, anon, authenticated;
revoke all on function private.post_system_message(uuid, uuid, text) from public, anon, authenticated;

-- İstemciler sahte sistem mesajı gönderemesin
drop policy if exists "members can send messages as themselves" on public.messages;
create policy "members can send messages as themselves" on public.messages for insert to authenticated
  with check (sender_id = (select auth.uid()) and private.can_post(conversation_id) and message_type <> 'system');

-- Sistem mesajları bildirim/push üretmesin
drop trigger if exists madem_notify_members_on_message on public.messages;
create trigger madem_notify_members_on_message after insert on public.messages for each row
  when (new.message_type <> 'system') execute function public.notify_conversation_members_on_message();

-- Üye ekleme
create or replace function public.add_group_members(conv uuid, member_ids uuid[])
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); current_count integer; names text[];
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and m.role = 'admin' and c.is_group) then
    raise exception 'Bu işlem için grup yöneticisi olmalısın.';
  end if;
  select count(*) into current_count from public.conversation_members where conversation_id = conv;
  if current_count + coalesce(array_length(member_ids, 1), 0) > 256 then raise exception 'Bir grupta en fazla 256 üye olabilir.'; end if;
  with ins as (
    insert into public.conversation_members(conversation_id, user_id, role)
    select conv, u.id, 'member'
    from (select distinct unnest(member_ids) as id) x
    join auth.users u on u.id = x.id
    where not exists (select 1 from public.user_blocks b where (b.blocker_id = actor and b.blocked_id = u.id) or (b.blocker_id = u.id and b.blocked_id = actor))
    on conflict do nothing
    returning user_id
  )
  select array_agg(private.profile_label(user_id)) into names from ins;
  if names is not null then
    perform private.post_system_message(conv, actor, array_to_string(names, ', ') || ' gruba eklendi');
  end if;
end $$;

-- Üye çıkarma
create or replace function public.remove_group_member(conv uuid, target uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if target = actor then raise exception 'Kendini çıkarmak için gruptan ayrıl.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and m.role = 'admin' and c.is_group) then
    raise exception 'Bu işlem için grup yöneticisi olmalısın.';
  end if;
  if exists (select 1 from public.conversation_members where conversation_id = conv and user_id = target) then
    perform private.post_system_message(conv, actor, private.profile_label(target) || ' gruptan çıkarıldı');
  end if;
  delete from public.conversation_members where conversation_id = conv and user_id = target;
end $$;

-- Gruptan ayrılma
create or replace function public.leave_group_conversation(conv uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); remaining integer;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and c.is_group) then
    raise exception 'Bu grubun üyesi değilsin.';
  end if;
  select count(*) into remaining from public.conversation_members where conversation_id = conv;
  if remaining > 1 then
    perform private.post_system_message(conv, actor, private.profile_label(actor) || ' gruptan ayrıldı');
  end if;
  delete from public.conversation_members where conversation_id = conv and user_id = actor;
  select count(*) into remaining from public.conversation_members where conversation_id = conv;
  if remaining = 0 then
    delete from public.conversations where id = conv;
  elsif not exists (select 1 from public.conversation_members where conversation_id = conv and role = 'admin') then
    update public.conversation_members set role = 'admin'
    where conversation_id = conv
      and user_id = (select user_id from public.conversation_members where conversation_id = conv order by joined_at asc limit 1);
  end if;
end $$;

-- Davet bağlantısıyla katılma
create or replace function public.join_group_by_invite(invite text) returns uuid language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); conv uuid; needs boolean;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  select conversation_id into conv from public.group_invites where code = invite;
  if conv is null then raise exception 'Davet bağlantısı geçersiz veya iptal edilmiş.'; end if;
  if exists (select 1 from public.conversation_members where conversation_id = conv and user_id = actor) then return conv; end if;
  if (select count(*) from public.conversation_members where conversation_id = conv) >= 256 then raise exception 'Bu grup dolu.'; end if;
  select require_join_approval into needs from public.conversations where id = conv;
  if coalesce(needs, false) then
    insert into public.group_join_requests(conversation_id, user_id) values (conv, actor) on conflict do nothing;
    return null; -- onay bekleniyor
  end if;
  insert into public.conversation_members(conversation_id, user_id, role) values (conv, actor, 'member') on conflict do nothing;
  perform private.post_system_message(conv, actor, private.profile_label(actor) || ' gruba katıldı');
  return conv;
end $$;

-- Katılma isteği onayı
create or replace function public.resolve_group_join_request(req uuid, approve boolean) returns void language plpgsql security definer set search_path = '' as $$
declare r public.group_join_requests%rowtype;
begin
  select * into r from public.group_join_requests where id = req;
  if r.id is null then raise exception 'İstek bulunamadı.'; end if;
  if not private.is_group_admin(r.conversation_id) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  if approve then
    if (select count(*) from public.conversation_members where conversation_id = r.conversation_id) >= 256 then raise exception 'Bu grup dolu.'; end if;
    if not exists (select 1 from public.conversation_members where conversation_id = r.conversation_id and user_id = r.user_id) then
      insert into public.conversation_members(conversation_id, user_id, role) values (r.conversation_id, r.user_id, 'member') on conflict do nothing;
      perform private.post_system_message(r.conversation_id, r.user_id, private.profile_label(r.user_id) || ' gruba katıldı');
    end if;
  end if;
  delete from public.group_join_requests where id = req;
end $$;

-- Sohbet özeti: son mesaj türü; sistem mesajı "okunmamış" sayılmaz
drop function if exists public.madem_conversation_summaries(uuid[]);
create function public.madem_conversation_summaries(conversation_ids uuid[])
returns table (
  conversation_id uuid,
  last_message_id uuid,
  last_content text,
  last_created_at timestamptz,
  last_sender_id uuid,
  last_read_at timestamptz,
  last_message_type text
)
language sql stable security invoker set search_path = public as $$
  select c.id, msg.id, msg.content, msg.created_at, msg.sender_id,
         coalesce(receipt.read_at, case when msg.message_type = 'system' then msg.created_at end),
         msg.message_type
  from public.conversations c
  join public.conversation_members mine on mine.conversation_id = c.id and mine.user_id = (select auth.uid())
  left join lateral (
    select m.id, m.content, m.created_at, m.sender_id, m.message_type
    from public.messages m where m.conversation_id = c.id
    order by m.created_at desc limit 1
  ) msg on true
  left join public.message_receipts receipt on receipt.message_id = msg.id and receipt.user_id = (select auth.uid())
  where c.id = any(conversation_ids);
$$;

revoke all on function public.add_group_members(uuid, uuid[]) from public, anon;
revoke all on function public.remove_group_member(uuid, uuid) from public, anon;
revoke all on function public.leave_group_conversation(uuid) from public, anon;
revoke all on function public.join_group_by_invite(text) from public, anon;
revoke all on function public.resolve_group_join_request(uuid, boolean) from public, anon;
revoke all on function public.madem_conversation_summaries(uuid[]) from public, anon;
grant execute on function public.add_group_members(uuid, uuid[]) to authenticated;
grant execute on function public.remove_group_member(uuid, uuid) to authenticated;
grant execute on function public.leave_group_conversation(uuid) to authenticated;
grant execute on function public.join_group_by_invite(text) to authenticated;
grant execute on function public.resolve_group_join_request(uuid, boolean) to authenticated;
grant execute on function public.madem_conversation_summaries(uuid[]) to authenticated;
-- Aramada sistem mesajları çıkmasın
create or replace function public.search_messages(term text)
returns table (message_id uuid, conversation_id uuid, content text, created_at timestamptz, sender_id uuid)
language sql stable security invoker set search_path = public as $$
  select m.id, m.conversation_id, m.content, m.created_at, m.sender_id
  from public.messages m
  where m.deleted_at is null
    and m.message_type <> 'system'
    and char_length(trim(term)) >= 2
    and m.content ilike '%' || replace(replace(replace(trim(term), '\', '\\'), '%', '\%'), '_', '\_') || '%'
    and not exists (select 1 from public.message_hidden h where h.message_id = m.id and h.user_id = (select auth.uid()))
  order by m.created_at desc
  limit 40;
$$;
revoke all on function public.search_messages(text) from public, anon;
grant execute on function public.search_messages(text) to authenticated;
commit;
