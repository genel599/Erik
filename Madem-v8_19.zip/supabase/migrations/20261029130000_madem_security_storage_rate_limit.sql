-- Madem: persistent auth rate limits and media upload MIME restrictions.
-- Apply this migration before deploying the updated madem-login/madem-register functions.
begin;

create table if not exists private.rate_limit_buckets (
  bucket text not null,
  key_hash text not null,
  window_started_at timestamptz not null,
  attempts integer not null check (attempts >= 1),
  primary key (bucket, key_hash)
);
revoke all on table private.rate_limit_buckets from public, anon, authenticated, service_role;

create or replace function public.consume_rate_limit(
  p_bucket text,
  p_key_hash text,
  p_max_attempts integer,
  p_window_seconds integer
) returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_attempts integer;
  v_now timestamptz := clock_timestamp();
begin
  if p_bucket is null or p_bucket not in ('login', 'register')
     or p_key_hash is null or p_key_hash !~ '^[0-9a-f]{64}$'
     or p_max_attempts is null or p_window_seconds is null
     or p_max_attempts < 1 or p_window_seconds < 1 or p_window_seconds > 86400 then
    raise exception 'Invalid rate-limit arguments';
  end if;

  insert into private.rate_limit_buckets (bucket, key_hash, window_started_at, attempts)
  values (p_bucket, p_key_hash, v_now, 1)
  on conflict (bucket, key_hash) do update
    set window_started_at = case
          when private.rate_limit_buckets.window_started_at + make_interval(secs => p_window_seconds) <= v_now then v_now
          else private.rate_limit_buckets.window_started_at
        end,
        attempts = case
          when private.rate_limit_buckets.window_started_at + make_interval(secs => p_window_seconds) <= v_now then 1
          else private.rate_limit_buckets.attempts + 1
        end
  returning attempts into v_attempts;

  -- Occasional cleanup keeps expired hashes from accumulating indefinitely.
  if random() < 0.01 then
    delete from private.rate_limit_buckets
      where window_started_at < v_now - interval '2 days';
  end if;

  return v_attempts > p_max_attempts;
end;
$$;
revoke all on function public.consume_rate_limit(text, text, integer, integer) from public, anon, authenticated;
grant execute on function public.consume_rate_limit(text, text, integer, integer) to service_role;

-- Keep uploads private and limited to media/document formats supported by the UI.
update storage.buckets
set public = false,
    file_size_limit = 52428800,
    allowed_mime_types = array[
      'image/jpeg','image/png','image/webp','image/gif',
      'video/mp4','video/webm',
      'audio/webm','audio/ogg','audio/mpeg','audio/mp4',
      'application/pdf','text/plain','application/zip',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    ]
where id = 'madem-media';

commit;
