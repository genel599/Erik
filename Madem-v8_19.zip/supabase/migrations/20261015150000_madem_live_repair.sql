-- Madem canlı backend uyumluluk onarımı (idempotent).
-- Uygulama anket, davet, mesajı kendinden gizleme ve cihaz oturumu tablolarını kullanır.
begin;
alter table public.conversations add column if not exists avatar_url text;
alter table public.conversations add column if not exists only_admins_send boolean not null default false;
alter table public.messages drop constraint if exists messages_message_type_check;
alter table public.messages add constraint messages_message_type_check check (message_type in ('text','image','video','file','voice','system','poll'));

create table if not exists public.group_invites (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  code text not null unique,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.group_invites enable row level security;
drop policy if exists "admins read invites" on public.group_invites;
create policy "admins read invites" on public.group_invites for select to authenticated using (private.is_group_admin(conversation_id));

create table if not exists public.message_hidden (
  user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(), primary key (user_id,message_id)
);
alter table public.message_hidden enable row level security;
drop policy if exists "own hidden select" on public.message_hidden;
drop policy if exists "own hidden insert" on public.message_hidden;
drop policy if exists "own hidden delete" on public.message_hidden;
create policy "own hidden select" on public.message_hidden for select to authenticated using (user_id=(select auth.uid()));
create policy "own hidden insert" on public.message_hidden for insert to authenticated with check (user_id=(select auth.uid()) and exists(select 1 from public.messages m where m.id=message_id and private.is_conversation_member(m.conversation_id)));
create policy "own hidden delete" on public.message_hidden for delete to authenticated using (user_id=(select auth.uid()));

create table if not exists public.polls (id uuid primary key default gen_random_uuid(), message_id uuid not null unique references public.messages(id) on delete cascade, question text not null check(char_length(question) between 1 and 200), multiple boolean not null default false, created_at timestamptz not null default now());
create table if not exists public.poll_options (id uuid primary key default gen_random_uuid(), poll_id uuid not null references public.polls(id) on delete cascade, label text not null check(char_length(label) between 1 and 100), position integer not null default 0);
create table if not exists public.poll_votes (poll_id uuid not null references public.polls(id) on delete cascade, option_id uuid not null references public.poll_options(id) on delete cascade, user_id uuid not null references auth.users(id) on delete cascade, created_at timestamptz not null default now(), primary key(option_id,user_id));
create index if not exists poll_votes_poll_idx on public.poll_votes(poll_id);
alter table public.polls enable row level security; alter table public.poll_options enable row level security; alter table public.poll_votes enable row level security;
drop policy if exists "members read polls" on public.polls;
drop policy if exists "members read poll options" on public.poll_options;
drop policy if exists "members read poll votes" on public.poll_votes;
create policy "members read polls" on public.polls for select to authenticated using(exists(select 1 from public.messages m where m.id=polls.message_id and private.is_conversation_member(m.conversation_id)));
create policy "members read poll options" on public.poll_options for select to authenticated using(exists(select 1 from public.polls p join public.messages m on m.id=p.message_id where p.id=poll_options.poll_id and private.is_conversation_member(m.conversation_id)));
create policy "members read poll votes" on public.poll_votes for select to authenticated using(exists(select 1 from public.polls p join public.messages m on m.id=p.message_id where p.id=poll_votes.poll_id and private.is_conversation_member(m.conversation_id)));

create table if not exists public.device_sessions (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, device_id text not null, platform text not null default 'web', label text not null default '', created_at timestamptz not null default now(), last_seen_at timestamptz not null default now(), revoked_at timestamptz, unique(user_id,device_id));
create index if not exists device_sessions_user_last_seen_idx on public.device_sessions(user_id,last_seen_at desc);
alter table public.device_sessions enable row level security;
drop policy if exists "users can view own device sessions" on public.device_sessions;
create policy "users can view own device sessions" on public.device_sessions for select to authenticated using(user_id=(select auth.uid()));
revoke insert,update,delete on public.device_sessions from anon,authenticated;

-- No anonymous access to privileged RPCs. Their authenticated versions validate auth.uid()/membership/admin.
revoke all on function public.create_group_conversation(text,uuid[]) from public,anon;
revoke all on function public.create_group_invite(uuid) from public,anon;
revoke all on function public.revoke_group_invite(uuid) from public,anon;
revoke all on function public.join_group_by_invite(text) from public,anon;
revoke all on function public.create_poll(uuid,text,text[],boolean) from public,anon;
revoke all on function public.vote_poll(uuid) from public,anon;
revoke all on function public.set_group_member_role(uuid,uuid,text) from public,anon;
revoke all on function public.set_group_only_admins(uuid,boolean) from public,anon;
revoke all on function public.set_group_avatar(uuid,text) from public,anon;
revoke all on function public.register_device_session(text,text,text) from public,anon;
revoke all on function public.rename_group_conversation(uuid,text) from public,anon;
revoke all on function public.add_group_members(uuid,uuid[]) from public,anon;
revoke all on function public.remove_group_member(uuid,uuid) from public,anon;
revoke all on function public.leave_group_conversation(uuid) from public,anon;
revoke all on function public.pin_message(uuid,boolean) from public,anon;
revoke all on function public.search_messages(text) from public,anon;
revoke all on function public.madem_conversation_summaries(uuid[]) from public,anon;
grant execute on function public.create_group_conversation(text,uuid[]) to authenticated;
grant execute on function public.create_group_invite(uuid) to authenticated;
grant execute on function public.revoke_group_invite(uuid) to authenticated;
grant execute on function public.join_group_by_invite(text) to authenticated;
grant execute on function public.create_poll(uuid,text,text[],boolean) to authenticated;
grant execute on function public.vote_poll(uuid) to authenticated;
grant execute on function public.set_group_member_role(uuid,uuid,text) to authenticated;
grant execute on function public.set_group_only_admins(uuid,boolean) to authenticated;
grant execute on function public.set_group_avatar(uuid,text) to authenticated;
grant execute on function public.register_device_session(text,text,text) to authenticated;
grant execute on function public.rename_group_conversation(uuid,text) to authenticated;
grant execute on function public.add_group_members(uuid,uuid[]) to authenticated;
grant execute on function public.remove_group_member(uuid,uuid) to authenticated;
grant execute on function public.leave_group_conversation(uuid) to authenticated;
grant execute on function public.pin_message(uuid,boolean) to authenticated;
grant execute on function public.search_messages(text) to authenticated;
grant execute on function public.madem_conversation_summaries(uuid[]) to authenticated;
revoke all on function public.notify_conversation_members_on_call() from public,anon,authenticated;
revoke all on function public.notify_conversation_members_on_message() from public,anon,authenticated;
revoke all on function public.madem_latest_conversation_messages(uuid[]) from public,anon;
alter function public.madem_latest_conversation_messages(uuid[]) security invoker;
grant execute on function public.madem_latest_conversation_messages(uuid[]) to authenticated;
revoke all on function public.open_direct_conversation(uuid) from public,anon;
grant execute on function public.open_direct_conversation(uuid) to authenticated;

create index if not exists call_sessions_conversation_id_idx on public.call_sessions(conversation_id);
create index if not exists call_sessions_initiator_id_idx on public.call_sessions(initiator_id);
create index if not exists call_signals_call_id_idx on public.call_signals(call_id);
create index if not exists call_signals_recipient_id_idx on public.call_signals(recipient_id);
create index if not exists call_signals_sender_id_idx on public.call_signals(sender_id);
create index if not exists conversation_user_state_user_id_idx on public.conversation_user_state(user_id);
create index if not exists message_receipts_user_id_idx on public.message_receipts(user_id);
create index if not exists messages_forwarded_from_idx on public.messages(forwarded_from);
create index if not exists notifications_actor_id_idx on public.notifications(actor_id);
create index if not exists notifications_conversation_id_idx on public.notifications(conversation_id);
create index if not exists notifications_message_id_idx on public.notifications(message_id);
create index if not exists typing_indicators_user_id_idx on public.typing_indicators(user_id);
create index if not exists user_blocks_blocked_id_idx on public.user_blocks(blocked_id);
create index if not exists user_reports_conversation_id_idx on public.user_reports(conversation_id);
create index if not exists user_reports_message_id_idx on public.user_reports(message_id);
create index if not exists user_reports_reported_user_id_idx on public.user_reports(reported_user_id);
create index if not exists user_reports_reporter_id_idx on public.user_reports(reporter_id);
create index if not exists group_invites_created_by_idx on public.group_invites(created_by);
create index if not exists message_hidden_message_id_idx on public.message_hidden(message_id);
create index if not exists poll_options_poll_id_idx on public.poll_options(poll_id);
create index if not exists poll_votes_user_id_idx on public.poll_votes(user_id);

commit;
