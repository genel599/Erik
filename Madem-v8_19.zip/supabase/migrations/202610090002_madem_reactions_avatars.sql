-- Message reactions and private-owner avatar uploads for madem.
create table if not exists public.message_reactions (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  reaction text not null check (reaction in ('❤️','😂','👍','😮','😢','🔥')),
  created_at timestamptz not null default now(),
  unique (message_id, user_id, reaction)
);
alter table public.message_reactions enable row level security;
drop policy if exists "conversation members can read reactions" on public.message_reactions;
drop policy if exists "users can add own reactions" on public.message_reactions;
drop policy if exists "users can remove own reactions" on public.message_reactions;
create policy "conversation members can read reactions" on public.message_reactions for select to authenticated
using (exists (select 1 from public.messages m where m.id = message_id and private.is_conversation_member(m.conversation_id)));
create policy "users can add own reactions" on public.message_reactions for insert to authenticated
with check (user_id = (select auth.uid()) and exists (select 1 from public.messages m where m.id = message_id and private.is_conversation_member(m.conversation_id)));
create policy "users can remove own reactions" on public.message_reactions for delete to authenticated
using (user_id = (select auth.uid()));
create index if not exists message_reactions_message_id_idx on public.message_reactions(message_id);

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'message_reactions') then
    alter publication supabase_realtime add table public.message_reactions;
  end if;
end $$;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('madem-avatars', 'madem-avatars', true, 5242880, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/png','image/jpeg','image/webp'];
drop policy if exists "avatars are publicly readable" on storage.objects;
drop policy if exists "users upload own avatars" on storage.objects;
drop policy if exists "users update own avatars" on storage.objects;
drop policy if exists "users delete own avatars" on storage.objects;
create policy "avatars are publicly readable" on storage.objects for select to public using (bucket_id = 'madem-avatars');
create policy "users upload own avatars" on storage.objects for insert to authenticated
with check (bucket_id = 'madem-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "users update own avatars" on storage.objects for update to authenticated
using (bucket_id = 'madem-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text)
with check (bucket_id = 'madem-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "users delete own avatars" on storage.objects for delete to authenticated
using (bucket_id = 'madem-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
