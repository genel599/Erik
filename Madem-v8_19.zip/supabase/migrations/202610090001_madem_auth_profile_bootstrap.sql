-- Already applied to the connected madem Supabase project on 2026-10-09.
create policy "users can insert own profile"
on public.profiles for insert to authenticated
with check (id = (select auth.uid()));

create or replace function private.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare raw_username text; safe_username text;
begin
  raw_username := lower(coalesce(new.raw_user_meta_data ->> 'username', split_part(coalesce(new.email, ''), '@', 1), ''));
  safe_username := regexp_replace(raw_username, '[^a-z0-9_]', '', 'g');
  if char_length(safe_username) < 3 then safe_username := 'user_' || substr(replace(new.id::text, '-', ''), 1, 8); end if;
  safe_username := substr(safe_username, 1, 24);
  insert into public.profiles (id, username, display_name)
  values (new.id, safe_username, left(coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), safe_username), 60))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created_madem on auth.users;
create trigger on_auth_user_created_madem after insert on auth.users
for each row execute function private.handle_new_user();
