-- madem backend repair: ensure critical RPCs exist after partial migrations

create or replace function public.pin_message(msg uuid, pin boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.messages
  set pinned_at = case when pin then now() else null end
  where id = msg;
end;
$$;

grant execute on function public.pin_message(uuid, boolean) to authenticated;
