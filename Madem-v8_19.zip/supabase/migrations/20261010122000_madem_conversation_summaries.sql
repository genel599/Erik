-- One indexed query for the latest message and current user's receipt per conversation.
begin;
create or replace function public.madem_conversation_summaries(conversation_ids uuid[])
returns table (
  conversation_id uuid,
  last_message_id uuid,
  last_content text,
  last_created_at timestamptz,
  last_sender_id uuid,
  last_read_at timestamptz
)
language sql
stable
security invoker
set search_path = public
as $$
  select c.id,
         msg.id,
         msg.content,
         msg.created_at,
         msg.sender_id,
         receipt.read_at
  from public.conversations c
  join public.conversation_members mine
    on mine.conversation_id = c.id and mine.user_id = (select auth.uid())
  left join lateral (
    select m.id, m.content, m.created_at, m.sender_id
    from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc
    limit 1
  ) msg on true
  left join public.message_receipts receipt
    on receipt.message_id = msg.id and receipt.user_id = (select auth.uid())
  where c.id = any(conversation_ids);
$$;
revoke all on function public.madem_conversation_summaries(uuid[]) from public, anon;
grant execute on function public.madem_conversation_summaries(uuid[]) to authenticated;
commit;
