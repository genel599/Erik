-- Message -> push notification trigger preparation
create table if not exists public.push_events (
 id uuid primary key default gen_random_uuid(),
 message_id uuid not null,
 created_at timestamptz default now()
);

-- Edge Function madem-push consumes these events and sends FCM.
