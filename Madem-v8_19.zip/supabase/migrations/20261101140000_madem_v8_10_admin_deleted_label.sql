-- madem v8_10: yönetici silince mesaj "Bu mesaj yönetici tarafından silindi" görünür
create or replace function public.delete_message_for_everyone(msg uuid) returns text
language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); r public.messages%rowtype; old_path text;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  select * into r from public.messages where id = msg;
  if r.id is null then raise exception 'Mesaj bulunamadı.'; end if;
  if r.message_type = 'system' then raise exception 'Sistem mesajları silinemez.'; end if;
  if not exists (select 1 from public.conversation_members where conversation_id = r.conversation_id and user_id = actor) then
    raise exception 'Bu sohbetin üyesi değilsin.';
  end if;
  if r.sender_id <> actor and not private.is_group_admin(r.conversation_id) then
    raise exception 'Bu mesajı herkesten silme yetkin yok.';
  end if;
  if r.deleted_at is not null then return null; end if;
  old_path := r.media_path;
  update public.messages
     set content = case when r.sender_id <> actor then 'Bu mesaj yönetici tarafından silindi' else 'Bu mesaj silindi' end,
         deleted_at = now(), media_path = null, media_mime_type = null
   where id = msg;
  return old_path;
end $$;
revoke all on function public.delete_message_for_everyone(uuid) from public, anon;
grant execute on function public.delete_message_for_everyone(uuid) to authenticated;
