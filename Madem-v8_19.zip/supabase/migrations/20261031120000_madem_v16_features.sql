-- madem v8_6: sohbet silme, grup açıklaması, katılma isteği onayı
alter table public.conversations add column if not exists description text;
alter table public.conversations add column if not exists require_join_approval boolean not null default false;
alter table public.conversation_user_state add column if not exists deleted_at timestamptz;

-- 9) Sohbeti benim için tamamen sil/temizle (diğer taraftaki mesajlar silinmez)
create or replace function public.clear_conversation_for_me(conv uuid) returns void language plpgsql security definer set search_path = '' as $$
begin
  if (select auth.uid()) is null or not private.is_conversation_member(conv) then raise exception 'Bu sohbete erişimin yok.'; end if;
  insert into public.message_hidden(user_id, message_id)
  select (select auth.uid()), m.id from public.messages m where m.conversation_id = conv
  on conflict do nothing;
end $$;

-- 18) Grup açıklaması (yalnızca yöneticiler değiştirir)
create or replace function public.set_group_description(conv uuid, new_description text) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  if new_description is not null and char_length(new_description) > 500 then raise exception 'Açıklama en fazla 500 karakter olabilir.'; end if;
  update public.conversations set description = nullif(btrim(new_description), '') where id = conv and is_group;
end $$;

-- 20) Gruba katılma isteği onayı
create or replace function public.set_group_join_approval(conv uuid, required boolean) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not private.is_group_admin(conv) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  update public.conversations set require_join_approval = coalesce(required, false) where id = conv and is_group;
end $$;

create table if not exists public.group_join_requests (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (conversation_id, user_id)
);
alter table public.group_join_requests enable row level security;
drop policy if exists "admins read join requests" on public.group_join_requests;
create policy "admins read join requests" on public.group_join_requests for select to authenticated
  using (private.is_group_admin(conversation_id) or user_id = (select auth.uid()));

create or replace function public.join_group_by_invite(invite text) returns uuid language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); conv uuid; needs boolean;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  select conversation_id into conv from public.group_invites where code = invite;
  if conv is null then raise exception 'Davet bağlantısı geçersiz veya iptal edilmiş.'; end if;
  if exists (select 1 from public.conversation_members where conversation_id = conv and user_id = actor) then return conv; end if;
  if (select count(*) from public.conversation_members where conversation_id = conv) >= 256 then raise exception 'Bu grup dolu.'; end if;
  select require_join_approval into needs from public.conversations where id = conv;
  if coalesce(needs, false) then
    insert into public.group_join_requests(conversation_id, user_id) values (conv, actor) on conflict do nothing;
    return null; -- onay bekleniyor
  end if;
  insert into public.conversation_members(conversation_id, user_id, role) values (conv, actor, 'member') on conflict do nothing;
  return conv;
end $$;

create or replace function public.resolve_group_join_request(req uuid, approve boolean) returns void language plpgsql security definer set search_path = '' as $$
declare r public.group_join_requests%rowtype;
begin
  select * into r from public.group_join_requests where id = req;
  if r.id is null then raise exception 'İstek bulunamadı.'; end if;
  if not private.is_group_admin(r.conversation_id) then raise exception 'Bu işlem için grup yöneticisi olmalısın.'; end if;
  if approve then
    if (select count(*) from public.conversation_members where conversation_id = r.conversation_id) >= 256 then raise exception 'Bu grup dolu.'; end if;
    insert into public.conversation_members(conversation_id, user_id, role) values (r.conversation_id, r.user_id, 'member') on conflict do nothing;
  end if;
  delete from public.group_join_requests where id = req;
end $$;

revoke all on function public.clear_conversation_for_me(uuid) from public, anon;
revoke all on function public.set_group_description(uuid, text) from public, anon;
revoke all on function public.set_group_join_approval(uuid, boolean) from public, anon;
revoke all on function public.resolve_group_join_request(uuid, boolean) from public, anon;
revoke all on function public.join_group_by_invite(text) from public, anon;
grant execute on function public.clear_conversation_for_me(uuid) to authenticated;
grant execute on function public.set_group_description(uuid, text) to authenticated;
grant execute on function public.set_group_join_approval(uuid, boolean) to authenticated;
grant execute on function public.resolve_group_join_request(uuid, boolean) to authenticated;
grant execute on function public.join_group_by_invite(text) to authenticated;
