-- Madem realtime hardening: ensure chat tables are published for Postgres Changes.
-- Safe to re-run. Apply this migration in the target Supabase project.
do $$
declare
  t text;
begin
  foreach t in array array['messages','message_reactions','call_signals','call_sessions','notifications'] loop
    if to_regclass('public.' || t) is not null
       and not exists (
         select 1
         from pg_publication_tables
         where pubname = 'supabase_realtime'
           and schemaname = 'public'
           and tablename = t
       ) then
      begin
        execute format('alter publication supabase_realtime add table public.%I', t);
      exception when duplicate_object then
        null;
      end;
    end if;
  end loop;
end $$;
