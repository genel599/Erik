-- Web Push: trigger, cihaz token'ı olmasa bile tarayıcı aboneliği olan kullanıcılar için de fonksiyonu çağırsın.
begin;
create or replace function private.push_on_notification()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_url text; v_secret text;
begin
  select value into v_url from private.push_config where key = 'function_url';
  select value into v_secret from private.push_config where key = 'webhook_secret';
  if v_url is null or v_secret is null then return new; end if;
  if not exists (select 1 from public.device_tokens where user_id = new.user_id)
     and not exists (select 1 from public.push_subscriptions where user_id = new.user_id) then
    return new;
  end if;

  perform net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-madem-secret', v_secret),
    body := jsonb_build_object(
      'notification_id', new.id,
      'user_id', new.user_id,
      'conversation_id', new.conversation_id,
      'kind', new.kind,
      'title', new.title,
      'body', coalesce(new.body, '')
    ),
    timeout_milliseconds := 5000
  );
  return new;
exception when others then
  raise warning 'madem push trigger failed: %', sqlerrm;
  return new;
end $$;
commit;
