-- Grup yönetimi RPC'leri + web push abonelikleri
begin;

create or replace function public.rename_group_conversation(conv uuid, new_title text)
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if new_title is null or length(trim(new_title)) < 1 or length(trim(new_title)) > 80 then raise exception 'Grup adı 1-80 karakter olmalı.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and m.role = 'admin' and c.is_group) then
    raise exception 'Bu işlem için grup yöneticisi olmalısın.';
  end if;
  update public.conversations set title = trim(new_title) where id = conv;
end $$;

create or replace function public.add_group_members(conv uuid, member_ids uuid[])
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); current_count integer;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and m.role = 'admin' and c.is_group) then
    raise exception 'Bu işlem için grup yöneticisi olmalısın.';
  end if;
  select count(*) into current_count from public.conversation_members where conversation_id = conv;
  if current_count + coalesce(array_length(member_ids, 1), 0) > 256 then raise exception 'Bir grupta en fazla 256 üye olabilir.'; end if;
  insert into public.conversation_members(conversation_id, user_id, role)
  select conv, u.id, 'member'
  from (select distinct unnest(member_ids) as id) x
  join auth.users u on u.id = x.id
  where not exists (select 1 from public.user_blocks b where (b.blocker_id = actor and b.blocked_id = u.id) or (b.blocker_id = u.id and b.blocked_id = actor))
  on conflict do nothing;
end $$;

create or replace function public.remove_group_member(conv uuid, target uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if target = actor then raise exception 'Kendini çıkarmak için gruptan ayrıl.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and m.role = 'admin' and c.is_group) then
    raise exception 'Bu işlem için grup yöneticisi olmalısın.';
  end if;
  delete from public.conversation_members where conversation_id = conv and user_id = target;
end $$;

create or replace function public.leave_group_conversation(conv uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare actor uuid := auth.uid(); remaining integer;
begin
  if actor is null then raise exception 'Oturum açmalısın.'; end if;
  if not exists (select 1 from public.conversation_members m join public.conversations c on c.id = m.conversation_id
                 where m.conversation_id = conv and m.user_id = actor and c.is_group) then
    raise exception 'Bu grubun üyesi değilsin.';
  end if;
  delete from public.conversation_members where conversation_id = conv and user_id = actor;
  select count(*) into remaining from public.conversation_members where conversation_id = conv;
  if remaining = 0 then
    delete from public.conversations where id = conv;
  elsif not exists (select 1 from public.conversation_members where conversation_id = conv and role = 'admin') then
    update public.conversation_members set role = 'admin'
    where conversation_id = conv
      and user_id = (select user_id from public.conversation_members where conversation_id = conv order by joined_at asc limit 1);
  end if;
end $$;

revoke all on function public.rename_group_conversation(uuid, text) from public;
revoke all on function public.add_group_members(uuid, uuid[]) from public;
revoke all on function public.remove_group_member(uuid, uuid) from public;
revoke all on function public.leave_group_conversation(uuid) from public;
grant execute on function public.rename_group_conversation(uuid, text) to authenticated;
grant execute on function public.add_group_members(uuid, uuid[]) to authenticated;
grant execute on function public.remove_group_member(uuid, uuid) to authenticated;
grant execute on function public.leave_group_conversation(uuid) to authenticated;

-- Web Push abonelikleri
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions enable row level security;
drop policy if exists "own push subs select" on public.push_subscriptions;
drop policy if exists "own push subs insert" on public.push_subscriptions;
drop policy if exists "own push subs update" on public.push_subscriptions;
drop policy if exists "own push subs delete" on public.push_subscriptions;
create policy "own push subs select" on public.push_subscriptions for select to authenticated using (user_id = (select auth.uid()));
create policy "own push subs insert" on public.push_subscriptions for insert to authenticated with check (user_id = (select auth.uid()));
create policy "own push subs update" on public.push_subscriptions for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own push subs delete" on public.push_subscriptions for delete to authenticated using (user_id = (select auth.uid()));

commit;
