-- madem: FCM push bildirimi — uçtan uca tamamlama
-- Akış: messages INSERT -> (mevcut trigger) notifications INSERT -> bu trigger -> Edge Function madem-push -> FCM -> Android
-- Mute / bildirim tercihleri notifications satırı oluşurken zaten uygulanıyor; burada ek filtre gerekmez.
begin;

create extension if not exists pg_net with schema extensions;
create schema if not exists private;

-- 1) device_tokens ---------------------------------------------------------
create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null,
  platform text not null default 'android',
  created_at timestamptz default now()
);
alter table public.device_tokens add column if not exists updated_at timestamptz not null default now();

-- Aynı token birden fazla satırda olamaz (en yenisi kalır)
delete from public.device_tokens a
using public.device_tokens b
where a.token = b.token
  and a.id <> b.id
  and (coalesce(a.created_at, '-infinity'::timestamptz), a.id) < (coalesce(b.created_at, '-infinity'::timestamptz), b.id);

create unique index if not exists device_tokens_token_uidx on public.device_tokens(token);
create index if not exists device_tokens_user_idx on public.device_tokens(user_id);

alter table public.device_tokens enable row level security;
drop policy if exists "own device tokens select" on public.device_tokens;
drop policy if exists "own device tokens delete" on public.device_tokens;
create policy "own device tokens select" on public.device_tokens for select to authenticated using (user_id = (select auth.uid()));
create policy "own device tokens delete" on public.device_tokens for delete to authenticated using (user_id = (select auth.uid()));
-- Ekleme/güncelleme doğrudan değil, aşağıdaki RPC ile yapılır (aynı telefonda hesap değişince token yeni kullanıcıya geçer).

create or replace function public.register_device_token(p_token text, p_platform text default 'android')
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if p_token is null or length(p_token) < 20 or length(p_token) > 4096 then raise exception 'invalid token'; end if;
  insert into public.device_tokens(user_id, token, platform, updated_at)
  values (auth.uid(), p_token, coalesce(nullif(p_platform, ''), 'android'), now())
  on conflict (token) do update set user_id = excluded.user_id, platform = excluded.platform, updated_at = now();
end $$;

create or replace function public.unregister_device_token(p_token text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  delete from public.device_tokens where token = p_token and user_id = auth.uid();
end $$;

revoke all on function public.register_device_token(text, text) from public, anon;
revoke all on function public.unregister_device_token(text) from public, anon;
grant execute on function public.register_device_token(text, text) to authenticated;
grant execute on function public.unregister_device_token(text) to authenticated;

-- 2) Edge Function ayarları (istemciden okunamaz) ---------------------------
create table if not exists private.push_config (key text primary key, value text not null);
alter table private.push_config enable row level security;
revoke all on private.push_config from public, anon, authenticated;

insert into private.push_config(key, value)
values ('function_url', 'https://aabmnntcmkyosmimjghw.supabase.co/functions/v1/madem-push')
on conflict (key) do nothing;
-- Paylaşılan gizli anahtar veritabanında üretilir; dosyalarda saklanmaz.
insert into private.push_config(key, value)
values ('webhook_secret', replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''))
on conflict (key) do nothing;

-- 3) notifications INSERT -> Edge Function ----------------------------------
create or replace function private.push_on_notification()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_url text; v_secret text;
begin
  select value into v_url from private.push_config where key = 'function_url';
  select value into v_secret from private.push_config where key = 'webhook_secret';
  if v_url is null or v_secret is null then return new; end if;
  if not exists (select 1 from public.device_tokens where user_id = new.user_id) then return new; end if;

  perform net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-madem-secret', v_secret),
    body := jsonb_build_object(
      'notification_id', new.id,
      'user_id', new.user_id,
      'conversation_id', new.conversation_id,
      'kind', new.kind,
      'title', new.title,
      'body', coalesce(new.body, '')
    ),
    timeout_milliseconds := 5000
  );
  return new;
exception when others then
  -- Push hatası asla mesaj gönderimini engellememeli.
  raise warning 'madem push trigger failed: %', sqlerrm;
  return new;
end $$;

drop trigger if exists madem_push_on_notification on public.notifications;
create trigger madem_push_on_notification
after insert on public.notifications
for each row execute function private.push_on_notification();

commit;
