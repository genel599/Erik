-- madem v8_8: grup olayı sistem mesajları + okunmamış @ bahsetme bilgisi
begin;

-- Yardımcılar (v8_7 ile aynı; tek başına da çalışsın diye tekrar tanımlı)
create or replace function private.profile_label(uid uuid) returns text language sql stable security definer set search_path = '' as $$
  select coalesce(nullif(btrim(display_name), ''), username, 'Bir kullanıcı') from public.profiles where id = uid;
$$;
create or replace function private.post_system_message(conv uuid, actor uuid, body text) returns void language plpgsql security definer set search_path = '' as $$
begin
  insert into public.messages(conversation_id, sender_id, content, message_type) values (conv, actor, left(body, 500), 'system');
end $$;
revoke all on function private.profile_label(uuid) from public, anon, authenticated;
revoke all on function private.post_system_message(uuid, uuid, text) from public, anon, authenticated;

-- 1) Grup oluşturuldu
create or replace function private.group_event_created() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform private.post_system_message(new.id, new.created_by, private.profile_label(new.created_by) || ' grubu oluşturdu');
  return new;
end $$;
revoke all on function private.group_event_created() from public, anon, authenticated;
drop trigger if exists madem_group_created_event on public.conversations;
create trigger madem_group_created_event after insert on public.conversations for each row
  when (new.is_group) execute function private.group_event_created();

-- 2) Ad / fotoğraf / mesaj izni değişti
create or replace function private.group_event_updated() returns trigger language plpgsql security definer set search_path = '' as $$
declare actor uuid := coalesce((select auth.uid()), new.created_by); who text;
begin
  if not new.is_group then return new; end if;
  who := private.profile_label(actor);
  if old.title is distinct from new.title and btrim(coalesce(new.title, '')) <> '' then
    perform private.post_system_message(new.id, actor, who || ' grup adını “' || btrim(new.title) || '” olarak değiştirdi');
  end if;
  if old.avatar_url is distinct from new.avatar_url then
    perform private.post_system_message(new.id, actor, who || case when new.avatar_url is null then ' grup fotoğrafını kaldırdı' else ' grup fotoğrafını değiştirdi' end);
  end if;
  if old.only_admins_send is distinct from new.only_admins_send then
    perform private.post_system_message(new.id, actor, case when new.only_admins_send then 'Artık yalnızca yöneticiler mesaj gönderebilir' else 'Artık herkes mesaj gönderebilir' end);
  end if;
  return new;
end $$;
revoke all on function private.group_event_updated() from public, anon, authenticated;
drop trigger if exists madem_group_updated_event on public.conversations;
create trigger madem_group_updated_event after update of title, avatar_url, only_admins_send on public.conversations for each row
  when (old.title is distinct from new.title or old.avatar_url is distinct from new.avatar_url or old.only_admins_send is distinct from new.only_admins_send)
  execute function private.group_event_updated();

-- 3) Yönetici yapıldı / yöneticilikten çıkarıldı
create or replace function private.group_event_role() returns trigger language plpgsql security definer set search_path = '' as $$
declare actor uuid := coalesce((select auth.uid()), new.user_id);
begin
  if not exists (select 1 from public.conversations c where c.id = new.conversation_id and c.is_group) then return new; end if;
  perform private.post_system_message(new.conversation_id, actor,
    private.profile_label(new.user_id) || case when new.role = 'admin' then ' yönetici yapıldı' else ' yöneticilikten çıkarıldı' end);
  return new;
end $$;
revoke all on function private.group_event_role() from public, anon, authenticated;
drop trigger if exists madem_group_role_event on public.conversation_members;
create trigger madem_group_role_event after update of role on public.conversation_members for each row
  when (old.role is distinct from new.role) execute function private.group_event_role();

-- 4) Sohbet özeti: okunmamış @ bahsetme bilgisi (son 30 gün, @kullanıcıadı veya @herkes)
drop function if exists public.madem_conversation_summaries(uuid[]);
create function public.madem_conversation_summaries(conversation_ids uuid[])
returns table (
  conversation_id uuid,
  last_message_id uuid,
  last_content text,
  last_created_at timestamptz,
  last_sender_id uuid,
  last_read_at timestamptz,
  last_message_type text,
  has_unread_mention boolean
)
language sql stable security invoker set search_path = public as $$
  select c.id, msg.id, msg.content, msg.created_at, msg.sender_id,
         coalesce(receipt.read_at, case when msg.message_type = 'system' then msg.created_at end),
         msg.message_type,
         (c.is_group and exists (
            select 1 from public.messages mm
            where mm.conversation_id = c.id
              and mm.sender_id <> (select auth.uid())
              and mm.message_type = 'text'
              and mm.deleted_at is null
              and mm.created_at > now() - interval '30 days'
              and mm.content ~* ('(^|[^[:alnum:]_])@(' || regexp_replace(coalesce(me.username, '-'), '([^[:alnum:]_])', '\\\1', 'g') || '|herkes)($|[^[:alnum:]_])')
              and not exists (select 1 from public.message_receipts r where r.message_id = mm.id and r.user_id = (select auth.uid()) and r.read_at is not null)
         )) as has_unread_mention
  from public.conversations c
  join public.conversation_members mine on mine.conversation_id = c.id and mine.user_id = (select auth.uid())
  left join public.profiles me on me.id = (select auth.uid())
  left join lateral (
    select m.id, m.content, m.created_at, m.sender_id, m.message_type
    from public.messages m where m.conversation_id = c.id
    order by m.created_at desc limit 1
  ) msg on true
  left join public.message_receipts receipt on receipt.message_id = msg.id and receipt.user_id = (select auth.uid())
  where c.id = any(conversation_ids);
$$;
revoke all on function public.madem_conversation_summaries(uuid[]) from public, anon;
grant execute on function public.madem_conversation_summaries(uuid[]) to authenticated;

commit;
