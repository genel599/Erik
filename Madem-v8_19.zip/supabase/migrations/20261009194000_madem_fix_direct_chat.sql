create or replace function public.open_direct_conversation(target_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = ''
as $function$
declare
  current_user_id uuid := auth.uid();
  existing_conversation_id uuid;
  new_conversation_id uuid;
begin
  if current_user_id is null then raise exception 'Giriş yapmalısın.'; end if;
  if target_user_id is null or target_user_id = current_user_id then raise exception 'Kendinle sohbet başlatamazsın.'; end if;
  if not exists (select 1 from auth.users where id = target_user_id) then raise exception 'Kullanıcı bulunamadı.'; end if;
  if exists (select 1 from public.user_blocks b where (b.blocker_id=current_user_id and b.blocked_id=target_user_id) or (b.blocker_id=target_user_id and b.blocked_id=current_user_id)) then
    raise exception 'Bu kullanıcıyla sohbet başlatılamıyor.';
  end if;
  select c.id into existing_conversation_id from public.conversations c
  where c.is_group=false
    and exists(select 1 from public.conversation_members a where a.conversation_id=c.id and a.user_id=current_user_id)
    and exists(select 1 from public.conversation_members b where b.conversation_id=c.id and b.user_id=target_user_id)
  order by c.created_at desc limit 1;
  if existing_conversation_id is not null then return existing_conversation_id; end if;
  insert into public.conversations(is_group,created_by) values(false,current_user_id) returning id into new_conversation_id;
  insert into public.conversation_members(conversation_id,user_id,role)
  values(new_conversation_id,current_user_id,'member'),(new_conversation_id,target_user_id,'member');
  return new_conversation_id;
end;
$function$;
