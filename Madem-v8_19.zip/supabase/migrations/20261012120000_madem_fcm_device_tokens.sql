-- FCM cihaz token altyapısı
create table if not exists public.device_tokens (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 token text not null,
 platform text not null default 'android',
 created_at timestamptz default now(),
 unique(user_id, token)
);

alter table public.device_tokens enable row level security;
