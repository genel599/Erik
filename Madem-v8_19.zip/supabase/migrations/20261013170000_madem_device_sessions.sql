-- Madem: çoklu cihaz oturum kaydı ve cihazlar arası senkronizasyon altyapısı.
-- Mesajlar zaten Supabase/Realtime üzerinden hesap bazında senkronize edilir.
begin;
create table if not exists public.device_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  platform text not null default 'web',
  label text not null default '',
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  unique(user_id, device_id)
);
create index if not exists device_sessions_user_last_seen_idx on public.device_sessions(user_id, last_seen_at desc);
alter table public.device_sessions enable row level security;
drop policy if exists "users can view own device sessions" on public.device_sessions;
create policy "users can view own device sessions" on public.device_sessions for select to authenticated using (user_id = (select auth.uid()));
-- Oturum yazma yalnızca doğrulanmış RPC üzerinden.
revoke insert, update, delete on public.device_sessions from anon, authenticated;
create or replace function public.register_device_session(p_device_id text, p_platform text default 'web', p_label text default '')
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if p_device_id is null or length(p_device_id) < 16 or length(p_device_id) > 128 then raise exception 'invalid device id'; end if;
  insert into public.device_sessions(user_id, device_id, platform, label, last_seen_at, revoked_at)
  values (auth.uid(), p_device_id, coalesce(nullif(p_platform, ''), 'web'), left(coalesce(p_label, ''), 160), now(), null)
  on conflict (user_id, device_id) do update set platform = excluded.platform, label = excluded.label, last_seen_at = now(), revoked_at = null;
end $$;
revoke all on function public.register_device_session(text, text, text) from public, anon;
grant execute on function public.register_device_session(text, text, text) to authenticated;
commit;
