-- madem v8_12: mesaj içeriği en fazla 10.000 karakter (istemci sınırıyla aynı)
alter table public.messages drop constraint if exists messages_content_length_check;
alter table public.messages add constraint messages_content_length_check check (content is null or char_length(content) <= 10000) not valid;
alter table public.messages validate constraint messages_content_length_check;
