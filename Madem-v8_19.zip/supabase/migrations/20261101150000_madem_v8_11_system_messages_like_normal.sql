-- madem v8_11: sistem mesajları normal mesaj gibi okunmamış sayılır ve bildirim üretir
insert into public.message_receipts(message_id, user_id, delivered_at, read_at)
select m.id, cm.user_id, m.created_at, m.created_at
from public.messages m
join public.conversation_members cm on cm.conversation_id = m.conversation_id and cm.user_id <> m.sender_id
where m.message_type = 'system'
on conflict do nothing;

drop trigger if exists madem_notify_members_on_message on public.messages;
create trigger madem_notify_members_on_message after insert on public.messages for each row
  execute function public.notify_conversation_members_on_message();

-- Sohbet özeti: sistem mesajı otomatik "okundu" sayılmaz
drop function if exists public.madem_conversation_summaries(uuid[]);
create function public.madem_conversation_summaries(conversation_ids uuid[])
returns table (
  conversation_id uuid,
  last_message_id uuid,
  last_content text,
  last_created_at timestamptz,
  last_sender_id uuid,
  last_read_at timestamptz,
  last_message_type text,
  has_unread_mention boolean
)
language sql stable security invoker set search_path = public as $$
  select c.id, msg.id, msg.content, msg.created_at, msg.sender_id,
         receipt.read_at,
         msg.message_type,
         (c.is_group and exists (
            select 1 from public.messages mm
            where mm.conversation_id = c.id
              and mm.sender_id <> (select auth.uid())
              and mm.message_type = 'text'
              and mm.deleted_at is null
              and mm.created_at > now() - interval '30 days'
              and mm.content ~* ('(^|[^[:alnum:]_])@(' || regexp_replace(coalesce(me.username, '-'), '([^[:alnum:]_])', '\\\1', 'g') || '|herkes)($|[^[:alnum:]_])')
              and not exists (select 1 from public.message_receipts r where r.message_id = mm.id and r.user_id = (select auth.uid()) and r.read_at is not null)
         )) as has_unread_mention
  from public.conversations c
  join public.conversation_members mine on mine.conversation_id = c.id and mine.user_id = (select auth.uid())
  left join public.profiles me on me.id = (select auth.uid())
  left join lateral (
    select m.id, m.content, m.created_at, m.sender_id, m.message_type
    from public.messages m where m.conversation_id = c.id
    order by m.created_at desc limit 1
  ) msg on true
  left join public.message_receipts receipt on receipt.message_id = msg.id and receipt.user_id = (select auth.uid())
  where c.id = any(conversation_ids);
$$;
revoke all on function public.madem_conversation_summaries(uuid[]) from public, anon;
grant execute on function public.madem_conversation_summaries(uuid[]) to authenticated;

