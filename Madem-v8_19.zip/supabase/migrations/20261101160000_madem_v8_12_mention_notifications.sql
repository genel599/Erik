-- madem v8_12: grupta @kullanıcı / @herkes ile etiketlenen üyeye ayrı "mention" bildirimi
-- Sessize alınmış sohbet ve kapalı mentions_enabled tercihi yine saygı görür.
create or replace function public.notify_conversation_members_on_message()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  is_group_chat boolean;
  sender_name text;
begin
  select c.is_group into is_group_chat from public.conversations c where c.id = new.conversation_id;
  select coalesce(p.display_name, p.username, 'Bir kullanıcı') into sender_name from public.profiles p where p.id = new.sender_id;

  insert into public.notifications(user_id, actor_id, conversation_id, message_id, kind, title, body)
  select cm.user_id,
         new.sender_id,
         new.conversation_id,
         new.id,
         case when x.is_mention then 'mention' when new.reply_to is not null then 'reply' when is_group_chat then 'group' else 'message' end,
         case when x.is_mention then sender_name || ' seni etiketledi'
              when is_group_chat then coalesce((select c.title from public.conversations c where c.id = new.conversation_id), 'Grup mesajı')
              else sender_name end,
         left(coalesce(new.content, 'Yeni medya'), 500)
  from public.conversation_members cm
  left join public.user_notification_preferences pref on pref.user_id = cm.user_id
  left join public.conversation_user_state state on state.conversation_id = new.conversation_id and state.user_id = cm.user_id
  left join public.profiles me on me.id = cm.user_id
  cross join lateral (
    select (coalesce(is_group_chat, false) and new.message_type = 'text' and coalesce(pref.mentions_enabled, true)
            and new.content ~* ('(^|[^[:alnum:]_])@(' || regexp_replace(coalesce(me.username, '-'), '([^[:alnum:]_])', '\\\1', 'g') || '|herkes)($|[^[:alnum:]_])')) as is_mention
  ) x
  where cm.conversation_id = new.conversation_id
    and cm.user_id <> new.sender_id
    and coalesce(state.muted_until, '-infinity'::timestamptz) <= now()
    and (x.is_mention or case when is_group_chat then coalesce(pref.groups_enabled, true) else coalesce(pref.messages_enabled, true) end);
  return new;
end;
$$;
