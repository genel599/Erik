-- Core schema bootstrap for a fresh Supabase project. IF NOT EXISTS keeps this
-- migration compatible with projects where these tables already exist.
create extension if not exists pgcrypto;
create schema if not exists private;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  bio text not null default '',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  title text,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member',
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  content text not null,
  reply_to uuid references public.messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id, conversation_id);

create or replace function private.is_conversation_member(conversation_uuid uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.conversation_members cm where cm.conversation_id = conversation_uuid and cm.user_id = (select auth.uid()));
$$;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles are readable by authenticated users" on public.profiles;
create policy "profiles are readable by authenticated users" on public.profiles for select to authenticated using (true);
drop policy if exists "users can update own profile" on public.profiles;
create policy "users can update own profile" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists "signed in users can create conversations" on public.conversations;
create policy "signed in users can create conversations" on public.conversations for insert to authenticated with check (created_by = (select auth.uid()));
drop policy if exists "members can view conversations" on public.conversations;
create policy "members can view conversations" on public.conversations for select to authenticated using (private.is_conversation_member(id));

drop policy if exists "conversation creator can add members" on public.conversation_members;
create policy "conversation creator can add members" on public.conversation_members for insert to authenticated with check (exists(select 1 from public.conversations c where c.id = conversation_id and c.created_by = (select auth.uid())) or user_id = (select auth.uid()) and private.is_conversation_member(conversation_id));
drop policy if exists "members can view memberships" on public.conversation_members;
create policy "members can view memberships" on public.conversation_members for select to authenticated using (private.is_conversation_member(conversation_id));

drop policy if exists "members can read messages" on public.messages;
create policy "members can read messages" on public.messages for select to authenticated using (private.is_conversation_member(conversation_id));
drop policy if exists "senders can update own messages" on public.messages;
create policy "senders can update own messages" on public.messages for update to authenticated using (sender_id = (select auth.uid()) and private.is_conversation_member(conversation_id)) with check (sender_id = (select auth.uid()) and private.is_conversation_member(conversation_id));
drop policy if exists "senders can delete own messages" on public.messages;
create policy "senders can delete own messages" on public.messages for delete to authenticated using (sender_id = (select auth.uid()) and private.is_conversation_member(conversation_id));
