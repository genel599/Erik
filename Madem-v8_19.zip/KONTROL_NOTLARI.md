# madem kontrol notları

- Backend RPC kontrolünde pin_message çağrısı ile migration arasında uyumluluk güçlendirildi.
- Kritik RPC fonksiyonlarının migration sonrası oluşması için onarım migration eklendi.
