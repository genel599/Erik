# v8.19

- Mesaja dokununca yalnızca emoji tepkileri çıkar.
- Mesaja uzun basınca (masaüstünde sağ tık) emoji hariç tüm işlemler çıkar: Yanıtla, Favori, İlet, Sabitle, Seç, Düzenle, Sil (Kendimden sil / Herkesten sil).
