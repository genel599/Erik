# Madem v15.11 — mesaj kuyruğu ve çevrimdışı önbellek

## Yapılanlar
- Mesaj gönderiminde UUID istemci tarafında oluşturuluyor ve sunucuya aynı kimlikle yazılıyor. İstek yanıtı kaybolup tekrar denenirse aynı mesajın iki kez oluşması engelleniyor.
- Çevrimdışı mesaj kuyruğu FIFO sırayla gönderiliyor. Ağ veya yetki hatasında mesaj kuyruktan silinmiyor.
- Kuyruktaki mesajlar için sunucuya aynı `id` ve `created_at` gönderiliyor; tekrar denemede `23505` (benzersiz kimlik zaten mevcut) başarılı teslim olarak ele alınıyor.
- Eski sürümlerin `local-*` kuyruk kimlikleri UUID'ye dönüştürülüyor.
- Yerel kuyruk yazılamazsa kullanıcıya hata gösteriliyor ve taslak geri konuyor.
- Sohbet önbelleği 100 yerine son 500 mesaja çıkarıldı.

## Doğrulama ve sınırlar
- Kaynak ZIP bütünlüğü kontrol edilmelidir; bağımlılık kurulumu bu çalışma ortamında zaman aşımına uğradığı için Vite üretim derlemesi doğrulanamadı.
- Bu sürüm uçtan uca şifreleme (Signal Protocol), çevrimdışı medya kuyruğu veya çoklu cihaz senkronizasyonu eklemez.
