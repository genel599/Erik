# Madem v8.16 — mesaj sesi ve titreşim
- Uygulama açıkken yeni mesaj gelince "dıt dıt" sesi çalar (iki kısa bip). Sessize alınmış sohbetlerde çalmaz. Kapatmak için tarayıcı konsolunda `localStorage.setItem('madem-sound','off')`.
- Uygulama kapalıyken gelen bildirimde titreşim eklendi (`vibrate`). Bildirim sesi web'de sistem tarafından belirlenir; özel ses için Android uygulaması (FCM bildirim kanalı) gerekir.
