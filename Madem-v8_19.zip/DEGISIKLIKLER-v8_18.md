# Madem v8.18
- **Çıkış yapınca eski hesabın bildirimi gelmesi düzeltildi:** Çıkışta bu cihazın web push abonelik kaydı hesaptan silinir. Başka hesaba girince abonelik `claim_push_subscription` ile yeni hesaba geçer (eskiden RLS yüzünden eski hesapta kalıyordu).
- **Simgedeki rozet ("2"):** Uygulama açılınca/öne gelince bekleyen bildirimler kapatılır ve `clearAppBadge` çağrılır. Android rozeti bildirim sayısından gelir.
- **Oturum:** Tarayıcıdan kalıcı depolama istenir (`navigator.storage.persist`), böylece oturum verisi silinmez. Canlı verilere göre sorun sunucuda değil, telefonda oturumun kaybolması.
- Migration: `20261101190000_madem_claim_push_subscription.sql` (canlıya uygulandı).
