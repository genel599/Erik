# madem — Android bildirim (FCM) kurulumu

Akış: mesaj gönderilir → `notifications` satırı oluşur (sessize alma / tercihler burada uygulanır) → veritabanı trigger'ı `madem-push` fonksiyonunu çağırır → fonksiyon FCM ile kullanıcının telefonlarına gönderir. Geçersiz token'lar otomatik silinir.

## 1) Firebase (bir kez)
1. Firebase Console'da proje aç → Android uygulaması ekle, paket adı: `com.madem.chat`.
2. `google-services.json` indir → `android/app/google-services.json` konumuna koy.
3. Proje ayarları → Hizmet hesapları → **Yeni özel anahtar oluştur** → JSON dosyasını indir (`servis-hesabi.json`). Bu dosyayı kimseyle paylaşma, projeye koyma.

## 2) Supabase
1. Migration'ı uygula: `supabase db push` (ya da `20261012130000_madem_fcm_complete.sql` içeriğini SQL Editor'de çalıştır).
2. Gizli anahtarı oku (SQL Editor):
   `select value from private.push_config where key = 'webhook_secret';`
3. Fonksiyon secret'larını ayarla ve yayınla:
   ```
   supabase secrets set WEBHOOK_SECRET=<yukarıdaki değer>
   supabase secrets set FIREBASE_SERVICE_ACCOUNT="$(cat servis-hesabi.json)"
   supabase functions deploy madem-push --no-verify-jwt
   ```
   (Dashboard kullanıyorsan Edge Functions → Secrets bölümüne aynı iki isimle ekle.)

## 3) Android derleme
```
npm install
npx cap add android      # android/ klasörü yoksa
# google-services.json'u android/app/ içine koy
npm run cap:sync         # build + sync + bildirim izni kontrolü
npm run android          # Android Studio'da aç, çalıştır / bundleRelease al
```

## 4) Test
İki hesapla: A telefonda girişli, uygulama arka planda/kapalı. B'den A'ya mesaj at → A'da bildirim gelmeli, dokununca sohbet açılmalı. Android 13+ ilk girişte bildirim izni sorar.

## Sorun giderme
- Bildirim gelmiyor: `select * from net._http_response order by created desc limit 5;` (trigger fonksiyonu çağırdı mı, hangi kod döndü).
  - 401 → `WEBHOOK_SECRET` ile veritabanındaki değer aynı değil.
  - 500 → Functions → madem-push → Logs (genelde `FIREBASE_SERVICE_ACCOUNT` hatalı).
- `select count(*) from device_tokens;` 0 ise telefon token kaydetmemiş: izin verilmiş mi, `google-services.json` doğru mu bak.
- Uygulama açıkken sistem bildirimi yerine uygulama içi bildirim görünür (normal).
- Tarayıcı/PWA push'u (VAPID) ayrı bir sistemdir ve bu pakette gönderici yoktur; yalnızca Android FCM çözüldü.
