# v6 değişiklikleri
- main.jsx: fazladan `}` (derleme hatası) düzeltildi.
- Klavye açılınca sohbetin kaybolması: viewport `interactive-widget=resizes-content`, `viewport-fit=cover`, panel `100dvh`.
- Composer taşması (gönder butonu ekran dışı) düzeltildi; mesaj kutusunda otomatik doldurma kapatıldı.
- Arama: 30 sn zaman aşımı ("Cevap vermedi" + durum `missed`), iptal `cancelled`, reddedilen `Reddedildi`; eski askıda kalan kayıtlar 2 dk sonra "Cevapsız" görünür; stale closure giderildi; çifte arama engellendi; isteğe bağlı TURN (`VITE_TURN_*`).
- Medya URL'i alınamazsa sonsuz istek döngüsü giderildi (30 sn bekleyip tekrar dener).
- Sohbet artık en yeni 200 mesajı yükler; "Daha eski mesajları yükle" düğmesi eklendi.
- Sesli mesaj/fotoğraf/video içeriği dosya adı yerine etiketle kaydedilir; listede eski kayıtlar da "🎤 Sesli mesaj / 📷 Fotoğraf" görünür.
- Henüz yapılmayanlar: taslak kaydı (`draftKey` kullanılmıyor), engeli kaldırma, 2FA kapatma, grup yönetimi, push bildirim, PWA ikonları.
