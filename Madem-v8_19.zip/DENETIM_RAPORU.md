# Madem — Denetim Raporu (güncel, v8_12)

Bu rapor kod okuması ve canlı Supabase veritabanı sorgularına dayanır. Uygulama derlenmedi ve iki gerçek hesapla uçtan uca test edilmedi.

## Doğrulananlar
- Tüm `public` tablolarında RLS açık ve hepsinin politikası var; anonim kullanıcının çağırabildiği ayrıcalıklı (`security definer`) fonksiyon yok; hepsinde `search_path` ayarlı.
- `madem-media` kovasında dosya türü listesi ve 50 MB sınırı uygulanmış.
- Giriş/kayıt hız sınırı veritabanında kalıcı sayaçla çalışır (`consume_rate_limit`). Fonksiyon eksikse giriş fonksiyonu 503 döner (güvenli taraf).
- Mesaj içeriği veritabanında 10.000 karakterle sınırlı.
- Çevrimdışı kuyrukta mesajlar istemci tarafında üretilen UUID taşır; tekrar gönderimde çakışma (23505) işlenir.

## Bilinen eksikler
- Uçtan uca şifreleme yok (mesajlar Supabase'de okunabilir).
- `package-lock.json` yok; bağımlılık sürümleri sabitlenmedi.
- iOS için `@capacitor/ios` yok, yalnızca Android.
- Arka plan senkronizasyonu yok: giden kuyruk uygulama açıkken boşalır. Metin kuyruğu `localStorage`, medya kuyruğu `IndexedDB` kullanır.
- Topluluk özelliği yok.
- Yük testi yapılmadı (canlıda 4 kullanıcı, ~90 mesaj).
- Derleme ve çok cihazlı senkronizasyon gerçek cihazda doğrulanmadı.

## Öneri sırası
1. Kendi bilgisayarında `npm install && npm run build`, ardından `package-lock.json`'ı depoya ekle.
2. İki hesapla gerçek test (çevrimdışı gönderim, bildirimler, çok cihaz).
3. Android'i gerçek cihazda dene.
4. Uçtan uca şifreleme ve topluluk gibi büyük işler.
