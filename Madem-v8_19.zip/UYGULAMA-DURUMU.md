# madem — uygulama paketi durumu (v9)

Ayrıntılar için `DEGISIKLIKLER-v9.md`.

- Seçilen özelliklerin büyük bölümü kodlandı; derleme ve iki hesapla uçtan uca test bu ortamda yapılamadı.
- Yeni migration (`20261011150000_...`) ve `madem-link-preview` fonksiyonu canlıya uygulanmalıdır; canlıya dağıtım yapılmadı.
