# madem — kapsamlı bakım paketi

## Bu pakette uygulanan kaynak değişiklikleri
- Supabase Realtime yayınını güvenli şekilde kontrol eden/ekleyen SQL migration eklendi (`20261011130000_madem_realtime_publication.sql`). Bu dosya hedef Supabase projesinde ayrıca uygulanmalıdır.
- Arka plan mesaj olayları sohbet listesini yeniler; tarayıcı `Notification` API'si desteklenmiyor veya hata veriyorsa mesaj akışı kesilmez.
- Okundu bilgisi yalnızca sekme görünür ve pencere odaklıyken yazılır; görünürlük/odak geri gelince tekrar kontrol edilir.
- Süreli medya bağlantılarının yenilenmesi için süre takibi eklendi.
- Ses kaydında tarayıcının desteklediği MIME türü seçilmeye çalışılır.
- Dosya seçici HEIC/HEIF, MOV, Office belgeleri ve yaygın dosya türlerini kabul eder.
- Mobil dokunmatik ekranlarda mesaj araçları hover olmadan görünür.
- Grup ekranında en az iki ek kişi gerektiği açıkça belirtilir.
- Tarih başlığı sabit BUGÜN metni yerine son mesajın tarihini gösterir.
- Gelen arama reddetme akışı `rejected` durumunu ve karşı tarafa hangup sinyalini yazar.
- PWA manifesti ve temel service worker eklendi; servis çalışanı kayıt kodu eklendi.

## Henüz tamamlanmamış / dış erişim isteyenler
- Eski mesajlar için gerçek sayfalama/yukarı kaydırarak yükleme henüz eklenmedi.
- Tam tarih gruplama (her gün için ayrı ayraç), gerçek emoji seçici, bildirim merkezi, kişiler arama sekmesi ve diğer yeni ürün özellikleri tamamlanmadı.
- Mesaj iletme, grup yönetimi/rolleri, sohbet içi arama ve medya galerisi tamamlanmadı.
- Engelleme/grup ekleme ve çağrı izinlerinin tüm sunucu tarafı güvenlik denetimi bağımsız SQL/RLS denetimi gerektirir.
- Storage silme, kayıt hız sınırı/bot koruması, push bildirimleri ve TURN sunucusu yapılandırması dış servis/secret gerektirir.
- Capacitor yapılandırması projede zaten var; bu paket native Android/iOS klasörleri veya imzalı mağaza paketleri üretmez.
- Supabase migration canlı projede uygulanmadı; Netlify dağıtımı yapılmadı.

## Doğrulama
- ZIP bütünlük testi yapılmalıdır.
- `npm install` ve `npm run build` hedef ortamda çalıştırılmalıdır.
- İki hesapla mesaj, gelen arama, reddetme ve ses/video akışı uçtan uca test edilmelidir.
