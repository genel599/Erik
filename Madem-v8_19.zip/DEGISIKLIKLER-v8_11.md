# Madem v8_11
- Sistem mesajları ("X gruba katıldı" vb.) artık normal mesaj gibi davranır: okunmamış sayılır (mavi nokta, sekme başlığı sayacı, "N okunmamış mesaj" ayracı) ve bildirim üretir (push ve tarayıcı bildirimi; sessize alınan sohbetlerde ve kapalı bildirim tercihlerinde gitmez).
- Eski 6 sistem mesajı tek seferlik okundu işaretlendi.
- Migration: `20261101150000_madem_v8_11_system_messages_like_normal.sql` (canlı veritabanına uygulandı).
