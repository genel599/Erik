# Madem V7 — hata ve performans düzeltmeleri

## Düzeltmeler
- **Gereksiz yeniden yükleme (performans):** Oturum belirteci yenilendiğinde (yaklaşık saatte bir) profil, sohbet listesi ve açık sohbetin mesajları baştan çekiliyordu. Bağımlılıklar `session` yerine `session?.user?.id` olarak değiştirildi.
- **Gelen mesajda çoklu yenileme (performans):** Aynı mesaj için sohbet listesi iki ayrı kanaldan tam yeniden yükleniyordu. Artık tek, 400 ms'lik birleştirilmiş (debounce) yenileme var.
- **Mesaj arama yarışı:** Hızlı yazarken eski aramanın sonucu yenisinin üstüne yazabiliyordu. İptal bayrağı eklendi.
- **Null koruması:** `deviceSync.js` ve `pushNotifications.js`, Supabase yapılandırılmamışken (`supabase === null`) hata atmaz.
- **Temizlik:** `Root()` içindeki iki tarafı da aynı olan koşul sadeleştirildi.

## Bilinen açık noktalar (bu sürümde değişmedi)
- `madem-link-preview` adres filtresi IP ve ana makine adı kontrolü yapar, ancak DNS çözümlemesi sonrası özel IP'ye giden alan adlarını engellemez (DNS rebinding). Edge Runtime'da `Deno.resolveDns` desteği doğrulanmadan eklenmedi.
- Yazıyor göstergesi her 2,5 sn'de bir sorgulanıyor; trafiği azaltmak için Realtime broadcast'e geçilebilir.
- `npm install` / `npm run build` bu ortamda çalıştırılamadı. Vercel'e atmadan önce build al.
- Migration önce, `madem-login` / `madem-register` / `_shared/rateLimit.ts` sonra deploy edilmeli (bkz. `DEPLOY-SON-KONTROL.md`).

## Ek (v7.1)
- Kurulum ekranı metni güncellendi: eksik ortam değişkenlerini adıyla söyler ve Vercel için "Environment Variables + Redeploy" adımını gösterir.
- `.env.production` eklendi: `VITE_SUPABASE_URL` ve publishable key, Vite'ın üretim derlemesinde otomatik okunur. Vercel panelinde değişken tanımlamak gerekmez (tanımlanırsa panel değeri önceliklidir). `supabase.js` içinde sabit varsayılan hâlâ yok.
- **Tema: "Sistem" seçeneği.** Ayarlar > Görünüm artık Sistem / Açık / Koyu seçici. Sistem seçiliyken cihazın açık/koyu ayarı değişince uygulama anında uyum sağlar. Daha önce açık ya da koyu seçmiş kullanıcıların tercihi korunur; hiç seçmemiş yeni kullanıcılar için varsayılan "Sistem".
- **Renk: vurgu rengi teal (#12a5b0).** Eski limon/zeytin yeşili ailesi (açık temada soluk, koyu temada kötü duran tonlar) tek bir teal tonuna çevrildi: düğmeler, avatarlar, seçili sohbet, kendi mesaj balonu, yazı vurguları ve ayar ikonları. Zemin ve nötr renkler değişmedi. Değişiklik `styles.css` içindeki yeşil/zeytin renk kodlarının yeniden eşlenmesi ve dosya sonundaki "v7: seçili/aktif durumlar" blokları. Rengi sonradan değiştirmek için `#12a5b0` (ana) ve `#0b7f86` (koyu metin) değerlerini aramak yeterli.
