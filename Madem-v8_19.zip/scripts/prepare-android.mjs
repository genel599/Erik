// cap sync sonrası: Android bildirim izni ve google-services.json kontrolü.
import fs from 'node:fs';
const manifest = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifest)) { console.log('android/ klasörü yok — önce: npx cap add android'); process.exit(0); }
let xml = fs.readFileSync(manifest, 'utf8');
if (!xml.includes('android.permission.POST_NOTIFICATIONS')) {
  xml = xml.replace(/<manifest[^>]*>/, (m) => `${m}\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />`);
  fs.writeFileSync(manifest, xml);
  console.log('AndroidManifest.xml: POST_NOTIFICATIONS izni eklendi.');
}
if (!fs.existsSync('android/app/google-services.json')) {
  console.error('\nUYARI: android/app/google-services.json yok. Firebase Console > Proje ayarları > Android uygulaması (paket adı: com.madem.chat) üzerinden indirip oraya koy; yoksa bildirim çalışmaz.\n');
}
