# v13
- Kendine mesaj: yeni sohbet penceresinde "Kendine mesaj" satırı, listede "Ad (Siz)". Gerekli SQL: supabase/migrations/20261012150000_madem_self_chat.sql
- Mobilde alt sekme çubuğu (sol şerit yerine), daha büyük yazılar (mesaj 15px, liste 14-15px)
- Açık temada yeşil yazı/etiket kontrastı düzeltildi
- Büyük harfli, aralıklı etiketler ("MESAJLARIN") cümle biçimine çevrildi
- Toast alt çubuğun üstünde görünür
