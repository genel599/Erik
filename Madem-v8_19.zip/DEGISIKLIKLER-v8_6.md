# Madem v8_6 – seçilen 8 özellik

Eklenenler (numaralar seçim listesindekiyle aynı):

- **9. Sohbeti silme:** Sohbet menüsünde "Sohbeti sil" (bire bir) / "Sohbeti temizle" (grup). Yalnızca senden silinir; karşı taraf etkilenmez. Bire bir sohbet yeni mesaj gelince listede yeniden görünür.
- **10. @etiketleme:** Grup sohbetinde `@` yazınca üye listesi açılır, seçince `@kullaniciadi` eklenir. Etiketler mavi/vurgulu görünür.
- **11. Aramadan mesaja atlama:** Sohbet listesindeki mesaj arama sonucuna veya sohbet içi aramada bir mesaja dokununca o mesaja gidilir ve kısa süre vurgulanır (eski mesajlar gerekirse otomatik yüklenir). Favorilerden atlama da artık çalışır.
- **17. Kaydırarak hızlı yanıt:** Mesajı sağa kaydırınca yanıt modu açılır.
- **18. Grup açıklaması:** Yöneticiler grup bilgisinden açıklama yazar; herkes görür, başlık altında ilk satırı görünür.
- **19. Üye yönetimi:** Üye satırında "Yönet" veya grup içinde gönderen adına dokununca (yöneticiler) tek ekranda "Yönetici yap/Yöneticiliği al" ve "Gruptan çıkar".
- **20. Katılma isteği onayı:** Grup bilgisinde "Katılma isteklerini yönetici onaylasın" seçeneği. Açıkken davet bağlantısıyla gelenler istek olarak düşer; yöneticiler Onayla/Reddet yapar.
- **21. Etiketlenince vurgu:** Senden bahsedilen mesaj sarı çerçeveyle öne çıkar; sohbet listesinde okunmamış grup mesajında `@` rozeti görünür.

## Kurulum
1. `supabase/migrations/20261031120000_madem_v16_features.sql` dosyasını Supabase SQL Editor'de çalıştır (yeni sütunlar, tablo ve RPC'ler).
2. Normal şekilde build/deploy et (`npm install && npm run build`).

Not: Bu ortamda internet olmadığı için tam `vite build` çalıştırılamadı; JSX söz dizimi kontrol edildi (hata yok).
