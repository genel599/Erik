# Madem v8.14 — Herkesten sil görünürlüğü ve güvenli silme

- Mesaj işlem çubuğundaki belirsiz `×` simgesi, açıkça görünen çöp kutusu + `Sil` eylemiyle değiştirildi.
- Silme onayında `Herkesten sil` seçeneği belirginleştirildi ve tüm katılımcılardan kaldırdığı açıkça anlatıldı.
- Gönderenin ve grup yöneticisinin herkesten silme işlemi aynı `delete_message_for_everyone` Supabase RPC'si üzerinden yürütülüyor. Böylece yetki kontrolü istemcide değil sunucu fonksiyonunda kalıyor.
- Silinen medya dosyasının depolamadan kaldırılması korunuyor.
