# Madem V6 – ek güvenlik düzeltmeleri

- Supabase URL ve publishable key eksik olduğunda uygulama artık varsayılan bir projeye sessizce bağlanmaz; kurulum ekranını gösterir.
- `audio/webm;codecs=opus` MIME değeri parametrelerinden arındırılarak `audio/webm` olarak kaydedilir.
- Rate limiter güvenilir IP başlığı bulamazsa tüm kullanıcıları ortak `unknown` kovasına koymaz; güvenli biçimde başarısız olur (auth fonksiyonları 503 döndürebilir). Supabase Edge Function ortamında IP başlıklarının gerçekten mevcut olduğu dağıtımda doğrulanmalıdır.

## Doğrulama durumu

- ZIP bütünlüğü ve kaynak sözdizimi kontrolleri yapılabilir.
- `npm install` ortamda zaman aşımına uğradığından `npm run build` doğrulanamadı.
- Supabase migration ve Edge Function'lar canlıya uygulanmadı. Önce migration, ardından `madem-login` ve `madem-register` (paylaşılan `_shared/rateLimit.ts` dosyasıyla) dağıtılmalıdır.
