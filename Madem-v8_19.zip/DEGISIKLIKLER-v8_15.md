# Madem v8.15 — bildirim, grup, çevrimdışı, kişiler ve arayüz

## Uygulanan düzeltmeler
- Metin mesajı gönderilirken bağlantı koparsa oluşan `fetch` istisnası artık taslağı kaybettirmiyor; mesaj aynı kimlikle çevrimdışı kuyruğa alınıyor.
- Bekleyen metin mesajları gönderilirken Supabase istemcisi doğrudan hata fırlatsa bile kuyruk korunuyor. Kuyruk FIFO sırayla ve tekrar denemeye uygun UUID ile çalışıyor.
- Kişiler sekmesi artık yalnızca birebir sohbet edilen hesapları gösteriyor; grupları ve kişinin kendi not sohbetini listelemiyor. Aynı kişi birden fazla sohbet kaydında varsa tekilleştiriliyor ve son mesaja göre sıralanıyor.
- Grup oluşturma ekranında 256 kişilik mevcut sunucu sınırı görünür hale getirildi; seçim 255 diğer üye + grup kurucusuyla sınırlandırıldı.
- Mobil başlıkların güvenli ekran alanına taşmaması ve içerik alanının doğru kaydırılması için mobil düzen iyileştirildi.

## Bu sürümde zaten bulunan ve korunan grup özellikleri
- Grup anketleri ve oy verme
- Yönetici/üye rolleri, üye çıkarma ve yönetici atama
- Yalnızca yöneticilerin mesaj yazabilmesi
- Davet bağlantısı oluşturma/iptal etme
- Yönetici onaylı katılma istekleri
- 256 kişiye kadar grup üyeliği

## Sınırlar / ayrıca gerekenler
- Tam teşekküllü Topluluklar (birden fazla grubun tek çatı altında yönetimi) bu güncellemede eklenmedi; mevcut grup altyapısından ayrı bir ürün/veri modeli gerektiriyor.
- Web Push altyapısı mevcut; gerçek cihaz teslimatı kullanıcı cihazında izin ve abonelikle doğrulanmalı.
- Android FCM için Firebase servis hesabı yapılandırması gerekli. Bu sır/kimlik bilgisi olmadan Android arka plan bildiriminin teslimatı doğrulanamaz.
- Çevrimdışı mesaj ve medya kuyrukları mevcut; farklı cihazlar ve uzun süreli çevrimdışı senaryolar için gerçek cihaz testi hâlâ gerekli.
