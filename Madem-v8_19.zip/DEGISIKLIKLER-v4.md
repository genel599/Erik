# Madem v4 — bildirim, görünüm ve dosya güvenliği düzenlemeleri

## Bu sürümde
- Bildirimler menüsüne okunmamış bildirim sayacı eklendi; sayaç oturum açıldığında veritabanından okunur ve bildirim tablosundaki değişikliklerle yenilenir.
- Görünüm ayarına açık/koyu tema geçişi eklendi. Tercih `localStorage` kullanılamadığında da uygulamanın açılmasını engellemez.
- Sohbette dosya gönderirken boş dosyalar, 50 MB üstü dosyalar ve yaygın çalıştırılabilir/aktif içerik uzantıları (HTML, SVG, JS, EXE vb.) istemci tarafında reddedilir.
- Var olan kişi arama, engellenen kullanıcılar, MFA, şifre değiştirme ve hesap silme akışları korunmuştur.

## Sınırlar ve dikkat edilmesi gerekenler
- Bu dosya tek başına Supabase Storage sunucu kurallarını değiştirmez. Dosya türü/boyutu kısıtları Storage tarafında da doğrulanmalıdır.
- Giriş/kayıt Edge Function'larındaki bellek içi `Map` hız sınırlaması dağıtımlar arasında kalıcı değildir. Üretim için paylaşılan, sunucu taraflı kalıcı limit uygulanması gerekir; bu ZIP veritabanı şemasını veya canlı Supabase projesini değiştirmez.
- Web push bildirimlerinin uygulama kapalıyken çalışması, Vercel ortam değişkenleri ve Supabase tarafındaki push gönderim yapılandırmasına bağlıdır.
- Derleme bu ortamda doğrulanamadı; `npm install` ağ/ortam zaman aşımına uğradı. JSX sözdizimi TypeScript transpile parser ile kontrol edildi. Vercel'e atmadan önce `npm run build` çalıştırılmalıdır.
