/* madem PWA service worker — shell cache + Web Push */
const CACHE = 'madem-shell-v7';
const PRECACHE = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Network-first for same-origin GET; offline fallback to cache / shell
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res.ok && (url.pathname === '/' || url.pathname.startsWith('/icons/') || url.pathname.endsWith('.webmanifest') || url.pathname.endsWith('.js') || url.pathname.endsWith('.css'))) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req).then((cached) => cached || caches.match('/')))
  );
});

self.addEventListener('push', (event) => {
  let d = {};
  try {
    d = event.data ? event.data.json() : {};
  } catch {
    d = { title: 'madem', body: event.data ? event.data.text() : '' };
  }
  event.waitUntil(
    self.registration.showNotification(d.title || 'madem', {
      body: d.body || '',
      tag: d.tag || ('madem-' + (d.conversationId || 'genel')),
      icon: '/icons/icon-192.png',
      badge: '/icons/badge-96.png',
      renotify: true,
      vibrate: [120, 80, 120],
      requireInteraction: d.kind === 'call',
      data: {
        conversationId: d.conversationId || null,
        kind: d.kind || 'message',
      },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const cid = event.notification.data && event.notification.data.conversationId;
  event.waitUntil(
    (async () => {
      const all = await clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const c of all) {
        if ('focus' in c) {
          await c.focus();
          c.postMessage({ type: 'open-conversation', conversationId: cid });
          return;
        }
      }
      await clients.openWindow(cid ? '/?c=' + cid : '/');
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
