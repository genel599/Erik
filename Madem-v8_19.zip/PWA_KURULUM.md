# madem — PWA (Play Store’suz uygulama)

Bu sürüm tarayıcıdan **Ana ekrana ekle** ile uygulama gibi kurulur. Play Store gerekmez.

## Vercel

1. Projeyi Vercel’e bağla / deploy et.
2. Environment Variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `VITE_VAPID_PUBLIC_KEY`  ← Web Push için zorunlu
3. Redeploy.

## VAPID (arka plan bildirimleri)

```bash
npx web-push generate-vapid-keys
```

- **Public** → Vercel: `VITE_VAPID_PUBLIC_KEY`
- **Public + Private** → Supabase secrets:
  ```bash
  supabase secrets set VAPID_PUBLIC_KEY=... VAPID_PRIVATE_KEY=... VAPID_SUBJECT=mailto:sen@ornek.com
  supabase functions deploy madem-push --no-verify-jwt
  ```
- Migration: `20261012140000_madem_webpush_trigger.sql` uygulanmış olmalı.

## Telefonda kurulum

**Android Chrome**
1. Siteyi aç.
2. Menü (⋮) → **Uygulamayı yükle** / **Ana ekrana ekle**
   veya Ayarlar içindeki **Yükle** düğmesi (tarayıcı destekliyorsa).
3. Ayarlar → Arka plan bildirimleri → Aç.

**iPhone Safari**
1. Paylaş → **Ana Ekrana Ekle**
2. Bildirim için PWA olarak açılmış olması gerekir.

## Güncelleme

Aynı Vercel adresine deploy yeter. Yeni link gerekmez. Service worker yeni sürümü alır.
