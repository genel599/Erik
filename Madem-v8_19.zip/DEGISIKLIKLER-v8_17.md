# Madem v8.17 — bildirim simgesi
- Durum çubuğundaki siyah kare düzeltildi: Android bildirim küçük simgesini yalnızca şeffaflık maskesi olarak okur. Renkli uygulama simgesi yerine şeffaf zeminli beyaz "m" harfi (`public/icons/badge-96.png`) kullanılıyor.
- Servis çalışanı önbellek sürümü v7'ye yükseltildi.
- Not: Android, bildirim simgesini ilk kurulumda önbelleğe alabilir. Görünmezse uygulamayı kaldırıp yeniden ana ekrana ekle.
