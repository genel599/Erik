# Madem v8_10
- Yönetici başkasının mesajını silince mesajın yerinde "Bu mesaj yönetici tarafından silindi" yazar (sohbet, yanıt önizlemesi ve dışa aktarma). Kendi mesajını silen için "Bu mesaj silindi" kalır.
- Migration: `20261101140000_madem_v8_10_admin_deleted_label.sql` (canlı veritabanına uygulandı).
