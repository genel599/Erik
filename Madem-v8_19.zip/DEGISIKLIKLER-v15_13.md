# Madem v15.13 – canlı backend onarımı

- Canlı Supabase veritabanına anket, grup daveti, kendimden mesaj gizleme ve cihaz oturumu tabloları eklendi.
- Bu tablolarda RLS politikaları ve ilgili RPC yetkileri kuruldu.
- Anonim kullanıcıların ayrıcalıklı RPC işlevlerini çağırması engellendi.
- `madem-link-preview` Edge Function canlı projeye JWT doğrulaması açık şekilde dağıtıldı; URL doğrulaması sıkılaştırıldı.
- Uygulamadaki sesli/görüntülü arama işleyicileri ve arama ekranları kaldırıldı.
- Canlı backend doğrulaması yapıldı; tam frontend build testi bağımlılık indirme erişimi nedeniyle tamamlanamadı.
