# Madem v15.12 — çevrimdışı medya ve cihaz oturumu altyapısı

## Bu sürümde
- Fotoğraf, video, sesli mesaj ve dosyalar internet yokken IndexedDB içinde Blob olarak kuyruğa alınır (50 MB mevcut sınır korunur).
- İnternet geldiğinde veya uygulama açıkken düzenli aralıklarla medya yüklemesi yeniden denenir.
- Medya dosya yolu ve mesaj UUID'si kuyruk öğesiyle sabit tutulur; tekrar denemelerde storage `upsert` ve mesaj UUID çakışması kontrolü çift kayıt riskini azaltır.
- `device_sessions` tablosu ve `register_device_session` RPC eklendi. Giriş yapan istemci cihazını kaydeder ve çevrimiçi olduğunda son görülme zamanını yeniler.
- Mesajların cihazlar arasında gerçek zamanlı senkronizasyonu mevcut Supabase Realtime akışıyla çalışmaya devam eder.

## Kurulum
Yeni `supabase/migrations/20261013170000_madem_device_sessions.sql` migration dosyasını Supabase SQL Editor'da çalıştır veya Supabase CLI ile migration'ları uygula.

## Önemli güvenlik notu
Uçtan uca şifreleme bu sürümde uygulanmış değildir. Signal Protocol olmadan yalnızca Web Crypto ile rastgele şifreleme eklemek, anahtar değişimini ve çoklu cihaz güvenini çözmez; güvenliymiş gibi sunulmadı. Mesaj içerikleri sunucuda okunabilir durumda kalır. Gerçek E2EE için Signal Protocol tabanlı anahtar değişimi, cihaz başına kimlik anahtarları, oturum kurulumu, anahtar doğrulama ve güvenlik testleri ayrıca tamamlanmalıdır.

## Doğrulama
Kaynak/SQL statik olarak gözden geçirildi. Canlı Supabase projesinde migration ve gerçek Android cihazlarla çevrimdışı-yeniden bağlanma testi yapılmadan üretime hazır olduğu iddia edilmez.
