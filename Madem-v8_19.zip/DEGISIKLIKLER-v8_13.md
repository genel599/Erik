# Madem v8.13 — Bildirim altyapısı

- Supabase `push_subscriptions` tablosu Web Push endpoint/anahtar alanlarıyla uyumlu hâle getirildi; eski platform/token kayıtları korunur.
- Android/iOS cihaz token'ları için `device_tokens` tablosu ve güvenli kayıt/silme RPC'leri eklendi.
- `notifications` tablosuna yeni kayıt geldiğinde `madem-push` Edge Function'ını çağıran `pg_net` tetikleyicisi eklendi.
- VAPID anahtarları Supabase Vault'ta şifreli saklanır; özel anahtar uygulama paketine veya Vercel'e konmaz.
- `madem-push` fonksiyonu gerçek notification kaydını Supabase'den okur; Web Push gönderir, süresi bitmiş abonelikleri temizler.
- FCM HTTP v1 gönderim kodu hazır; Firebase servis hesabı tanımlanana kadar Android push gönderimi devreye girmez.
- Vercel `VITE_VAPID_PUBLIC_KEY` değişkeni eklendi.

## Durum
Web Push sunucu altyapısı Supabase üzerinde kuruldu ve test isteği `200 / no_targets` döndürdü. Gerçek cihaz testi için uygulamada bildirim izninin verilmesi ve bir Web Push aboneliğinin oluşması gerekir. Android FCM için Firebase Android uygulaması ve servis hesabı hâlâ gereklidir.
