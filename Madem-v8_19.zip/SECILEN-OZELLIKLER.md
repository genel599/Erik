# madem — Kullanıcının seçtiği özellikler

Bu belge, kullanıcı tarafından seçilen ürün gereksinimlerini kaydeder. Bunlar gereksinim listesidir; tek başına özelliklerin kodda uygulandığı veya canlıya alındığı anlamına gelmez.

## Sohbetler ve mesajlar
- Eski mesajlar yukarı kaydırıldıkça yüklensin.
- Sohbet listesinde sabitlenen sohbetler üstte, kalanlar son mesaja göre sıralansın.
- Sohbet arşivleme yalnızca bire bir sohbetlerde olsun.
- Sohbet sabitleme yalnızca gruplarda olsun.
- Mesaj sabitleme: bire bir sohbette herkes; grupta yalnızca yöneticiler.
- Mesaj düzenleme istenildiği zaman yapılabilsin; “Düzenlendi” etiketi gösterilmesin.
- Mesaja yanıt verme bire bir ve grup sohbetlerinde olsun.
- Mesaj iletme bire bir ve grup sohbetlerinde olsun.
- Mesaj silme: kendimden ve herkesten silme; süre sınırı olmasın.
- Mesajları çoklu seçme ve seçilenleri silme, iletme, favorilere ekleme ve diğer işlemler olsun.
- Sohbet dışa aktarma metin ve medyayı kapsasın.
- Sohbet taslakları her sohbet için otomatik kaydedilsin.
- Mesaj zaman damgası mesaja dokununca gösterilsin.
- Bağlantı önizlemeleri otomatik oluşsun.
- Tüm sohbetlerde genel arama ve sohbet içi mesaj araması olsun.
- Medya galerisi bire bir ve grup sohbetlerinde olsun.
- Favori mesajlar bire bir ve grup sohbetlerinde kaydedilsin; ayrı Favoriler bölümü olsun.
- Kaybolan mesajlar olmasın.
- Sohbet yedekleme şimdilik olmasın.

## Ses, medya ve dosyalar
- Sesli mesajlar bire bir ve grup sohbetlerinde gönderilebilsin.
- Sesli mesaj oynatma hızları: 1×, 1.5×, 2×.
- Fotoğraf ve videolar bire bir ve grup sohbetlerinde, orijinal kalitede gönderilsin.
- Dosyalar bire bir ve grup sohbetlerinde gönderilebilsin ve indirilebilsin.
- Dosya türü kısıtlaması olmasın.

## Gruplar
- Grup anketleri olsun; yalnızca grup sohbetlerinde kullanılabilsin.
- Davet bağlantısını yöneticiler oluşturabilsin.
- Varsayılan olarak tüm üyeler mesaj yazabilsin; yöneticiler bu izni değiştirebilsin.
- Yöneticiler başka yöneticiler atayabilsin, üyeleri çıkarabilsin, grup adını ve fotoğrafını değiştirebilsin.
- Grup okundu bilgisi, mesajı okuyan üyelerin listesini göstersin.

## Kişiler, profil ve durum
- Benzersiz kullanıcı adıyla kullanıcı arama/bulma olsun.
- Biyografi herkese açık olsun.
- Çevrimiçi durumu ve son görülme herkese açık olsun; gizleme seçeneği olmasın.
- Yazıyor göstergesi bire bir ve grup sohbetlerinde daima açık olsun; kapatma ayarı olmasın.
- Profil fotoğrafı/biyografi için ek gizlilik ayarları olmasın.
- Durum/hikâye özelliği olmasın.
- Engelleme olsun; şikâyet özelliği olmasın.

## Bildirimler ve görünüm
- Bildirim merkezi olsun.
- Sohbet bildirimlerini sessize alma bire bir ve grup sohbetlerinde olsun.
- Sohbet başına ayrı bildirim sesi ayarı olmasın.
- Uygulama kilidi olmasın.
- Sohbet arka planı özelleştirme olmasın.
- Yalnızca açık tema olsun.
- Arayüz dili yalnızca Türkçe olsun.
- Ayrı kişiler sekmesi olsun.
- Emoji seçici olsun.

## Hesaplar ve cihazlar
- Telefon, bilgisayar ve tablet desteği olsun.
- Kullanıcılar kayıt olup gerçek kullanıcılarla çevrimiçi mesajlaşabilsin.
- Kullanıcı özelliği önerme/hata bildirme bölümü olmasın.

## Uygulama notu
Bu dosya, seçilen gereksinimleri kaynak ZIP'ine ekler. Özelliklerin tümünün uygulanmış, test edilmiş veya canlıya yüklenmiş olduğunu iddia etmez.
