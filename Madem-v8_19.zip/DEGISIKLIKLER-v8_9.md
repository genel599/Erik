# Madem v8_9

- **Yönetici "Herkesten sil":** Grup yöneticisi, kendi atmadığı mesajları da herkesten silebilir (buton "Herkesten sil (yönetici)"). Yetki sunucuda `delete_message_for_everyone` fonksiyonuyla doğrulanır. Sistem mesajları silinemez.
- **Üye kendi mesajını herkesten silebilir** (grup ve birebir sohbet): bu özellik zaten vardı, değişmedi.

## Kurulum
`supabase/migrations/20261101130000_madem_v8_9_admin_delete_for_everyone.sql` (canlı veritabanına uygulandı).
