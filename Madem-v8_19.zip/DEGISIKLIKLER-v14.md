# v14
- Uygulama ikonu: beyaz zemin, yeşil "ma" + mavi "dem" yazısı (public/icons/*)
- Maskable ikon güvenli alana sığdırıldı (Samsung/Android yuvarlak ve squircle maskelerinde kırpılmaz)
- theme_color beyaz, service worker önbelleği v4 (eski ikon temizlenir)
