madem: Sesli ve görüntülü arama özellikleri kaldırıldı. Arama menüsü, arama butonları ve çağrı ekranı devre dışı bırakıldı.
