# Madem v15

- v14 özellikleri korunmuştur.
- Mevcut mesajlaşma yapısı değiştirilmemiştir.
- Uygulama çökmelerinde kullanıcıya kontrollü hata ekranı gösterimi eklendi.
- Sonraki güvenlik ve performans geliştirmeleri için altyapı korunmuştur.
