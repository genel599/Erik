# Madem v8_12
- **Etiket bildirimi:** Grupta `@kullanıcı` veya `@herkes` ile etiketlenen üyeye "X seni etiketledi" başlıklı ayrı bildirim gider (tür: `mention`). Sessize alınmış sohbet ve kapalı `mentions_enabled` tercihi saygı görür. Migration: `20261101160000_...`
- **Hız sınırı:** `consume_rate_limit` fonksiyonu ve sayaç tablosu canlıya eklendi.
- **Mesaj sınırı:** İçerik 10.000 karakterle sınırlandı. Migration: `20261101170000_...`
- **Onay pencereleri:** Tarayıcının `confirm()` penceresi yerine uygulama içi onay penceresi (çıkış, hesap silme, gruptan ayrılma, engelleme vb.).
- Dokümanlar (`DENETIM_RAPORU.md`, `README.md`) güncellendi.
