# Madem v8_7

1. **Sekme başlığında okunmamış sayısı:** Okunmamış sohbet varsa sekme başlığı `(3) madem` olur, yoksa `madem — Mesajlaşma`. Sessize alınan ve arşivlenen sohbetler sayılmaz; açık/görünür sohbet de sayılmaz.
2. **@herkes:** Grup sohbetinde `@` yazınca listenin en üstünde "Herkes" çıkar. `@herkes` içeren mesaj tüm üyelerde sarı vurguyla görünür ve sohbet listesinde `@` rozeti çıkarır. (Push bildirimi davranışı değişmedi; sessize alanlara bildirim gitmez.)
3. **Sistem mesajları:** "X gruba eklendi / gruba katıldı / gruptan çıkarıldı / gruptan ayrıldı" mesajları sohbette ortalanmış gri etiket olarak görünür. Bildirim/push üretmez, okunmamış sayılmaz, istemci tarafından taklit edilemez.

## Kurulum
1. `supabase/migrations/20261031130000_madem_v8_7_system_messages.sql` dosyasını Supabase SQL Editor'de çalıştır (madde 3 için gerekli; 1 ve 2 yalnızca istemci değişikliğidir).
2. `npm install && npm run build` ile derleyip deploy et.
