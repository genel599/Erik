# Madem v8_8

- **@ rozeti (madde 5):** Okunmamış @kullanıcı / @herkes bahsetmesi artık sunucudan hesaplanır (son 30 gün). Sayfa yenilense ya da sonradan başka mesaj gelse de rozet, sohbet açılıp okunana kadar kalır. Rozet mavi noktanın yanında görünür.
- **Grup olayı sistem mesajları (madde 10):** "X grubu oluşturdu", "X grup adını “…” olarak değiştirdi", "X grup fotoğrafını değiştirdi/kaldırdı", "X yönetici yapıldı / yöneticilikten çıkarıldı", "Artık yalnızca yöneticiler mesaj gönderebilir / Artık herkes mesaj gönderebilir". Veritabanı tetikleyicileriyle çalışır, istemci değişikliği gerekmez.
- **Okunmamış mesaj ayracı (madde 11):** Sohbet açılınca "N okunmamış mesaj" çizgisi ilk okunmamış mesajın üstünde çıkar ve ekran oraya kayar.

## Kurulum
1. Önce v8_7 migration'ı çalışmış olmalı (`20261031130000_...`).
2. Sonra `supabase/migrations/20261101120000_madem_v8_8_events_and_mentions.sql` dosyasını Supabase SQL Editor'de çalıştır. Sohbet özeti fonksiyonunu yeniden oluşturur, yedek al.
3. Derle ve deploy et.
