# v8.19

- Mesaja dokununca yalnızca emoji tepkileri çıkar.
- Mesaja uzun basınca (masaüstünde sağ tık) emoji hariç tüm işlemler çıkar: Yanıtla, Favori, İlet, Sabitle, Seç, Düzenle, Sil (Kendimden sil / Herkesten sil).


## v8.19.1 — mobil fotoğraf ve bildirim kutusu düzeltmesi
- Profil ve sohbet/grup avatarları sabit kare ölçüye alındı; görseller `object-fit: cover` ile oranı bozulmadan kırpılır.
- Mobilde başarı/hata mesajı (toast) mesaj yazma alanının üstüne taşındı; gönderme alanını kapatmaz.
- `.env.production` gizli dosyası dağıtım ZIP'inden çıkarıldı ve `.gitignore` içine eklendi; üretim sırlarının depoya yüklenmesi önlenir.
